{
  description = "EBALIA Launcher — Lost Versions + full in-process Minecraft client";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
  };

  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs { inherit system; };
      in {
        packages.default = pkgs.stdenv.mkDerivation {
          pname = "ebalia-launcher";
          version = "3.0.0";

          src = ./.;

          nativeBuildInputs = [ pkgs.cmake pkgs.qt6.wrapQtAppsHook pkgs.pkg-config ];
          buildInputs = [ pkgs.qt6.qtbase pkgs.qt6.qttools pkgs.qt6.qtmultimedia pkgs.qt6.qtsvg pkgs.libarchive ];

          cmakeFlags = [
            "-DCMAKE_BUILD_TYPE=Release"
          ];

          installPhase = ''
            runHook preInstall
            install -Dm755 ebalia-launcher $out/bin/ebalia-launcher
            install -Dm644 ${./resources/versions.json} $out/share/ebalia-launcher/versions.json
            runHook postInstall
          '';

          meta = with pkgs.lib; {
            description = "EBALIA Launcher — lost versions + full client";
            license = licenses.mit;
            platforms = platforms.all;
          };
        };

        devShells.default = pkgs.mkShell {
          nativeBuildInputs = [ pkgs.cmake pkgs.qt6.wrapQtAppsHook pkgs.pkg-config ];
          buildInputs = [ pkgs.qt6.qtbase pkgs.qt6.qttools pkgs.qt6.qtmultimedia pkgs.qt6.qtsvg pkgs.libarchive ];
        };
      });
}
