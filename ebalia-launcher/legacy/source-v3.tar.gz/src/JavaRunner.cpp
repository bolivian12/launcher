#include "JavaRunner.hpp"
#include <QFileInfo>
#include <QDir>
#include <QProcessEnvironment>
#include <QStandardPaths>

JavaRunner::JavaRunner(QObject *parent)
    : QObject(parent)
    , m_process(nullptr)
{
}

JavaRunner::~JavaRunner()
{
    if (m_process) {
        m_process->close();
        m_process->deleteLater();
    }
}

void JavaRunner::locateJava()
{
    m_javaPaths = findJava();
    if (!m_javaPaths.isEmpty()) {
        emit javaFound(m_javaPaths.first());
    } else {
        emit javaNotFound();
    }
}

QStringList JavaRunner::findJava()
{
    QStringList results;

#if defined(Q_OS_WIN)
    QStringList searchDirs = {
        qgetenv("JAVA_HOME"),
        qgetenv("JDK_HOME"),
        "C:/Program Files/Java",
        "C:/Program Files (x86)/Java",
        "C:/Program Files/Eclipse Adoptium",
        "C:/Program Files/Microsoft"
    };
    QStringList exeNames = {"javaw.exe", "java.exe"};

#elif defined(Q_OS_MAC)
    QStringList searchDirs = {
        qgetenv("JAVA_HOME"),
        "/Library/Java/JavaVirtualMachines",
        "/opt/homebrew/opt/openjdk@8",
        "/usr/local/opt/openjdk@8"
    };
    QStringList exeNames = {"java"};

#else
    QStringList searchDirs = {
        qgetenv("JAVA_HOME"),
        "/usr/lib/jvm",
        "/usr/local/lib/jvm",
        "/opt/jdk",
        "/run/current-system/sw/lib/jvm",
        "/nix/var/nix/profiles/default/lib/jvm"
    };
    QStringList exeNames = {"java", "javaw"};
#endif

    for (const QString &dir : searchDirs) {
        if (dir.isEmpty()) continue;
        QFileInfo info(dir);
        if (!info.exists()) continue;

        if (info.isFile()) {
            if (exeNames.contains(info.fileName(), Qt::CaseInsensitive))
                results << info.absoluteFilePath();
            continue;
        }

        QDir d(dir);

        // Direct check
        for (const QString &exe : exeNames) {
            // check bin/ subdir first
            QString binDir = d.absoluteFilePath("bin");
            if (QFileInfo::exists(binDir)) {
                QString p = QDir(binDir).absoluteFilePath(exe);
                if (QFileInfo::exists(p) && !results.contains(p))
                    results << p;
            }
            // check direct
            QString p = d.absoluteFilePath(exe);
            if (QFileInfo::exists(p) && !results.contains(p))
                results << p;
        }

        // One level deep (common for /usr/lib/jvm/java-8-openjdk/)
        QStringList subdirs = d.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString &sub : subdirs) {
            QDir subDir = d.absoluteFilePath(sub);

            // bin/ subdir
            QString binPath = subDir.absoluteFilePath("bin");
            if (QFileInfo::exists(binPath)) {
                for (const QString &exe : exeNames) {
                    QString p = QDir(binPath).absoluteFilePath(exe);
                    if (QFileInfo::exists(p) && !results.contains(p))
                        results << p;
                }
            }

            // macOS JVM structure: Contents/Home/bin/
            QString macPath = subDir.absoluteFilePath("Contents/Home/bin");
            if (QFileInfo::exists(macPath)) {
                for (const QString &exe : exeNames) {
                    QString p = QDir(macPath).absoluteFilePath(exe);
                    if (QFileInfo::exists(p) && !results.contains(p))
                        results << p;
                }
            }
        }
    }

    // Check PATH on non-Windows
#ifndef Q_OS_WIN
    QProcess whichProc;
    whichProc.start("which", QStringList{"java"});
    whichProc.waitForFinished(3000);
    QString pathResult = QString::fromUtf8(whichProc.readAllStandardOutput()).trimmed();
    if (!pathResult.isEmpty() && !results.contains(pathResult))
        results << pathResult;
#endif

    return results;
}

void JavaRunner::launch(const VersionInfo &version, const QString &installDir)
{
    QString javaPath;
    if (!m_javaPaths.isEmpty()) {
        javaPath = m_javaPaths.first();
    } else {
        m_javaPaths = findJava();
        if (m_javaPaths.isEmpty()) {
            emit processError("No Java installation found. Install Java 8 for old Minecraft versions.");
            return;
        }
        javaPath = m_javaPaths.first();
    }

    // Build launch arguments
    QStringList args;
    args << "-Xmx512m" << "-Xms256m";
    args << "-Djava.util.Arrays.useLegacyMergeSort=true";

    // Find the jar or exe in the install directory
    QDir dir(installDir);

#if defined(Q_OS_WIN)
    // On Windows, try launching the .exe directly if it exists
    QString exePath = dir.absoluteFilePath(version.launchCommand);
    if (version.launchCommand.endsWith(".exe") && QFileInfo::exists(exePath)) {
        if (m_process) {
            m_process->close();
            m_process->deleteLater();
        }
        m_process = new QProcess(this);
        m_process->setWorkingDirectory(installDir);
        connect(m_process, &QProcess::errorOccurred, this, &JavaRunner::onErrorOccurred);
        connect(m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                this, &JavaRunner::onFinished);

        m_process->start(exePath, QStringList());
        if (m_process->waitForStarted(5000)) {
            emit processStarted();
        } else {
            emit processError("Failed to start: " + m_process->errorString());
        }
        return;
    }
#endif

    // Java-based launch: find .jar files
    QStringList jars = dir.entryList(QStringList() << "*.jar", QDir::Files);
    if (jars.isEmpty()) {
        emit processError("No JAR file found in: " + installDir);
        return;
    }

    QString jarPath = dir.absoluteFilePath(jars.first());
    args << "-jar" << jarPath;

    if (m_process) {
        m_process->close();
        m_process->deleteLater();
    }
    m_process = new QProcess(this);
    m_process->setWorkingDirectory(installDir);

    connect(m_process, &QProcess::errorOccurred, this, &JavaRunner::onErrorOccurred);
    connect(m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &JavaRunner::onFinished);

    m_process->start(javaPath, args);

    if (m_process->waitForStarted(5000)) {
        emit processStarted();
    } else {
        emit processError("Failed to start Java: " + m_process->errorString());
    }
}

void JavaRunner::onErrorOccurred(QProcess::ProcessError error)
{
    Q_UNUSED(error)
    emit processError("Process error: " + (m_process ? m_process->errorString() : "unknown"));
}

void JavaRunner::onFinished(int exitCode, QProcess::ExitStatus status)
{
    Q_UNUSED(status)
    emit processFinished(exitCode);

    if (m_process) {
        m_process->deleteLater();
        m_process = nullptr;
    }
}
