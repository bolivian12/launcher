#include "PatreonAuth.hpp"

#include <QTcpServer>
#include <QTcpSocket>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QSettings>
#include <QDesktopServices>
#include <QUrl>
#include <QFile>
#include <QJsonDocument>

// ── Creator configuration ────────────────────────────────────────
// Fill these from https://www.patreon.com/portal/registration/register-clients
static const char kClientId[]     = "FILL_ME_CLIENT_ID";
static const char kClientSecret[] = "FILL_ME_CLIENT_SECRET";
// Only count memberships whose campaign vanity contains this ("" = any)
static const char kCampaignKeyword[] = "ebalia";

static const char kTokenUrl[]    = "https://www.patreon.com/api/oauth2/token";
static const char kIdentityUrl[] =
    "https://www.patreon.com/api/oauth2/v2/identity"
    "?include=memberships.currently_entitled_tiers,memberships.campaign"
    "&fields%5Buser%5D=full_name"
    "&fields%5Bmember%5D=patron_status"
    "&fields%5Btier%5D=title"
    "&fields%5Bcampaign%5D=vanity";

// Credential chain: bundled resources/patreon.json (authoritative when filled)
// → QSettings (dev override) → compiled-in placeholders.
static QString fromBundledJson(const QString &field)
{
    QFile f(QStringLiteral(":/patreon.json"));
    if (!f.open(QIODevice::ReadOnly))
        return QString();
    return QJsonDocument::fromJson(f.readAll()).object()
        .value(field).toString();
}

static QString clientId()
{
    QString v = fromBundledJson(QStringLiteral("client_id"));
    if (v.isEmpty() || v == QStringLiteral("FILL_ME_CLIENT_ID")) {
        QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        v = s.value(QStringLiteral("patreon/client_id")).toString();
    }
    return v.isEmpty() ? QString::fromLatin1(kClientId) : v;
}

static QString clientSecret()
{
    QString v = fromBundledJson(QStringLiteral("client_secret"));
    if (v.isEmpty() || v == QStringLiteral("FILL_ME_CLIENT_SECRET")) {
        QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        v = s.value(QStringLiteral("patreon/client_secret")).toString();
    }
    return v.isEmpty() ? QString::fromLatin1(kClientSecret) : v;
}

PatreonAuth::PatreonAuth(QObject *parent)
    : QObject(parent)
{
}

bool PatreonAuth::isConfigured() const
{
    return !clientId().isEmpty() && clientId() != QStringLiteral("FILL_ME_CLIENT_ID")
        && !clientSecret().isEmpty() && clientSecret() != QStringLiteral("FILL_ME_CLIENT_SECRET");
}

bool PatreonAuth::hasTokens() const
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    return !s.value(QStringLiteral("patreon/access")).toString().isEmpty();
}

void PatreonAuth::startLogin()
{
    if (!isConfigured()) {
        emit loginFailed(QStringLiteral(
            "Patreon client not configured — set kClientId/kClientSecret in PatreonAuth.cpp"));
        return;
    }

    if (m_server) {
        m_server->close();
        m_server->deleteLater();
    }
    m_server = new QTcpServer(this);
    // Prefer the fixed port registered in the Patreon client; fall back to ephemeral
    if (!m_server->listen(QHostAddress::LocalHost, 8777) &&
        !m_server->listen(QHostAddress::LocalHost, 0)) {
        emit loginFailed(QStringLiteral("Cannot start local callback server"));
        return;
    }
    connect(m_server, &QTcpServer::newConnection,
            this, &PatreonAuth::onCallbackConnection);

    const quint16 port = m_server->serverPort();
    const QString redirect =
        QStringLiteral("http://127.0.0.1:%1/callback").arg(port);

    QUrl url(QStringLiteral("https://www.patreon.com/oauth2/authorize"));
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("response_type"), QStringLiteral("code"));
    q.addQueryItem(QStringLiteral("client_id"), QString::fromLatin1(kClientId));
    q.addQueryItem(QStringLiteral("redirect_uri"), redirect);
    q.addQueryItem(QStringLiteral("scope"),
                   QStringLiteral("identity identity.memberships"));
    url.setQuery(q);
    m_authUrl = url.toString();

    QDesktopServices::openUrl(url);
    emit loginStarted();
}

void PatreonAuth::onCallbackConnection()
{
    QTcpSocket *sock = m_server->nextPendingConnection();
    if (!sock) return;

    connect(sock, &QTcpSocket::readyRead, this, [this, sock] {
        const QString req = QString::fromUtf8(sock->readAll());
        const int sp1 = req.indexOf(QLatin1Char(' '));
        const int sp2 = req.indexOf(QLatin1Char(' '), sp1 + 1);
        const QString path = req.mid(sp1 + 1, sp2 - sp1 - 1);

        const QByteArray page =
            "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n"
            "<html><body style='background:#161616;color:#7cbd4b;font-family:monospace;"
            "display:flex;align-items:center;justify-content:center;height:100vh'>"
            "<h2>EBALIA — membership linked. You can return to the launcher.</h2>"
            "</body></html>";
        sock->write(page);
        sock->flush();
        sock->disconnectFromHost();

        const quint16 port = m_server->serverPort();
        m_server->close();
        m_server->deleteLater();
        m_server = nullptr;

        const QUrlQuery query(QUrl(path).query());
        const QString code = query.queryItemValue(QStringLiteral("code"));
        if (code.isEmpty()) {
            emit loginFailed(QStringLiteral("Patreon did not return an auth code"));
            return;
        }
        exchangeCode(code, port);
    });
}

void PatreonAuth::exchangeCode(const QString &code, quint16 port)
{
    QUrlQuery form;
    form.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("authorization_code"));
    form.addQueryItem(QStringLiteral("code"), code);
    form.addQueryItem(QStringLiteral("client_id"), QString::fromLatin1(kClientId));
    form.addQueryItem(QStringLiteral("client_secret"), QString::fromLatin1(kClientSecret));
    form.addQueryItem(QStringLiteral("redirect_uri"),
                      QStringLiteral("http://127.0.0.1:%1/callback").arg(port));

    QNetworkRequest req(QUrl(QString::fromLatin1(kTokenUrl)));
    req.setHeader(QNetworkRequest::ContentTypeHeader,
                  QStringLiteral("application/x-www-form-urlencoded"));
    req.setHeader(QNetworkRequest::UserAgentHeader,
                  QStringLiteral("EBALIA-Launcher/3.0"));

    QNetworkReply *reply = m_nam.post(req, form.toString(QUrl::FullyEncoded).toUtf8());
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit loginFailed(QStringLiteral("Token exchange failed: ") + reply->errorString());
            return;
        }
        QJsonObject obj = QJsonDocument::fromJson(reply->readAll()).object();
        const QString access  = obj[QStringLiteral("access_token")].toString();
        const QString refresh = obj[QStringLiteral("refresh_token")].toString();
        if (access.isEmpty()) {
            emit loginFailed(QStringLiteral("Patreon returned no access token"));
            return;
        }
        QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s.setValue(QStringLiteral("patreon/access"), access);
        s.setValue(QStringLiteral("patreon/refresh"), refresh);
        requestIdentity(access, true);
    });
}

void PatreonAuth::refreshTokens()
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    const QString refresh = s.value(QStringLiteral("patreon/refresh")).toString();
    if (refresh.isEmpty()) {
        emit loginFailed(QStringLiteral("Session expired — log in again"));
        return;
    }

    QUrlQuery form;
    form.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("refresh_token"));
    form.addQueryItem(QStringLiteral("refresh_token"), refresh);
    form.addQueryItem(QStringLiteral("client_id"), QString::fromLatin1(kClientId));
    form.addQueryItem(QStringLiteral("client_secret"), QString::fromLatin1(kClientSecret));

    QNetworkRequest req(QUrl(QString::fromLatin1(kTokenUrl)));
    req.setHeader(QNetworkRequest::ContentTypeHeader,
                  QStringLiteral("application/x-www-form-urlencoded"));
    req.setHeader(QNetworkRequest::UserAgentHeader,
                  QStringLiteral("EBALIA-Launcher/3.0"));

    QNetworkReply *reply = m_nam.post(req, form.toString(QUrl::FullyEncoded).toUtf8());
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit loginFailed(QStringLiteral("Token refresh failed — log in again"));
            return;
        }
        QJsonObject obj = QJsonDocument::fromJson(reply->readAll()).object();
        const QString access  = obj[QStringLiteral("access_token")].toString();
        const QString refresh = obj[QStringLiteral("refresh_token")].toString();
        QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s.setValue(QStringLiteral("patreon/access"), access);
        s.setValue(QStringLiteral("patreon/refresh"), refresh);
        requestIdentity(access, false);
    });
}

void PatreonAuth::fetchIdentity()
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    const QString access = s.value(QStringLiteral("patreon/access")).toString();
    if (access.isEmpty())
        return;
    requestIdentity(access, true);
}

void PatreonAuth::requestIdentity(const QString &accessToken, bool allowRefreshRetry)
{
    QNetworkRequest req(QUrl(QString::fromLatin1(kIdentityUrl)));
    req.setRawHeader("Authorization", "Bearer " + accessToken.toUtf8());
    req.setHeader(QNetworkRequest::UserAgentHeader,
                  QStringLiteral("EBALIA-Launcher/3.0"));

    QNetworkReply *reply = m_nam.get(req);
    connect(reply, &QNetworkReply::finished, this, [this, reply, allowRefreshRetry] {
        reply->deleteLater();

        if (reply->error() == QNetworkReply::AuthenticationRequiredError && allowRefreshRetry) {
            refreshTokens();
            return;
        }
        if (reply->error() != QNetworkReply::NoError) {
            emit loginFailed(QStringLiteral("Identity check failed: ") + reply->errorString());
            return;
        }

        QJsonObject root = QJsonDocument::fromJson(reply->readAll()).object();
        const QString name = root[QStringLiteral("data")].toObject()
                                 [QStringLiteral("attributes")].toObject()
                                 [QStringLiteral("full_name")].toString();

        // Index included tiers (id -> title) and campaign vanities
        QHash<QString, QString> tierTitles;
        QHash<QString, QString> campaignVanity;
        const QJsonArray included = root[QStringLiteral("included")].toArray();
        for (const QJsonValue &v : included) {
            const QJsonObject o = v.toObject();
            const QString type = o[QStringLiteral("type")].toString();
            const QString id   = o[QStringLiteral("id")].toString();
            if (type == QStringLiteral("tier"))
                tierTitles[id] = o[QStringLiteral("attributes")].toObject()
                                     [QStringLiteral("title")].toString();
            else if (type == QStringLiteral("campaign"))
                campaignVanity[id] = o[QStringLiteral("attributes")].toObject()
                                         [QStringLiteral("vanity")].toString();
        }

        // Walk memberships: active patrons of our campaign, keep highest tier
        int bestRank = 0;
        QString bestTitle;
        for (const QJsonValue &v : included) {
            const QJsonObject o = v.toObject();
            if (o[QStringLiteral("type")].toString() != QStringLiteral("member"))
                continue;
            const QString status = o[QStringLiteral("attributes")].toObject()
                                       [QStringLiteral("patron_status")].toString();
            if (status != QStringLiteral("active_patron"))
                continue;

            // Optional campaign filter
            if (kCampaignKeyword[0] != '\0') {
                const QString campId = o[QStringLiteral("relationships")].toObject()
                    [QStringLiteral("campaign")].toObject()
                    [QStringLiteral("data")].toObject()
                    [QStringLiteral("id")].toString();
                const QString vanity = campaignVanity.value(campId);
                if (!vanity.isEmpty() &&
                    !vanity.contains(QString::fromLatin1(kCampaignKeyword), Qt::CaseInsensitive))
                    continue;
            }

            const QJsonArray entitled = o[QStringLiteral("relationships")].toObject()
                [QStringLiteral("currently_entitled_tiers")].toObject()
                [QStringLiteral("data")].toArray();
            for (const QJsonValue &tv : entitled) {
                const QString title = tierTitles.value(
                    tv.toObject()[QStringLiteral("id")].toString());
                const QString low = title.toLower();
                int rank = 0;
                if (low.contains(QStringLiteral("senior")))         rank = 3;
                else if (low.contains(QStringLiteral("explicit")))  rank = 2;
                else if (low.contains(QStringLiteral("exclusive"))) rank = 1;
                if (rank > bestRank) {
                    bestRank = rank;
                    bestTitle = title;
                }
            }
        }

        emit identityReady(name, bestRank, bestTitle);
    });
}

void PatreonAuth::logout()
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    s.remove(QStringLiteral("patreon/access"));
    s.remove(QStringLiteral("patreon/refresh"));
}
