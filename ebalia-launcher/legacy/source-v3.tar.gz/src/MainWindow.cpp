#include "MainWindow.hpp"
#include "LicenseDialog.hpp"
#include "UpdateDialog.hpp"
#include "VideoDialog.hpp"
#include "NewInstanceDialog.hpp"
#include "EditInstanceDialog.hpp"
#include "NiceButton.hpp"
#include "Icons.hpp"
#include "TourOverlay.hpp"

#include <QApplication>
#include <QScreen>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QMouseEvent>
#include <QSettings>
#include <QDir>
#include <QStyle>
#include <QPixmap>
#include <QDesktopServices>
#include <QUrl>
#include <QProcess>
#include <QClipboard>
#include <QTimer>
#include <QStackedLayout>
#include <QFileInfo>
#include <QGuiApplication>
#include <QLineEdit>
#include <QStandardPaths>
#include <QFileDialog>
#include <QPlainTextEdit>
#include <QCheckBox>
#include <QSpinBox>
#include <QMessageBox>
#include <QDateTime>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    m_versionManager  = new VersionManager(this);
    m_downloadManager = new DownloadManager(this);
    m_serverDl        = new DownloadManager(this);
    m_javaRunner      = new JavaRunner(this);
    m_licenseManager  = new LicenseManager(this);
    m_patreonAuth     = new PatreonAuth(this);
    m_modManager      = new ModManager(this);
    m_newsManager     = new NewsManager(this);
    m_updateChecker   = new UpdateChecker(this);
    m_depManager      = new DependencyManager(this);
    m_mcManager       = new McInstanceManager(m_versionManager->getDataDir(), this);
    m_accountManager  = new AccountManager(m_mcManager->mcDir(), this);

    setupUI();
    setupStylesheet();
    connectSignals();
    loadVersions();
    retranslateUi();
    m_javaRunner->locateJava();

    // Live data + session revalidation
    m_newsManager->refresh();
    if (m_patreonAuth->hasTokens())
        m_patreonAuth->fetchIdentity();
    m_updateChecker->check();
}

MainWindow::~MainWindow() = default;

// ─── UI ──────────────────────────────────────────────────────────

void MainWindow::setupUI()
{
    setWindowTitle(QStringLiteral("EBALIA — Lost Versions"));
    resize(1200, 720);
    setMinimumSize(1000, 620);

    QScreen *screen = QApplication::primaryScreen();
    if (screen) {
        QRect g = screen->availableGeometry();
        move((g.width() - width()) / 2, (g.height() - height()) / 2);
    }

    auto *central = new QWidget(this);
    auto *root = new QHBoxLayout(central);
    root->setSpacing(0);
    root->setContentsMargins(0, 0, 0, 0);

    // ══ Sidebar ══
    auto *sidebar = new QWidget(central);
    sidebar->setObjectName(QStringLiteral("sidebar"));
    sidebar->setFixedWidth(204);

    auto *sideLayout = new QVBoxLayout(sidebar);
    sideLayout->setSpacing(2);
    sideLayout->setContentsMargins(0, 10, 0, 8);

    m_licenseChip = new QPushButton(QStringLiteral("FREE"), sidebar);
    m_licenseChip->setObjectName(QStringLiteral("accountChip"));
    m_licenseChip->setCursor(Qt::PointingHandCursor);
    m_licenseChip->setToolTip(QStringLiteral("Membership"));
    sideLayout->addWidget(m_licenseChip);

    // Mode switch: Lost Versions ⇄ EBALIA Client
    auto *modeRow = new QHBoxLayout;
    modeRow->setContentsMargins(10, 8, 10, 4);
    modeRow->setSpacing(4);
    m_modeLost = new QPushButton(QStringLiteral("LOST"), sidebar);
    m_modeLost->setObjectName(QStringLiteral("modeBtn"));
    m_modeLost->setCheckable(true);
    m_modeLost->setChecked(true);
    m_modeLost->setCursor(Qt::PointingHandCursor);
    m_modeLost->setToolTip(QStringLiteral("Lost Versions"));
    m_modeClient = new QPushButton(QStringLiteral("CLIENT"), sidebar);
    m_modeClient->setObjectName(QStringLiteral("modeBtn"));
    m_modeClient->setCheckable(true);
    m_modeClient->setCursor(Qt::PointingHandCursor);
    m_modeClient->setToolTip(QStringLiteral("EBALIA Client — vanilla Minecraft instances"));
    modeRow->addWidget(m_modeLost, 1);
    modeRow->addWidget(m_modeClient, 1);
    sideLayout->addLayout(modeRow);
    sideLayout->addSpacing(10);

    auto *libCaption = new QLabel(QStringLiteral("LIBRARY"), sidebar);
    libCaption->setObjectName(QStringLiteral("sideCaption"));
    sideLayout->addWidget(libCaption);

    auto mkSide = [sidebar](const QPixmap &icon, const QString &text, bool checkable) {
        auto *b = new QPushButton(QStringLiteral("  ") + text, sidebar);
        b->setObjectName(QStringLiteral("sideItem"));
        b->setIcon(QIcon(icon));
        b->setIconSize(QSize(18, 18));
        b->setCheckable(checkable);
        b->setCursor(Qt::PointingHandCursor);
        return b;
    };

    m_sideHome   = mkSide(icons::home(),        QStringLiteral("HOME"), true);
    m_sideAll    = mkSide(icons::allVersions(), QStringLiteral("ALL VERSIONS"), true);
    m_sideAlpha  = mkSide(icons::alpha(),       QStringLiteral("ALPHA"), true);
    m_sideHorror = mkSide(icons::horror(),      QStringLiteral("HORROR"), true);
    m_sideRelease= mkSide(icons::release(),     QStringLiteral("RELEASE"), true);

    for (auto *btn : { m_sideHome, m_sideAll, m_sideAlpha, m_sideHorror, m_sideRelease })
        sideLayout->addWidget(btn);
    m_sideHome->setChecked(true);

    sideLayout->addStretch(1);

    auto *comCaption = new QLabel(QStringLiteral("COMMUNITY"), sidebar);
    comCaption->setObjectName(QStringLiteral("sideCaption"));
    sideLayout->addWidget(comCaption);

    auto mkLink = [this, &mkSide](const QPixmap &icon, const QString &text,
                                  void (MainWindow::*slot)()) {
        auto *b = mkSide(icon, text, false);
        connect(b, &QPushButton::clicked, this, slot);
        return b;
    };

    auto *sideNews    = mkLink(icons::news(),    QStringLiteral("WHAT'S NEW"), &MainWindow::onTabNews);
    auto *sideFanarts = mkLink(icons::fanart(),  QStringLiteral("FAN ARTS"),  &MainWindow::onTabFanarts);
    auto *sideServers = mkLink(icons::server(),  QStringLiteral("SERVERS"),   &MainWindow::onTabServers);
    auto *sideLearn   = mkLink(icons::learn(),   QStringLiteral("LEARN"),     &MainWindow::onTabLearn);
    auto *sideSupport = mkLink(icons::support(), QStringLiteral("SUPPORT"),   &MainWindow::onTabSupport);
    auto *sideSetup   = mkLink(icons::setup(),   QStringLiteral("SETUP"),     &MainWindow::onTabSetup);
    m_sideSettings    = mkLink(icons::gear(),    QStringLiteral("SETTINGS"),  &MainWindow::onTabSettings);

    for (auto *b : { sideNews, sideFanarts, sideServers, sideLearn, sideSupport, sideSetup })
        sideLayout->addWidget(b);
    sideLayout->addWidget(m_sideSettings);

    auto *versionLabel = new QLabel(QStringLiteral("v3.0.0"), sidebar);
    versionLabel->setObjectName(QStringLiteral("sideVersion"));
    sideLayout->addWidget(versionLabel);

    root->addWidget(sidebar);

    // ══ Right column ══
    auto *rightCol = new QWidget(central);
    auto *rightLayout = new QVBoxLayout(rightCol);
    rightLayout->setSpacing(0);
    rightLayout->setContentsMargins(0, 0, 0, 0);

    auto *topBar = new QWidget(rightCol);
    topBar->setObjectName(QStringLiteral("topBar"));
    topBar->setFixedHeight(58);

    auto *topLayout = new QVBoxLayout(topBar);
    topLayout->setContentsMargins(22, 8, 22, 0);
    topLayout->setSpacing(2);

    auto *gameTitle = new QLabel(QStringLiteral("EBALIA: LOST VERSIONS"), topBar);
    gameTitle->setObjectName(QStringLiteral("gameTitle"));
    topLayout->addWidget(gameTitle);

    auto *tabsRow = new QHBoxLayout;
    tabsRow->setSpacing(26);

    auto mkTab = [topBar](const QString &text) {
        auto *b = new QPushButton(text, topBar);
        b->setObjectName(QStringLiteral("topTab"));
        b->setCheckable(true);
        b->setCursor(Qt::PointingHandCursor);
        return b;
    };
    m_tabPlay     = mkTab(QStringLiteral("Play"));
    m_tabVersions = mkTab(QStringLiteral("Versions"));
    m_tabMods     = mkTab(QStringLiteral("Mods"));
    m_tabSupport  = mkTab(QStringLiteral("Support"));
    m_tabNews     = mkTab(QStringLiteral("Patch Notes"));
    for (auto *t : { m_tabPlay, m_tabVersions, m_tabMods, m_tabSupport, m_tabNews })
        tabsRow->addWidget(t);
    tabsRow->addStretch(1);
    m_tabPlay->setChecked(true);
    topLayout->addLayout(tabsRow);

    rightLayout->addWidget(topBar);

    // ══ Pages ══
    m_stack = new QStackedWidget(rightCol);

    // ── Play page: slideshow hero + news strip ──
    m_playPage = new QWidget;
    m_playPage->setObjectName(QStringLiteral("playPage"));
    auto *playLayout = new QVBoxLayout(m_playPage);
    playLayout->setSpacing(0);
    playLayout->setContentsMargins(0, 0, 0, 0);

    auto *hero = new QFrame(m_playPage);
    hero->setObjectName(QStringLiteral("heroPanel"));

    // Slideshow sits behind the hero content (StackAll overlays them)
    auto *heroStack = new QStackedLayout(hero);
    heroStack->setStackingMode(QStackedLayout::StackAll);
    heroStack->setContentsMargins(0, 0, 0, 0);

    auto *heroContent = new QWidget(hero);
    heroContent->setAttribute(Qt::WA_TranslucentBackground);
    auto *heroLayout = new QVBoxLayout(heroContent);
    heroLayout->setContentsMargins(24, 16, 24, 0);
    heroLayout->setSpacing(4);

    m_slideshow = new HeroSlideshow(hero);
    for (const char *f : { "f1_2", "f2_2", "f3_2", "f1_6", "f2_6", "f3_6", "f2_10", "f3_10" })
        m_slideshow->addFrame(QPixmap(QStringLiteral(":/art/%1.jpg").arg(QLatin1String(f))));
    m_slideshow->start(6000);

    heroStack->addWidget(heroContent);   // on top
    heroStack->addWidget(m_slideshow);   // behind

    auto *heroTopRow = new QHBoxLayout;
    m_heroCategory = new QLabel(QStringLiteral("LIBRARY"), heroContent);
    m_heroCategory->setObjectName(QStringLiteral("heroCategory"));
    heroTopRow->addWidget(m_heroCategory);
    heroTopRow->addStretch(1);
    heroLayout->addLayout(heroTopRow);

    heroLayout->addStretch(1);

    m_heroName = new QLabel(QStringLiteral("EBALIA"), heroContent);
    m_heroName->setObjectName(QStringLiteral("heroBigName"));
    m_heroName->setAlignment(Qt::AlignCenter);
    heroLayout->addWidget(m_heroName);

    m_heroDesc = new QLabel(QStringLiteral("LOST VERSIONS"), heroContent);
    m_heroDesc->setObjectName(QStringLiteral("heroBigSub"));
    m_heroDesc->setAlignment(Qt::AlignCenter);
    heroLayout->addWidget(m_heroDesc);

    m_heroStatus = new QLabel(QString(), heroContent);
    m_heroStatus->setObjectName(QStringLiteral("heroStatus"));
    m_heroStatus->setAlignment(Qt::AlignCenter);
    heroLayout->addWidget(m_heroStatus);

    heroLayout->addStretch(1);

    auto *controlsRow = new QHBoxLayout;
    controlsRow->setSpacing(14);

    m_versionCombo = new QComboBox(heroContent);
    m_versionCombo->setObjectName(QStringLiteral("versionCombo"));
    m_versionCombo->setMinimumWidth(250);
    controlsRow->addWidget(m_versionCombo, 0, Qt::AlignBottom);

    m_folderButton = new NiceButton(QStringLiteral("FOLDER"), NiceButton::Outline, heroContent);
    m_folderButton->setFixedSize(110, 40);
    m_folderButton->setToolTip(QStringLiteral("Open the selected version's install folder"));
    connect(m_folderButton, &QPushButton::clicked, this, [this] {
        const auto versions = m_versionManager->getVersions();
        if (m_selectedIndex < 0 || m_selectedIndex >= versions.size()) return;
        const QString path = m_versionManager->getInstallPath(versions[m_selectedIndex]);
        QDir().mkpath(path);
        QDesktopServices::openUrl(QUrl::fromLocalFile(path));
    });
    controlsRow->addWidget(m_folderButton, 0, Qt::AlignBottom);

    controlsRow->addStretch(1);

    m_installButton = new NiceButton(QStringLiteral("INSTALL"), NiceButton::Secondary, heroContent);
    m_installButton->setObjectName(QStringLiteral("installBtn"));
    m_installButton->setEnabled(false);
    m_installButton->setFixedSize(140, 52);
    controlsRow->addWidget(m_installButton, 0, Qt::AlignBottom);

    m_playButton = new NiceButton(QStringLiteral("PLAY"), NiceButton::Primary, heroContent);
    m_playButton->setObjectName(QStringLiteral("playBtn"));
    m_playButton->setEnabled(false);
    m_playButton->setFixedSize(220, 52);
    QFont playFont = m_playButton->font();
    playFont.setPixelSize(17);
    playFont.setBold(true);
    playFont.setLetterSpacing(QFont::AbsoluteSpacing, 2);
    m_playButton->setFont(playFont);
    controlsRow->addWidget(m_playButton, 0, Qt::AlignBottom);

    controlsRow->addStretch(1);

    auto *rightCol2 = new QVBoxLayout;
    rightCol2->setSpacing(6);
    m_updateChip = new NiceButton(QStringLiteral("Update available"), NiceButton::Outline, heroContent);
    m_updateChip->setObjectName(QStringLiteral("updateChip"));
    m_updateChip->setFixedSize(180, 34);
    m_updateChip->hide();
    rightCol2->addWidget(m_updateChip, 0, Qt::AlignRight);

    m_progressBar = new QProgressBar(heroContent);
    m_progressBar->setObjectName(QStringLiteral("mcProgress"));
    m_progressBar->setRange(0, 100);
    m_progressBar->setFixedWidth(180);
    m_progressBar->hide();
    rightCol2->addWidget(m_progressBar, 0, Qt::AlignRight);
    rightCol2->addStretch(1);
    controlsRow->addLayout(rightCol2);

    heroLayout->addLayout(controlsRow);
    heroLayout->addSpacing(14);

    playLayout->addWidget(hero, 1);

    // News strip
    auto *newsStrip = new QWidget(m_playPage);
    newsStrip->setObjectName(QStringLiteral("newsStrip"));
    auto *stripLayout = new QVBoxLayout(newsStrip);
    stripLayout->setContentsMargins(24, 14, 24, 16);
    stripLayout->setSpacing(8);

    auto *newsHeaderRow = new QHBoxLayout;
    auto *newsHeader = new QLabel(QStringLiteral("NEWS"), newsStrip);
    newsHeader->setObjectName(QStringLiteral("heroCategory"));
    newsHeaderRow->addWidget(newsHeader);
    newsHeaderRow->addStretch(1);
    auto *discordBtn = new NiceButton(QStringLiteral("DISCORD"), NiceButton::Outline, newsStrip);
    discordBtn->setFixedSize(120, 30);
    discordBtn->setToolTip(QStringLiteral("https://discord.gg/ZrgMwfdwZB"));
    connect(discordBtn, &QPushButton::clicked, this, [] {
        QDesktopServices::openUrl(QUrl(QStringLiteral("https://discord.gg/ZrgMwfdwZB")));
    });
    newsHeaderRow->addWidget(discordBtn);
    stripLayout->addLayout(newsHeaderRow);

    m_playNewsLayout = new QVBoxLayout;
    m_playNewsLayout->setSpacing(8);
    stripLayout->addLayout(m_playNewsLayout);

    playLayout->addWidget(newsStrip);

    m_stack->addWidget(m_playPage);

    // ── Versions page ──
    m_versionsPage = new QWidget;
    m_versionsPage->setObjectName(QStringLiteral("versionsPage"));
    auto *versionsLayout = new QVBoxLayout(m_versionsPage);
    versionsLayout->setSpacing(10);
    versionsLayout->setContentsMargins(20, 16, 20, 12);

    m_versionsHeader = new QLabel(QStringLiteral("ALL VERSIONS"), m_versionsPage);
    m_versionsHeader->setObjectName(QStringLiteral("pageHeader"));
    versionsLayout->addWidget(m_versionsHeader);

    auto *cardsScroll = new QScrollArea(m_versionsPage);
    cardsScroll->setObjectName(QStringLiteral("cardsScroll"));
    cardsScroll->setWidgetResizable(true);
    cardsScroll->setFrameShape(QFrame::NoFrame);
    cardsScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    m_cardsContainer = new QWidget;
    m_cardsContainer->setObjectName(QStringLiteral("cardsContainer"));
    m_cardsLayout = new QVBoxLayout(m_cardsContainer);
    m_cardsLayout->setSpacing(8);
    m_cardsLayout->setContentsMargins(2, 2, 2, 2);
    cardsScroll->setWidget(m_cardsContainer);

    versionsLayout->addWidget(cardsScroll, 1);
    m_stack->addWidget(m_versionsPage);

    // ── Scroll pages (mods / support / news / servers / learn / fanarts / setup) ──
    auto mkPage = [this](const QString &objectName, QScrollArea *&scroll, QVBoxLayout *&layout) {
        scroll = new QScrollArea;
        scroll->setObjectName(objectName);
        scroll->setWidgetResizable(true);
        scroll->setFrameShape(QFrame::NoFrame);
        scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        auto *container = new QWidget;
        container->setObjectName(QStringLiteral("cardsContainer"));
        layout = new QVBoxLayout(container);
        layout->setSpacing(10);
        layout->setContentsMargins(20, 16, 20, 12);
        scroll->setWidget(container);
        m_stack->addWidget(scroll);
    };

    mkPage(QStringLiteral("modsPage"),    m_modsScroll,    m_modsLayout);
    mkPage(QStringLiteral("supportPage"), m_supportScroll, m_supportLayout);
    mkPage(QStringLiteral("newsPage"),    m_newsScroll,    m_newsLayout);
    mkPage(QStringLiteral("serversPage"), m_serversScroll, m_serversLayout);
    mkPage(QStringLiteral("learnPage"),   m_learnScroll,   m_learnLayout);
    mkPage(QStringLiteral("setupPage"),   m_setupScroll,   m_setupLayout);
    mkPage(QStringLiteral("setupPage"),   m_settingsScroll, m_settingsLayout);

    m_fanartsScroll = new QScrollArea;
    m_fanartsScroll->setObjectName(QStringLiteral("fanartsPage"));
    m_fanartsScroll->setWidgetResizable(true);
    m_fanartsScroll->setFrameShape(QFrame::NoFrame);
    auto *fanartsContainer = new QWidget;
    fanartsContainer->setObjectName(QStringLiteral("cardsContainer"));
    new QVBoxLayout(fanartsContainer); // grid built inside buildFanartsPage
    m_fanartsScroll->setWidget(fanartsContainer);
    m_stack->addWidget(m_fanartsScroll);

    // ── Client mode page ──
    m_clientPage = new QWidget;
    m_clientPage->setObjectName(QStringLiteral("cardsContainer"));
    auto *clientOuter = new QVBoxLayout(m_clientPage);
    clientOuter->setSpacing(10);
    clientOuter->setContentsMargins(20, 16, 20, 12);
    m_stack->addWidget(m_clientPage);

    buildModsPage();
    buildSupportPage();
    buildServersPage();
    buildLearnPage();
    buildFanartsPage();
    buildSetupPage();
    buildSettingsPage();

    rightLayout->addWidget(m_stack, 1);
    root->addWidget(rightCol, 1);

    setCentralWidget(central);

    rebuildNewsAreas();
    updateLicenseChip();
}

void MainWindow::setupStylesheet()
{
    setStyleSheet(QStringLiteral(R"(
        QWidget {
            font-family: 'Noto Sans', 'Segoe UI', 'Inter', sans-serif;
        }
        QMainWindow, QDialog { background-color: #161616; }

        QWidget#sidebar {
            background-color: #101010;
            border-right: 1px solid #242424;
        }
        QWidget#topBar {
            background-color: #161616;
            border-bottom: 1px solid #242424;
        }

        QLabel { color: #e8e8e8; background: transparent; }

        QLabel#gameTitle {
            color: #909090; font-size: 10px; font-weight: 600; letter-spacing: 1px;
        }
        QLabel#sideCaption {
            color: #5a5a5a; font-size: 9px; font-weight: 600;
            letter-spacing: 2px; padding: 2px 16px 6px 16px;
        }
        QLabel#sideVersion { color: #606060; font-size: 10px; padding: 6px 16px; }

        QPushButton#accountChip {
            background-color: #1d1d1d;
            color: #d0d0d0;
            border: none;
            border-bottom: 1px solid #242424;
            padding: 14px 16px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
        }
        QPushButton#accountChip:hover { background-color: #242424; }
        QPushButton#accountChip[tier="exclusive"] { color: #55ffff; }
        QPushButton#accountChip[tier="explicit"]  { color: #ff55ff; }
        QPushButton#accountChip[tier="senior"]    { color: #ffaa00; }

        QPushButton#sideItem {
            background-color: transparent;
            color: #b5b5b5;
            border: none;
            border-left: 3px solid transparent;
            padding: 10px 16px;
            text-align: left;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1px;
        }
        QPushButton#sideItem:hover { background-color: #1d1d1d; color: #ffffff; }
        QPushButton#sideItem:checked {
            background-color: #1d1d1d;
            color: #ffffff;
            border-left: 3px solid #3c8527;
        }

        /* Mode switch */
        QPushButton#modeBtn {
            background-color: #1a1a1a;
            color: #8a8a8a;
            border: 1px solid #2c2c2c;
            border-radius: 6px;
            padding: 7px 0;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        QPushButton#modeBtn:checked {
            background-color: #24371b;
            color: #7dd069;
            border-color: #3c8527;
        }

        QPushButton#topTab {
            background-color: transparent;
            color: #909090;
            border: none;
            border-bottom: 2px solid transparent;
            padding: 4px 2px 8px 2px;
            font-size: 14px;
        }
        QPushButton#topTab:hover { color: #ffffff; }
        QPushButton#topTab:checked {
            color: #ffffff;
            border-bottom: 2px solid #3c8527;
        }

        /* Hero (slideshow sits behind; panel itself transparent) */
        QFrame#heroPanel { border-bottom: 1px solid #242424; }
        QLabel#heroCategory {
            color: #7dd069; font-size: 11px; font-weight: 600; letter-spacing: 2px;
        }
        QLabel#heroBigName {
            color: #ffffff; font-size: 36px; font-weight: bold; letter-spacing: 6px;
        }
        QLabel#heroBigSub { color: #d0d0d0; font-size: 12px; letter-spacing: 4px; }
        QLabel#heroStatus {
            background-color: rgba(10,10,10,160);
            border-radius: 6px;
            padding: 3px 12px;
            font-size: 12px; color: #d0d0d0;
        }
        QLabel#heroStatus[state="ready"]  { color: #7dd069; }
        QLabel#heroStatus[state="info"]   { color: #e8c154; }

        QLabel#pageHeader {
            color: #7dd069; font-size: 16px; font-weight: bold; letter-spacing: 3px;
        }
        QLabel#sectionHeader {
            color: #909090; font-size: 11px; font-weight: 600;
            letter-spacing: 2px; padding-top: 8px;
        }

        /* News */
        QWidget#newsStrip { background-color: #101010; }
        QFrame#newsCard {
            background-color: #202020;
            border: 1px solid #2a2a2a;
            border-radius: 8px;
        }
        QFrame#newsThumb {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #24371b, stop:1 #161616);
            border-radius: 6px;
        }
        QLabel#newsTitle { color: #ffffff; font-size: 15px; font-weight: bold; }
        QLabel#newsDate { color: #707070; font-size: 11px; }
        QLabel#newsExcerpt { color: #a0a0a0; font-size: 12px; }

        /* Scrollbars */
        QScrollArea { background-color: transparent; border: none; }
        QScrollBar:vertical { background: transparent; width: 8px; margin: 4px 2px; }
        QScrollBar::handle:vertical {
            background: #3a3a3a; border-radius: 4px; min-height: 30px;
        }
        QScrollBar::handle:vertical:hover { background: #4a4a4a; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

        /* Cards (default = library green) */
        QWidget#cardsContainer { background-color: transparent; }
        QFrame#versionCard, QFrame#modCard, QFrame#setupCard, QFrame#guideCard {
            background-color: #202020;
            border: 1px solid #2a2a2a;
            border-radius: 8px;
        }
        QFrame#versionCard:hover { background-color: #262626; border-color: #3a3a3a; }
        QFrame#versionCard[selected="true"] {
            background-color: #22301c;
            border: 1px solid #3c8527;
        }

        QLabel#cardName { color: #ffffff; font-size: 13px; font-weight: 600; }
        QLabel#cardCategory {
            color: #7dd069; font-size: 10px; font-weight: 600; letter-spacing: 1px;
        }
        QLabel#cardAuthor { color: #808080; font-size: 10px; }
        QLabel#cardDesc { color: #a0a0a0; font-size: 11px; }
        QLabel#cardInstalled    { color: #7dd069; font-size: 11px; font-weight: 600; }
        QLabel#cardNotInstalled { color: #707070; font-size: 11px; }
        QLabel#cardOk      { color: #7dd069; font-size: 11px; font-weight: 600; }
        QLabel#cardMissing { color: #e0a03a; font-size: 11px; font-weight: 600; }
        QLabel#cardError   { color: #e05555; font-size: 11px; }
        QLabel#guideStep   { color: #c8c8c8; font-size: 12px; }
        QLabel#mono        { color: #e8c154; font-size: 12px; font-family: 'DejaVu Sans Mono', monospace; }

        /* Fan art gallery */
        QFrame#fanartCard {
            background-color: #1c1c1c;
            border: 1px solid #2a2a2a;
            border-radius: 8px;
        }
        QFrame#fanartCard:hover { border-color: #ffd75a; }
        QLabel#fanartCredit { color: #909090; font-size: 10px; }

        /* ── Section themes ───────────────────────────── */

        QWidget#versionsPage[theme="alpha"] { background-color: #121a10; }
        QWidget#versionsPage[theme="alpha"] QLabel#pageHeader { color: #a4e06a; }
        QWidget#versionsPage[theme="alpha"] QFrame#versionCard {
            background-color: #1a2416; border: 1px solid #2c3a24;
        }
        QWidget#versionsPage[theme="alpha"] QFrame#versionCard:hover {
            background-color: #202c1a; border-color: #3e5430;
        }
        QWidget#versionsPage[theme="alpha"] QFrame#versionCard[selected="true"] {
            background-color: #24371b; border: 1px solid #8be86e;
        }
        QWidget#versionsPage[theme="alpha"] QLabel#cardCategory { color: #a4e06a; }

        QWidget#versionsPage[theme="horror"] { background-color: #150e11; }
        QWidget#versionsPage[theme="horror"] QLabel#pageHeader {
            color: #ff4444; letter-spacing: 5px;
        }
        QWidget#versionsPage[theme="horror"] QFrame#versionCard {
            background-color: #1c1216; border: 1px solid #361820;
        }
        QWidget#versionsPage[theme="horror"] QFrame#versionCard:hover {
            background-color: #24161c; border-color: #55222c;
        }
        QWidget#versionsPage[theme="horror"] QFrame#versionCard[selected="true"] {
            background-color: #2c1218; border: 1px solid #e03a3a;
        }
        QWidget#versionsPage[theme="horror"] QLabel#cardCategory { color: #ff5555; }
        QWidget#versionsPage[theme="horror"] QLabel#cardName { color: #f0dcd8; }
        QWidget#versionsPage[theme="horror"] QLabel#cardInstalled { color: #ff7a5c; }

        QWidget#versionsPage[theme="release"] { background-color: #0e181c; }
        QWidget#versionsPage[theme="release"] QLabel#pageHeader { color: #55c7d9; }
        QWidget#versionsPage[theme="release"] QFrame#versionCard {
            background-color: #142028; border: 1px solid #1e3440;
        }
        QWidget#versionsPage[theme="release"] QFrame#versionCard:hover {
            background-color: #182630; border-color: #2a4a5a;
        }
        QWidget#versionsPage[theme="release"] QFrame#versionCard[selected="true"] {
            background-color: #14303a; border: 1px solid #55c7d9;
        }
        QWidget#versionsPage[theme="release"] QLabel#cardCategory { color: #55c7d9; }
        QWidget#versionsPage[theme="release"] QLabel#cardInstalled { color: #6fe3f5; }

        QScrollArea#modsPage { background-color: #181410; }
        QScrollArea#modsPage QLabel#pageHeader { color: #e0a03a; }
        QScrollArea#modsPage QFrame#modCard {
            background-color: #201a12; border: 1px solid #3a2e18;
        }
        QScrollArea#modsPage QLabel#cardCategory { color: #e0a03a; }

        QScrollArea#supportPage { background-color: #1a1214; }
        QScrollArea#supportPage QLabel#pageHeader { color: #e05a5a; }
        QScrollArea#supportPage QFrame#modCard, QScrollArea#supportPage QFrame#guideCard {
            background-color: #221518; border: 1px solid #3c2026;
        }

        QScrollArea#newsPage { background-color: #141118; }
        QScrollArea#newsPage QLabel#pageHeader { color: #b47ef0; }
        QScrollArea#newsPage QFrame#newsCard {
            background-color: #1c1722; border: 1px solid #2e2440;
        }
        QScrollArea#newsPage QFrame#newsThumb {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #2e2440, stop:1 #141118);
        }

        QScrollArea#serversPage { background-color: #10161c; }
        QScrollArea#serversPage QLabel#pageHeader { color: #78a0c8; }
        QScrollArea#serversPage QFrame#modCard, QScrollArea#serversPage QFrame#guideCard {
            background-color: #16202a; border: 1px solid #24374a;
        }

        QScrollArea#learnPage { background-color: #181408; }
        QScrollArea#learnPage QLabel#pageHeader { color: #e6b43c; }
        QScrollArea#learnPage QFrame#modCard {
            background-color: #201a10; border: 1px solid #3c3014;
        }

        QScrollArea#fanartsPage { background-color: #161014; }
        QScrollArea#fanartsPage QLabel#pageHeader { color: #ff8ac2; }

        QScrollArea#setupPage { background-color: #141416; }
        QScrollArea#setupPage QLabel#pageHeader { color: #b0b0b0; }
        QScrollArea#setupPage QFrame#setupCard {
            background-color: #1c1c20; border: 1px solid #2c2c34;
        }

        /* Buttons (NiceButton paints itself — no rules needed) */
        QPushButton#dialogBtnSecondary, QPushButton#modLinkBtn {
            background-color: #2a2a2a;
            color: #d0d0d0;
            border: none;
            border-radius: 6px;
            padding: 12px 20px;
            font-size: 12px; font-weight: 600; letter-spacing: 1px;
        }
        QPushButton#modLinkBtn { padding: 6px 14px; font-size: 10px; }
        QPushButton#dialogBtnSecondary:hover, QPushButton#modLinkBtn:hover {
            background-color: #343434; color: #ffffff;
        }
        QPushButton#dialogBtn {
            background-color: #44a02d;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            padding: 10px 22px;
            font-size: 12px; font-weight: bold; letter-spacing: 1px;
        }
        QPushButton#dialogBtn:hover { background-color: #52b83c; }

        QComboBox#versionCombo {
            background-color: rgba(22, 22, 22, 235);
            color: #ffffff;
            border: 1px solid #3a3a3a;
            border-radius: 6px;
            padding: 10px 14px;
            font-size: 13px;
        }
        QComboBox#versionCombo:hover { border-color: #44a02d; }
        QComboBox#versionCombo::drop-down { border: none; width: 28px; }
        QComboBox#versionCombo QAbstractItemView {
            background-color: #202020;
            color: #e8e8e8;
            selection-background-color: #24371b;
            selection-color: #7dd069;
            border: 1px solid #333333;
            outline: none;
            padding: 4px;
        }

        QProgressBar#mcProgress, QProgressBar {
            background-color: #262626;
            border: none;
            border-radius: 4px;
            text-align: center;
            color: #e8e8e8;
            font-size: 10px;
            max-height: 10px;
        }
        QProgressBar#mcProgress::chunk, QProgressBar::chunk {
            background-color: #44a02d;
            border-radius: 4px;
        }

        /* Dialogs */
        QLabel#dialogTitle {
            color: #6fcf5a; font-size: 15px; font-weight: bold; letter-spacing: 3px;
        }
        QLabel#dialogTier { color: #ffffff; font-size: 14px; font-weight: 600; }
        QLabel#dialogInfo { color: #a0a0a0; font-size: 11px; }
        QLabel#dialogFeedback { font-size: 11px; min-height: 16px; }
        QLineEdit#licenseInput {
            background-color: #101010;
            color: #ffffff;
            border: 1px solid #333333;
            border-radius: 6px;
            padding: 9px;
            font-size: 13px;
        }
        QLineEdit#licenseInput:focus { border-color: #44a02d; }

        /* Instance editor + dialogs */
        QTabWidget::pane {
            border: 1px solid #2a2a2a; border-radius: 8px; top: -1px;
        }
        QTabBar::tab {
            background: transparent; color: #909090; padding: 8px 16px;
            font-size: 11px; font-weight: 600; letter-spacing: 1px;
        }
        QTabBar::tab:hover { color: #d0d0d0; }
        QTabBar::tab:selected { color: #ffffff; border-bottom: 2px solid #44a02d; }
        QListWidget {
            background-color: #101010; color: #e8e8e8;
            border: 1px solid #333333; border-radius: 6px;
        }
        QListWidget::item { padding: 5px 8px; }
        QListWidget::item:selected { background-color: #24371b; }
        QPlainTextEdit {
            background-color: #101010; color: #c8c8c8;
            border: 1px solid #333333; border-radius: 6px;
            font-family: 'DejaVu Sans Mono', monospace; font-size: 11px;
        }
        QSpinBox {
            background-color: #101010; color: #e8e8e8;
            border: 1px solid #333333; border-radius: 6px; padding: 5px;
        }
        QCheckBox { color: #d0d0d0; spacing: 6px; }

        QSlider::groove:horizontal {
            background: #262626; height: 4px; border-radius: 2px;
        }
        QSlider::handle:horizontal {
            background: #44a02d; width: 12px; margin: -5px 0; border-radius: 6px;
        }
        QSlider::sub-page:horizontal { background: #44a02d; border-radius: 2px; }

        QToolTip {
            background-color: #2a2a2a;
            color: #e8e8e8;
            border: 1px solid #3a3a3a;
            padding: 4px 8px;
        }

        QTreeWidget, QTableWidget, QListWidget#cardsScroll {
            background-color: #101010;
            color: #e8e8e8;
            border: 1px solid #333333;
            outline: none;
        }
        QTreeWidget::item, QListWidget::item { padding: 3px 6px; }
        QTreeWidget::item:selected, QListWidget::item:selected {
            background-color: #24371b;
            color: #ffffff;
        }
        QTreeWidget::item:hover, QListWidget::item:hover { background-color: #1d1d1d; }
        QHeaderView::section {
            background-color: #1a1a1a;
            color: #909090;
            border: none;
            border-bottom: 1px solid #2c2c2c;
            padding: 5px 8px;
            font-size: 11px;
        }

        /* Instance tiles (client grid) */
        QPushButton#instTile {
            background-color: #1c1c1c;
            border: 1px solid #2a2a2a;
            border-radius: 8px;
        }
        QPushButton#instTile:hover { background-color: #242424; border-color: #3a3a3a; }
        QPushButton#instTile:checked {
            background-color: #22301c;
            border: 1px solid #3c8527;
        }
    )"));
}

// ─── Page builders ───────────────────────────────────────────────

QWidget *MainWindow::buildNewsCard(const NewsItem &item, bool featured)
{
    auto *card = new QFrame;
    card->setObjectName(QStringLiteral("newsCard"));
    card->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);

    auto *lay = new QHBoxLayout(card);
    lay->setContentsMargins(14, 14, 14, 14);
    lay->setSpacing(16);

    auto *thumb = new QFrame(card);
    thumb->setObjectName(QStringLiteral("newsThumb"));
    thumb->setFixedSize(featured ? 150 : 110, featured ? 100 : 74);
    auto *thumbLayout = new QVBoxLayout(thumb);
    auto *thumbLogo = new QLabel(thumb);
    thumbLogo->setPixmap(QPixmap(QStringLiteral(":/ebalia.png"))
                             .scaled(featured ? 56 : 40, featured ? 56 : 40,
                                     Qt::KeepAspectRatio, Qt::SmoothTransformation));
    thumbLogo->setAlignment(Qt::AlignCenter);
    thumbLayout->addWidget(thumbLogo);
    lay->addWidget(thumb, 0, Qt::AlignVCenter);

    auto *textCol = new QVBoxLayout;
    textCol->setSpacing(3);

    auto *titleLabel = new QLabel(item.title, card);
    titleLabel->setObjectName(QStringLiteral("newsTitle"));
    auto *dateLabel = new QLabel(item.date, card);
    dateLabel->setObjectName(QStringLiteral("newsDate"));
    auto *excerptLabel = new QLabel(item.excerpt, card);
    excerptLabel->setObjectName(QStringLiteral("newsExcerpt"));
    excerptLabel->setWordWrap(true);

    textCol->addWidget(titleLabel);
    textCol->addWidget(dateLabel);
    textCol->addWidget(excerptLabel);
    textCol->addStretch(1);

    if (!item.url.isEmpty()) {
        auto *more = new NiceButton(QStringLiteral("Read more ↗"), NiceButton::Primary, card);
        more->setFixedHeight(34);
        more->setFixedWidth(140);
        const QString url = item.url;
        connect(more, &QPushButton::clicked, this, [url] {
            QDesktopServices::openUrl(QUrl(url));
        });
        textCol->addWidget(more, 0, Qt::AlignLeft);
    }

    lay->addLayout(textCol, 1);
    return card;
}

QWidget *MainWindow::buildNewsLockCard()
{
    auto *card = new QFrame;
    card->setObjectName(QStringLiteral("newsCard"));
    card->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);

    auto *lay = new QHBoxLayout(card);
    lay->setContentsMargins(14, 14, 14, 14);
    lay->setSpacing(16);

    auto *thumb = new QFrame(card);
    thumb->setObjectName(QStringLiteral("newsThumb"));
    thumb->setFixedSize(110, 74);
    auto *thumbLayout = new QVBoxLayout(thumb);
    auto *thumbLogo = new QLabel(thumb);
    thumbLogo->setPixmap(QPixmap(QStringLiteral(":/ebalia.png"))
                             .scaled(40, 40, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    thumbLogo->setAlignment(Qt::AlignCenter);
    thumbLayout->addWidget(thumbLogo);
    lay->addWidget(thumb, 0, Qt::AlignVCenter);

    auto *textCol = new QVBoxLayout;
    textCol->setSpacing(3);

    auto *titleLabel = new QLabel(QStringLiteral("MEMBERS ONLY"), card);
    titleLabel->setObjectName(QStringLiteral("newsTitle"));
    auto *excerptLabel = new QLabel(
        QStringLiteral("Dev leaks, early builds and announcements are exclusive to Patreon members. "
                       "Link your account to read them live."),
        card);
    excerptLabel->setObjectName(QStringLiteral("newsExcerpt"));
    excerptLabel->setWordWrap(true);

    auto *link = new NiceButton(QStringLiteral("LINK PATREON"), NiceButton::Primary, card);
    link->setFixedSize(150, 34);
    connect(link, &QPushButton::clicked, this, &MainWindow::onLicenseChipClicked);

    textCol->addWidget(titleLabel);
    textCol->addWidget(excerptLabel);
    textCol->addStretch(1);
    textCol->addWidget(link, 0, Qt::AlignLeft);

    lay->addLayout(textCol, 1);
    return card;
}

void MainWindow::rebuildNewsAreas()
{
    const auto clearLayout = [](QVBoxLayout *layout) {
        QLayoutItem *item;
        while ((item = layout->takeAt(0)) != nullptr) {
            if (item->widget())
                item->widget()->deleteLater();
            delete item;
        }
    };
    clearLayout(m_playNewsLayout);
    clearLayout(m_newsLayout);

    if (!newsVisible()) {
        m_playNewsLayout->addWidget(buildNewsLockCard());
        m_newsLayout->addWidget(buildNewsLockCard());
        m_newsLayout->addStretch();
        return;
    }

    const auto items = m_newsManager->items();
    for (int i = 0; i < qMin(2, items.size()); ++i)
        m_playNewsLayout->addWidget(buildNewsCard(items[i], i == 0));

    for (int i = 0; i < items.size(); ++i)
        m_newsLayout->addWidget(buildNewsCard(items[i], i == 0));
    m_newsLayout->addStretch();
}

void MainWindow::buildModsPage()
{
    auto *header = new QLabel(QStringLiteral("MODS — CURATED BY EBALIA"), m_modsScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_modsLayout->addWidget(header);

    // Trailers bundled from the legacy project (converted to mp4)
    static const QHash<QString, QString> trailers = {
        { QStringLiteral("in-your-world"), QStringLiteral(":/videos/in-your-world.mp4") },
        { QStringLiteral("the-silence"),   QStringLiteral(":/videos/the-silence.mp4") },
        { QStringLiteral("ooo-jar"),       QStringLiteral(":/videos/ooo-jar.mp4") },
    };

    const auto mods = m_modManager->getMods();
    for (const ModInfo &m : mods) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("modCard"));
        card->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);

        auto *lay = new QHBoxLayout(card);
        lay->setContentsMargins(14, 12, 16, 12);
        lay->setSpacing(14);

        if (!m.icon.isEmpty()) {
            auto *iconLabel = new QLabel(card);
            iconLabel->setPixmap(QPixmap(QStringLiteral(":/") + m.icon)
                                     .scaled(52, 52, Qt::KeepAspectRatio,
                                             Qt::SmoothTransformation));
            iconLabel->setFixedSize(52, 52);
            iconLabel->setAlignment(Qt::AlignCenter);
            lay->addWidget(iconLabel, 0, Qt::AlignTop);
        }

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);

        auto *nameLabel = new QLabel(m.name, card);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        auto *authorLabel = new QLabel(QStringLiteral("by ") + m.author, card);
        authorLabel->setObjectName(QStringLiteral("cardAuthor"));
        auto *descLabel = new QLabel(m.description, card);
        descLabel->setObjectName(QStringLiteral("cardDesc"));
        descLabel->setWordWrap(true);

        textCol->addWidget(nameLabel);
        textCol->addWidget(authorLabel);
        textCol->addWidget(descLabel);

        if (trailers.contains(m.id)) {
            auto *trailer = new NiceButton(QStringLiteral("▶  TRAILER"), NiceButton::Outline, card);
            trailer->setFixedSize(130, 30);
            const QString title = m.name + QStringLiteral(" — Official Trailer");
            const QString path = trailers[m.id];
            connect(trailer, &QPushButton::clicked, this, [this, title, path] {
                VideoDialog dlg(title, path, this);
                dlg.exec();
            });
            textCol->addWidget(trailer, 0, Qt::AlignLeft);
        }

        lay->addLayout(textCol, 1);

        auto *linkCol = new QVBoxLayout;
        linkCol->setSpacing(6);
        for (const ModLink &link : m.links) {
            auto *btn = new NiceButton(link.label, NiceButton::Secondary, card);
            btn->setFixedSize(110, 28);
            btn->setToolTip(link.url);
            const QString url = link.url;
            connect(btn, &QPushButton::clicked, this, [url] {
                QDesktopServices::openUrl(QUrl(url));
            });
            linkCol->addWidget(btn);
        }
        linkCol->addStretch(1);
        lay->addLayout(linkCol);

        m_modsLayout->addWidget(card);
    }

    m_modsLayout->addStretch();
}

void MainWindow::buildSupportPage()
{
    // ── Community links ──
    auto *header = new QLabel(QStringLiteral("SUPPORT & COMMUNITY"), m_supportScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_supportLayout->addWidget(header);

    struct SupportLink {
        const char *name; const char *desc; const char *url; const char *iconRes;
    };
    static const SupportLink links[] = {
        { "Discord",            "Join the EBALIA community server",
          "https://discord.gg/ZrgMwfdwZB",               ":/brands/discord.svg" },
        { "YouTube",            "Videos, trailers and version showcases",
          "https://www.youtube.com/@EBALIA",             ":/brands/youtube.svg" },
        { "Patreon Membership", "Exclusive, Explicit and Senior tiers",
          "https://www.patreon.com/c/ebalia/membership", ":/brands/patreon.svg" },
        { "Patreon Shop",       "One-time purchases and extras",
          "https://www.patreon.com/c/ebalia/shop",       ":/brands/patreon.svg" },
        { "Alphaver Wiki",      "Lore and docs for the Alpha versions",
          "https://alphaver.miraheze.org/",              nullptr },
    };

    for (const auto &l : links) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("modCard"));
        card->setMinimumHeight(64);

        auto *lay = new QHBoxLayout(card);
        lay->setContentsMargins(14, 10, 16, 10);
        lay->setSpacing(14);

        auto *iconLabel = new QLabel(card);
        if (l.iconRes)
            iconLabel->setPixmap(QPixmap(QLatin1String(l.iconRes))
                                     .scaled(26, 26, Qt::KeepAspectRatio,
                                             Qt::SmoothTransformation));
        else
            iconLabel->setPixmap(icons::wiki(26));
        iconLabel->setFixedSize(26, 26);
        iconLabel->setAlignment(Qt::AlignCenter);
        lay->addWidget(iconLabel, 0, Qt::AlignVCenter);

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);
        auto *nameLabel = new QLabel(QString::fromLatin1(l.name), card);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        auto *descLabel = new QLabel(QString::fromLatin1(l.desc), card);
        descLabel->setObjectName(QStringLiteral("cardDesc"));
        textCol->addWidget(nameLabel);
        textCol->addWidget(descLabel);
        lay->addLayout(textCol, 1);

        auto *btn = new NiceButton(QStringLiteral("OPEN"), NiceButton::Secondary, card);
        btn->setFixedSize(90, 30);
        btn->setToolTip(QString::fromLatin1(l.url));
        const QString url = QString::fromLatin1(l.url);
        connect(btn, &QPushButton::clicked, this, [url] {
            QDesktopServices::openUrl(QUrl(url));
        });
        lay->addWidget(btn, 0, Qt::AlignVCenter);

        m_supportLayout->addWidget(card);
    }

    // ── Ticket guide ──
    auto *ticketHeader = new QLabel(QStringLiteral("OPEN A TICKET"), m_supportScroll);
    ticketHeader->setObjectName(QStringLiteral("sectionHeader"));
    m_supportLayout->addWidget(ticketHeader);

    auto *ticketCard = new QFrame;
    ticketCard->setObjectName(QStringLiteral("guideCard"));
    auto *ticketLay = new QVBoxLayout(ticketCard);
    ticketLay->setContentsMargins(16, 14, 16, 14);
    ticketLay->setSpacing(6);

    const QStringList ticketSteps = {
        QStringLiteral("1.  Join the EBALIA Discord server."),
        QStringLiteral("2.  Go to the #ticket channel (Ticket Tool)."),
        QStringLiteral("3.  Press “Create ticket” and explain your problem."),
        QStringLiteral("4.  An administrator or EBALIA will get back to you as soon as possible."),
    };
    for (const QString &s : ticketSteps) {
        auto *step = new QLabel(s, ticketCard);
        step->setObjectName(QStringLiteral("guideStep"));
        step->setWordWrap(true);
        ticketLay->addWidget(step);
    }
    auto *discordBtn = new NiceButton(QStringLiteral("OPEN DISCORD"), NiceButton::Primary, ticketCard);
    discordBtn->setFixedSize(160, 34);
    connect(discordBtn, &QPushButton::clicked, this, [] {
        QDesktopServices::openUrl(QUrl(QStringLiteral("https://discord.gg/ZrgMwfdwZB")));
    });
    ticketLay->addWidget(discordBtn, 0, Qt::AlignLeft);
    m_supportLayout->addWidget(ticketCard);

    // ── Solutions ──
    auto *solHeader = new QLabel(QStringLiteral("COMMON SOLUTIONS"), m_supportScroll);
    solHeader->setObjectName(QStringLiteral("sectionHeader"));
    m_supportLayout->addWidget(solHeader);

    const auto solutionCard = [this](const QString &title, const QStringList &steps) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("guideCard"));
        auto *lay = new QVBoxLayout(card);
        lay->setContentsMargins(16, 14, 16, 14);
        lay->setSpacing(6);
        auto *t = new QLabel(title, card);
        t->setObjectName(QStringLiteral("cardName"));
        lay->addWidget(t);
        for (const QString &s : steps) {
            auto *step = new QLabel(s, card);
            step->setObjectName(QStringLiteral("guideStep"));
            step->setWordWrap(true);
            lay->addWidget(step);
        }
        m_supportLayout->addWidget(card);
        return lay;
    };

    solutionCard(QStringLiteral("No version works"),
                 { QStringLiteral("The resources were not downloaded or verified correctly, "
                                  "or your antivirus blocked the download server (unknown = normal)."),
                   QStringLiteral("1.  Remove everything: Setup → reinstall Game resources."),
                   QStringLiteral("2.  Temporarily disable your antivirus and download again."),
                   QStringLiteral("3.  Make sure 7-Zip or WinRAR is installed on your main drive."),
                   QStringLiteral("4.  Still stuck? Open a ticket on Discord.") });

    solutionCard(QStringLiteral("Error downloading resources"),
                 { QStringLiteral("1.  Clear all files and download again with the antivirus off."),
                   QStringLiteral("2.  Verify the extraction finished (Setup → Game resources)."),
                   QStringLiteral("3.  If it fails repeatedly, ask on the Discord server.") });

    auto *closeLay = solutionCard(
        QStringLiteral("I can not close the game"),
        { QStringLiteral("The game process is stuck in the background. "
                         "Open the task manager and end java / javaw.") });
#if defined(Q_OS_WIN)
    auto *taskBtn = new NiceButton(QStringLiteral("OPEN TASK MANAGER"), NiceButton::Secondary);
    taskBtn->setFixedSize(200, 32);
    connect(taskBtn, &QPushButton::clicked, this, [] {
        QProcess::startDetached(QStringLiteral("taskmgr"), QStringList());
    });
#else
    auto *taskBtn = new NiceButton(QStringLiteral("OPEN SYSTEM MONITOR"), NiceButton::Secondary);
    taskBtn->setFixedSize(200, 32);
    connect(taskBtn, &QPushButton::clicked, this, [] {
        QProcess::startDetached(QStringLiteral("gnome-system-monitor"), QStringList());
    });
#endif
    closeLay->addWidget(taskBtn, 0, Qt::AlignLeft);

    solutionCard(QStringLiteral("My question is not here"),
                 { QStringLiteral("Open a ticket on the Discord server — "
                                  "an administrator or EBALIA will answer.") });

    m_supportLayout->addStretch();
}

void MainWindow::buildServersPage()
{
    auto *header = new QLabel(QStringLiteral("SERVERS"), m_serversScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_serversLayout->addWidget(header);

    struct ServerJar {
        const char *name; const char *desc; const char *file; const char *url;
    };
    static const ServerJar jars[] = {
        { "Minecraft a1.1.1 Server",
          "Official EBALIA server jar for Minecraft a1.1.1.",
          "a1.1.1_server.jar",
          "https://github.com/nnn83/servidores/releases/download/servidores/a1.1.1_server.jar" },
        { "NSSS Server",
          "Server jar for the NSSS experience (a1.1.11_111-1).",
          "a1.1.11_111-1_server.jar",
          "https://github.com/use300name/nsssserver/releases/download/NSSS-Server/a1.1.11_111-1_server.jar" },
    };

    const QString serversDir = m_versionManager->getDataDir() + QStringLiteral("/servers");

    for (const auto &j : jars) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("modCard"));
        card->setMinimumHeight(84);

        auto *lay = new QHBoxLayout(card);
        lay->setContentsMargins(14, 12, 16, 12);
        lay->setSpacing(14);

        auto *iconLabel = new QLabel(card);
        iconLabel->setPixmap(icons::server(30));
        iconLabel->setFixedSize(30, 30);
        iconLabel->setAlignment(Qt::AlignCenter);
        lay->addWidget(iconLabel, 0, Qt::AlignTop);

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);
        auto *nameLabel = new QLabel(QString::fromLatin1(j.name), card);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        auto *descLabel = new QLabel(QString::fromLatin1(j.desc), card);
        descLabel->setObjectName(QStringLiteral("cardDesc"));
        descLabel->setWordWrap(true);
        auto *statusLabel = new QLabel(QString(), card);
        statusLabel->setObjectName(QStringLiteral("cardDesc"));
        textCol->addWidget(nameLabel);
        textCol->addWidget(descLabel);
        textCol->addWidget(statusLabel);
        lay->addLayout(textCol, 1);

        auto *btn = new NiceButton(QStringLiteral("DOWNLOAD"), NiceButton::Primary, card);
        btn->setFixedSize(130, 34);
        const QString url  = QString::fromLatin1(j.url);
        const QString dest = serversDir + QLatin1Char('/') + QString::fromLatin1(j.file);
        connect(btn, &QPushButton::clicked, this, [this, url, dest, statusLabel] {
            QDir().mkpath(QFileInfo(dest).absolutePath());
            statusLabel->setText(QStringLiteral("Downloading..."));
            m_serverDl->downloadFile(url, dest);
        });
        lay->addWidget(btn, 0, Qt::AlignVCenter);

        connect(m_serverDl, &DownloadManager::finished, this,
                [statusLabel, dest](const QString &path, bool ok, const QString &err) {
            if (path != dest) return;
            statusLabel->setText(ok ? QStringLiteral("Saved to: ") + dest
                                    : QStringLiteral("Failed: ") + err);
        });

        m_serversLayout->addWidget(card);
    }

    // How to host
    auto *guideHeader = new QLabel(QStringLiteral("HOW TO HOST"), m_serversScroll);
    guideHeader->setObjectName(QStringLiteral("sectionHeader"));
    m_serversLayout->addWidget(guideHeader);

    auto *guide = new QFrame;
    guide->setObjectName(QStringLiteral("guideCard"));
    auto *guideLay = new QVBoxLayout(guide);
    guideLay->setContentsMargins(16, 14, 16, 14);
    guideLay->setSpacing(6);
    const QStringList steps = {
        QStringLiteral("1.  Download the server jar for your version above."),
        QStringLiteral("2.  Put it in an empty folder."),
        QStringLiteral("3.  Run:  java -jar <file>.jar nogui"),
        QStringLiteral("4.  Accept the EULA in eula.txt (eula=true) and run again."),
        QStringLiteral("5.  Share your IP (or use Hamachi/ZeroTier) with your friends."),
    };
    for (const QString &s : steps) {
        auto *step = new QLabel(s, guide);
        step->setObjectName(QStringLiteral("guideStep"));
        step->setWordWrap(true);
        guideLay->addWidget(step);
    }
    m_serversLayout->addWidget(guide);

    // Community servers
    auto *comHeader = new QLabel(QStringLiteral("COMMUNITY SERVERS"), m_serversScroll);
    comHeader->setObjectName(QStringLiteral("sectionHeader"));
    m_serversLayout->addWidget(comHeader);

    auto *comCard = new QFrame;
    comCard->setObjectName(QStringLiteral("guideCard"));
    auto *comLay = new QVBoxLayout(comCard);
    comLay->setContentsMargins(16, 14, 16, 14);
    comLay->setSpacing(6);
    // lifted from the legacy launcher
    for (const QString &ip : { QStringLiteral("erdbeerbaerlp.de:25580"),
                               QStringLiteral("is-very.dog"),
                               QStringLiteral("dantdmjace.org") }) {
        auto *row = new QHBoxLayout;
        auto *ipLabel = new QLabel(ip, comCard);
        ipLabel->setObjectName(QStringLiteral("mono"));
        row->addWidget(ipLabel, 1);
        auto *copy = new NiceButton(QStringLiteral("COPY"), NiceButton::Secondary, comCard);
        copy->setFixedSize(80, 26);
        connect(copy, &QPushButton::clicked, this, [ip] {
            QGuiApplication::clipboard()->setText(ip);
        });
        row->addWidget(copy);
        comLay->addLayout(row);
    }
    m_serversLayout->addWidget(comCard);

    m_serversLayout->addStretch();
}

void MainWindow::buildLearnPage()
{
    auto *header = new QLabel(QStringLiteral("LEARN — FREE COURSES"), m_learnScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_learnLayout->addWidget(header);

    auto *note = new QLabel(
        QStringLiteral("The courses EBALIA used to learn Java and build the mods. "
                       "Hard to find — shared here for the community."), m_learnScroll);
    note->setObjectName(QStringLiteral("cardDesc"));
    note->setWordWrap(true);
    m_learnLayout->addWidget(note);

    struct Course { QString name; QString lang; QString url; };
    static const Course courses[] = {
        { QString::fromUtf8("Java — 127 hour complete course"),       QStringLiteral("ES"), QStringLiteral("https://n9.cl/java127horas") },
        { QString::fromUtf8("Programación ATS — Java"),               QStringLiteral("ES"), QStringLiteral("https://n9.cl/programacionatsjava") },
        { QString::fromUtf8("Java Developer — coding course pack"),   QStringLiteral("ES"), QStringLiteral("https://acortar.link/JavaDeveloper") },
        { QString::fromUtf8("Universidad Java 2021"),                 QStringLiteral("ES"), QStringLiteral("https://acortar.link/UniversidadJava2021") },
        { QString::fromUtf8("Minecraft Modding for Forge — 0 to Pro"), QStringLiteral("EN"),
          QStringLiteral("https://www.youtube.com/results?search_query=minecraft+forge+modding+course+1.20") },
    };

    for (const auto &c : courses) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("modCard"));
        card->setMinimumHeight(64);

        auto *lay = new QHBoxLayout(card);
        lay->setContentsMargins(14, 10, 16, 10);
        lay->setSpacing(14);

        auto *iconLabel = new QLabel(card);
        iconLabel->setPixmap(icons::learn(26));
        iconLabel->setFixedSize(26, 26);
        iconLabel->setAlignment(Qt::AlignCenter);
        lay->addWidget(iconLabel, 0, Qt::AlignVCenter);

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);
        auto *nameLabel = new QLabel(c.name, card);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        auto *langLabel = new QLabel(QStringLiteral("Language: ") + c.lang, card);
        langLabel->setObjectName(QStringLiteral("cardAuthor"));
        textCol->addWidget(nameLabel);
        textCol->addWidget(langLabel);
        lay->addLayout(textCol, 1);

        auto *btn = new NiceButton(QStringLiteral("OPEN"), NiceButton::Secondary, card);
        btn->setFixedSize(90, 30);
        const QString url = c.url;
        connect(btn, &QPushButton::clicked, this, [url] {
            QDesktopServices::openUrl(QUrl(url));
        });
        lay->addWidget(btn, 0, Qt::AlignVCenter);

        m_learnLayout->addWidget(card);
    }

    m_learnLayout->addStretch();
}

void MainWindow::buildFanartsPage()
{
    auto *container = m_fanartsScroll->widget();
    auto *outer = qobject_cast<QVBoxLayout*>(container->layout());
    outer->setContentsMargins(20, 16, 20, 12);
    outer->setSpacing(10);

    auto *header = new QLabel(QStringLiteral("FAN ARTS"), container);
    header->setObjectName(QStringLiteral("pageHeader"));
    outer->addWidget(header);

    auto *note = new QLabel(
        QStringLiteral("Community art from the EBALIA universe. "
                       "Share yours on the Discord server."), container);
    note->setObjectName(QStringLiteral("cardDesc"));
    outer->addWidget(note);

    struct Fanart { const char *file; const char *artist; };
    static const Fanart arts[] = {
        { "f01", "autumnus_" }, { "f02", "autumnus_" }, { "f03", "autumnus_" },
        { "f04", "autumnus_" }, { "f05", "autumnus_" }, { "f06", "awesomegoat152" },
        { "f07", "awesomegoat152" }, { "f08", "ashorsmth" }, { "f09", "realtbnrsaiyan" },
        { "f10", "ashorsmth" }, { "f11", "has0ne" }, { "f12", "has0ne" },
        { "f13", "ashorsmth" }, { "f14", "malidactae" }, { "f15", "ashorsmth" },
        { "f16", "autumnus_" }, { "f17", "awesomegoat152" }, { "f18", "anonymousbut2nd" },
        { "f19", "anonymousbut2nd" }, { "f20", "autumnus_" },
    };

    auto *grid = new QGridLayout;
    grid->setSpacing(10);
    const int cols = 4;
    for (int i = 0; i < 20; ++i) {
        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("fanartCard"));
        card->setCursor(Qt::PointingHandCursor);
        card->setProperty("fanartFile", QLatin1String(arts[i].file));
        card->setProperty("fanartArtist", QLatin1String(arts[i].artist));
        card->installEventFilter(this);
        auto *lay = new QVBoxLayout(card);
        lay->setContentsMargins(6, 6, 6, 6);
        lay->setSpacing(4);

        auto *img = new QLabel(card);
        img->setPixmap(QPixmap(QStringLiteral(":/fanarts/%1.png").arg(QLatin1String(arts[i].file)))
                           .scaled(220, 160, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        img->setAlignment(Qt::AlignCenter);
        img->setMinimumHeight(120);
        lay->addWidget(img);

        auto *credit = new QLabel(QStringLiteral("Artist: ") + QLatin1String(arts[i].artist), card);
        credit->setObjectName(QStringLiteral("fanartCredit"));
        credit->setAlignment(Qt::AlignCenter);
        lay->addWidget(credit);

        grid->addWidget(card, i / cols, i % cols);
    }
    outer->addLayout(grid);

    // Credits — fan artists + original version creators (from the legacy credits page)
    auto *credHeader = new QLabel(QStringLiteral("CREDITS"), container);
    credHeader->setObjectName(QStringLiteral("sectionHeader"));
    outer->addWidget(credHeader);

    auto *credCard = new QFrame;
    credCard->setObjectName(QStringLiteral("guideCard"));
    auto *credLay = new QVBoxLayout(credCard);
    credLay->setContentsMargins(16, 14, 16, 14);
    credLay->setSpacing(6);

    auto *artistsLabel = new QLabel(
        QStringLiteral("Fan artists: autumnus_ · Has0ne · Niravixis · ashorsmth · "
                       "awesomegoat152 · realtbnrsaiyan · malidactae · anonymousbut2nd"),
        credCard);
    artistsLabel->setObjectName(QStringLiteral("guideStep"));
    artistsLabel->setWordWrap(true);
    credLay->addWidget(artistsLabel);

    auto *creatorsLabel = new QLabel(
        QStringLiteral("Creators of the original versions: Locod (Minecraft 1.7.10) · "
                       "Ext 16.05 Team (Alpha 1.0.16.05_20)"),
        credCard);
    creatorsLabel->setObjectName(QStringLiteral("guideStep"));
    creatorsLabel->setWordWrap(true);
    credLay->addWidget(creatorsLabel);

    auto *footnote = new QLabel(
        QStringLiteral("It has been thoroughly researched to give credit to the original "
                       "creators who appear here. Want your fan art featured? Share it on Discord."),
        credCard);
    footnote->setObjectName(QStringLiteral("cardDesc"));
    footnote->setWordWrap(true);
    credLay->addWidget(footnote);

    outer->addWidget(credCard);
    outer->addStretch();
}

void MainWindow::buildSetupPage()
{
    auto *header = new QLabel(QStringLiteral("SETUP — DEPENDENCIES"), m_setupScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_setupLayout->addWidget(header);

    auto *note = new QLabel(
        QStringLiteral("Everything the lost versions need to run. Install once and forget."),
        m_setupScroll);
    note->setObjectName(QStringLiteral("cardDesc"));
    m_setupLayout->addWidget(note);

    for (DependencyManager::Dep dep : { DependencyManager::Dep::Java,
                                        DependencyManager::Dep::Jarfix,
                                        DependencyManager::Dep::OpenAL,
                                        DependencyManager::Dep::Resources }) {
        const int depId = static_cast<int>(dep);
        const bool supported = DependencyManager::depSupportedOnThisOS(dep);

        auto *card = new QFrame;
        card->setObjectName(QStringLiteral("setupCard"));
        card->setMinimumHeight(76);

        auto *lay = new QHBoxLayout(card);
        lay->setContentsMargins(16, 12, 16, 12);
        lay->setSpacing(14);

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);

        auto *nameLabel = new QLabel(DependencyManager::depName(dep), card);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        auto *descLabel = new QLabel(DependencyManager::depDescription(dep), card);
        descLabel->setObjectName(QStringLiteral("cardDesc"));
        descLabel->setWordWrap(true);

        auto *statusLabel = new QLabel(card);
        statusLabel->setProperty("depId", depId);
        statusLabel->setProperty("role", QStringLiteral("status"));

        auto *bar = new QProgressBar(card);
        bar->setRange(0, 100);
        bar->setFixedHeight(8);
        bar->setTextVisible(false);
        bar->setProperty("depId", depId);
        bar->setProperty("role", QStringLiteral("bar"));
        bar->hide();

        textCol->addWidget(nameLabel);
        textCol->addWidget(descLabel);
        textCol->addWidget(statusLabel);
        textCol->addWidget(bar);
        lay->addLayout(textCol, 1);

        auto *btn = new NiceButton(QStringLiteral("INSTALL"), NiceButton::Primary, card);
        btn->setFixedSize(130, 34);
        btn->setProperty("depId", depId);
        btn->setProperty("role", QStringLiteral("button"));
        if (supported) {
            connect(btn, &QPushButton::clicked, this, [this, dep] {
                m_depManager->install(dep);
            });
        } else {
            btn->setEnabled(false);
            btn->setText(QStringLiteral("WINDOWS ONLY"));
            statusLabel->setText(QStringLiteral("Only needed on Windows"));
        }
        lay->addWidget(btn, 0, Qt::AlignVCenter);

        m_setupLayout->addWidget(card);
    }

    m_setupLayout->addStretch();

    // Initial statuses
    QTimer::singleShot(0, this, [this] {
        for (auto *lbl : m_setupScroll->findChildren<QLabel*>()) {
            if (lbl->property("role").toString() != QLatin1String("status")) continue;
            const auto dep = static_cast<DependencyManager::Dep>(lbl->property("depId").toInt());
            if (!DependencyManager::depSupportedOnThisOS(dep))
                continue; // keeps its "Only needed on Windows" text
            const bool ok = m_depManager->isInstalled(dep);
            lbl->setText(ok ? QStringLiteral("INSTALLED") : QStringLiteral("MISSING"));
            lbl->setObjectName(ok ? QStringLiteral("cardOk") : QStringLiteral("cardMissing"));
            lbl->style()->unpolish(lbl);
            lbl->style()->polish(lbl);
        }
    });

    connect(m_depManager, &DependencyManager::progress, this,
            [this](DependencyManager::Dep dep, int pct, const QString &stage) {
        const int id = static_cast<int>(dep);
        for (auto *bar : m_setupScroll->findChildren<QProgressBar*>()) {
            if (bar->property("depId").toInt() == id) {
                bar->show();
                bar->setValue(pct);
            }
        }
        for (auto *lbl : m_setupScroll->findChildren<QLabel*>()) {
            if (lbl->property("depId").toInt() == id &&
                lbl->property("role").toString() == QLatin1String("status")) {
                lbl->setText(QStringLiteral("%1 — %2%").arg(stage).arg(pct));
            }
        }
    });

    connect(m_depManager, &DependencyManager::installed, this,
            [this](DependencyManager::Dep dep) {
        const int id = static_cast<int>(dep);
        for (auto *lbl : m_setupScroll->findChildren<QLabel*>()) {
            if (lbl->property("depId").toInt() == id &&
                lbl->property("role").toString() == QLatin1String("status")) {
                lbl->setText(QStringLiteral("INSTALLED"));
                lbl->setObjectName(QStringLiteral("cardOk"));
                lbl->style()->unpolish(lbl);
                lbl->style()->polish(lbl);
            }
        }
        for (auto *bar : m_setupScroll->findChildren<QProgressBar*>()) {
            if (bar->property("depId").toInt() == id)
                bar->hide();
        }
    });

    connect(m_depManager, &DependencyManager::failed, this,
            [this](DependencyManager::Dep dep, const QString &err) {
        const int id = static_cast<int>(dep);
        for (auto *lbl : m_setupScroll->findChildren<QLabel*>()) {
            if (lbl->property("depId").toInt() == id &&
                lbl->property("role").toString() == QLatin1String("status")) {
                lbl->setText(QStringLiteral("FAILED — ") + err);
                lbl->setObjectName(QStringLiteral("cardError"));
                lbl->style()->unpolish(lbl);
                lbl->style()->polish(lbl);
            }
        }
    });
}

// ─── Versions ────────────────────────────────────────────────────

void MainWindow::loadVersions()
{
    m_versionManager->loadVersions();
    refreshCombo();
    refreshCards();

    const auto versions = m_versionManager->getVersions();

    int toSelect = -1;
    if (m_selectedIndex >= 0 && m_selectedIndex < versions.size()) {
        toSelect = m_selectedIndex;
    } else {
        QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        const QString last = s.value(QStringLiteral("lastVersion")).toString();
        for (int i = 0; i < versions.size(); ++i) {
            if (versions[i].id == last) { toSelect = i; break; }
        }
        if (toSelect < 0 && !versions.isEmpty())
            toSelect = 0;
    }
    selectVersion(toSelect);
}

void MainWindow::refreshCombo()
{
    QSignalBlocker blocker(m_versionCombo);
    m_versionCombo->clear();

    const auto versions = m_versionManager->getVersions();
    for (int i = 0; i < versions.size(); ++i) {
        const VersionInfo &v = versions[i];
        QString text = v.name;
        if (m_versionManager->isVersionInstalled(v))
            text += QStringLiteral("   ✓");
        m_versionCombo->addItem(text, i);
    }
}

void MainWindow::refreshCards()
{
    QLayoutItem *item;
    while ((item = m_cardsLayout->takeAt(0)) != nullptr) {
        if (item->widget())
            item->widget()->deleteLater();
        delete item;
    }
    m_cards.clear();

    const auto versions = m_versionManager->getVersions();

    for (int i = 0; i < versions.size(); ++i) {
        const VersionInfo &v = versions[i];

        if (!m_currentCategory.isEmpty() &&
            v.category.compare(m_currentCategory, Qt::CaseInsensitive) != 0)
            continue;

        const bool installed = m_versionManager->isVersionInstalled(v);

        VersionCard card;
        card.versionIndex = i;

        card.frame = new QFrame(m_cardsContainer);
        card.frame->setObjectName(QStringLiteral("versionCard"));
        card.frame->setCursor(Qt::PointingHandCursor);
        card.frame->setProperty("versionIndex", i);
        card.frame->setProperty("selected", m_selectedIndex == i);
        card.frame->setMinimumHeight(70);

        auto *cardLayout = new QHBoxLayout(card.frame);
        cardLayout->setContentsMargins(14, 10, 16, 10);
        cardLayout->setSpacing(14);

        // Category pixel icon
        auto *iconLabel = new QLabel(card.frame);
        QPixmap catIcon;
        if (v.category.compare(QStringLiteral("horror"), Qt::CaseInsensitive) == 0)
            catIcon = icons::horror(30);
        else if (v.category.compare(QStringLiteral("release"), Qt::CaseInsensitive) == 0)
            catIcon = icons::release(30);
        else
            catIcon = icons::alpha(30);
        iconLabel->setPixmap(catIcon);
        iconLabel->setFixedSize(30, 30);
        iconLabel->setAlignment(Qt::AlignCenter);
        cardLayout->addWidget(iconLabel, 0, Qt::AlignVCenter);

        auto *textCol = new QVBoxLayout;
        textCol->setSpacing(2);

        auto *nameRow = new QHBoxLayout;
        nameRow->setSpacing(8);
        auto *catLabel = new QLabel(v.category.toUpper(), card.frame);
        catLabel->setObjectName(QStringLiteral("cardCategory"));
        auto *nameLabel = new QLabel(v.name, card.frame);
        nameLabel->setObjectName(QStringLiteral("cardName"));
        nameRow->addWidget(catLabel);
        nameRow->addWidget(nameLabel);
        nameRow->addStretch(1);

        auto *descLabel = new QLabel(v.description, card.frame);
        descLabel->setObjectName(QStringLiteral("cardDesc"));

        textCol->addLayout(nameRow);
        textCol->addWidget(descLabel);
        cardLayout->addLayout(textCol, 1);

        card.statusLabel = new QLabel(
            installed ? QStringLiteral("INSTALLED") : QStringLiteral("NOT INSTALLED"),
            card.frame);
        card.statusLabel->setObjectName(installed ? QStringLiteral("cardInstalled")
                                                  : QStringLiteral("cardNotInstalled"));
        cardLayout->addWidget(card.statusLabel, 0, Qt::AlignVCenter);

        // Per-version install folder
        auto *folderBtn = new QPushButton(card.frame);
        folderBtn->setIcon(QIcon(icons::folder(16)));
        folderBtn->setIconSize(QSize(16, 16));
        folderBtn->setFixedSize(30, 26);
        folderBtn->setObjectName(QStringLiteral("modLinkBtn"));
        folderBtn->setCursor(Qt::PointingHandCursor);
        const QString installPath = m_versionManager->getInstallPath(v);
        folderBtn->setToolTip(installPath);
        connect(folderBtn, &QPushButton::clicked, this, [installPath] {
            QDir().mkpath(installPath);
            QDesktopServices::openUrl(QUrl::fromLocalFile(installPath));
        });
        cardLayout->addWidget(folderBtn, 0, Qt::AlignVCenter);

        card.frame->installEventFilter(this);

        m_cardsLayout->addWidget(card.frame);
        m_cards.append(card);
    }

    m_cardsLayout->addStretch();
}

bool MainWindow::newsVisible() const
{
    return LicenseManager::tierRank(m_licenseManager->tier())
           >= LicenseManager::tierRank(LicenseManager::Tier::Exclusive);
}

void MainWindow::selectVersion(int index)
{
    m_selectedIndex = index;

    {
        QSignalBlocker blocker(m_versionCombo);
        for (int row = 0; row < m_versionCombo->count(); ++row) {
            if (m_versionCombo->itemData(row).toInt() == index) {
                m_versionCombo->setCurrentIndex(row);
                break;
            }
        }
    }

    for (const VersionCard &card : m_cards) {
        const bool isSel = (card.versionIndex == index);
        card.frame->setProperty("selected", isSel);
        card.frame->style()->unpolish(card.frame);
        card.frame->style()->polish(card.frame);
    }

    const auto versions = m_versionManager->getVersions();
    if (index < 0 || index >= versions.size()) {
        m_heroCategory->setText(QStringLiteral("LIBRARY"));
        m_heroStatus->setText(QString());
        m_heroStatus->setProperty("state", QString());
        m_playButton->setEnabled(false);
        m_installButton->setEnabled(false);
        return;
    }

    const VersionInfo &v = versions[index];
    const bool installed = m_versionManager->isVersionInstalled(v);

    updateHero(v, installed);

    m_playButton->setEnabled(installed);
    m_installButton->setEnabled(!installed);

    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    s.setValue(QStringLiteral("lastVersion"), v.id);
}

void MainWindow::updateHero(const VersionInfo &v, bool installed)
{
    m_heroCategory->setText(v.category.toUpper() + QStringLiteral("   •   ") + v.name);

    QString state;
    QString text;
    if (installed) {
        state = QStringLiteral("ready");
        text  = QStringLiteral("Ready to play");
    } else {
        state = QStringLiteral("info");
        text  = QStringLiteral("Not installed — press INSTALL to download");
    }
    m_heroStatus->setText(text);
    m_heroStatus->setProperty("state", state);
    m_heroStatus->style()->unpolish(m_heroStatus);
    m_heroStatus->style()->polish(m_heroStatus);
}

void MainWindow::updateLicenseChip()
{
    const LicenseManager::Tier t = m_licenseManager->tier();
    const QString name = LicenseManager::tierName(t);
    QString text = name;
    if (m_licenseManager->isLinked() && !m_licenseManager->patronName().isEmpty()) {
        // Elide so the chip never clips inside the sidebar
        QString patron = m_licenseManager->patronName();
        if (patron.length() > 10)
            patron = patron.left(9) + QStringLiteral("…");
        text = patron + QStringLiteral(" · ") + name;
    }
    m_licenseChip->setText(text);
    m_licenseChip->setToolTip(m_licenseManager->isLinked()
                                  ? m_licenseManager->patronName() + QStringLiteral(" — ") + name
                                  : QStringLiteral("Membership"));
    m_licenseChip->setProperty("tier", name.toLower());
    m_licenseChip->style()->unpolish(m_licenseChip);
    m_licenseChip->style()->polish(m_licenseChip);
}

// ─── Connections ─────────────────────────────────────────────────

void MainWindow::connectSignals()
{
    connect(m_sideHome, &QPushButton::clicked, this, &MainWindow::onSideHome);
    connect(m_sideAll, &QPushButton::clicked, this, &MainWindow::onSideAll);
    connect(m_sideAlpha, &QPushButton::clicked, this, &MainWindow::onSideAlpha);
    connect(m_sideHorror, &QPushButton::clicked, this, &MainWindow::onSideHorror);
    connect(m_sideRelease, &QPushButton::clicked, this, &MainWindow::onSideRelease);

    connect(m_tabPlay, &QPushButton::clicked, this, &MainWindow::onTabPlay);
    connect(m_tabVersions, &QPushButton::clicked, this, &MainWindow::onTabVersions);
    connect(m_tabMods, &QPushButton::clicked, this, &MainWindow::onTabMods);
    connect(m_tabSupport, &QPushButton::clicked, this, &MainWindow::onTabSupport);
    connect(m_tabNews, &QPushButton::clicked, this, &MainWindow::onTabNews);

    connect(m_playButton, &QPushButton::clicked, this, &MainWindow::onPlayClicked);
    connect(m_installButton, &QPushButton::clicked, this, &MainWindow::onInstallClicked);
    connect(m_licenseChip, &QPushButton::clicked, this, &MainWindow::onLicenseChipClicked);
    connect(m_updateChip, &QPushButton::clicked, this, &MainWindow::onUpdateClicked);

    connect(m_versionCombo, &QComboBox::activated,
            this, &MainWindow::onComboActivated);

    // Mode switch
    connect(m_modeLost, &QPushButton::clicked, this, &MainWindow::onModeLost);
    connect(m_modeClient, &QPushButton::clicked, this, &MainWindow::onModeClient);

    // Client mode plumbing
    connect(m_mcManager, &McInstanceManager::manifestReady,
            this, [this](const QList<McVersion> &v) { m_mcVersions = v; });
    connect(m_mcManager, &McInstanceManager::installProgress, this,
            [this](const QString &dir, int pct, const QString &stage) {
        for (auto *lbl : m_clientPage->findChildren<QLabel*>()) {
            if (lbl->property("instDir").toString() == dir) {
                lbl->setVisible(true);
                lbl->setText(QStringLiteral("%1 — %2%").arg(stage).arg(pct));
            }
        }
        for (auto *bar : m_clientPage->findChildren<QProgressBar*>()) {
            if (bar->property("instDir").toString() == dir) {
                bar->setVisible(true);
                bar->setValue(pct);
            }
        }
    });
    connect(m_mcManager, &McInstanceManager::installDone,
            this, [this](const QString &dir, bool ok, const QString &err) {
        refreshInstances();
        if (!ok) {
            QMessageBox::warning(this, QStringLiteral("Install failed"),
                                 QStringLiteral("%1\n\n%2").arg(dir, err));
        }
    });

    // Playtime tracking (instance.json lastPlayed/totalSecs)
    connect(m_mcManager, &McInstanceManager::gameStarted,
            this, [this](const QString &dir) {
        const qint64 now = QDateTime::currentSecsSinceEpoch();
        m_playStarts[dir] = now;
        QFile f(dir + QStringLiteral("/instance.json"));
        if (f.open(QIODevice::ReadOnly)) {
            QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
            f.close();
            o[QStringLiteral("lastPlayed")] = now;
            QFile out(dir + QStringLiteral("/instance.json"));
            if (out.open(QIODevice::WriteOnly)) {
                out.write(QJsonDocument(o).toJson());
                out.close();
            }
        }
        if (m_stack->currentWidget() == m_clientPage)
            refreshInstances();   // reveal the KILL button

        QSettings gs(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        if (gs.value(QStringLiteral("mc/hideOnPlay"), false).toBool())
            hide();
    });
    connect(m_mcManager, &McInstanceManager::gameEnded,
            this, [this](const QString &dir, int code) {
        const qint64 started = m_playStarts.take(dir);
        if (started > 0) {
            const qint64 played = QDateTime::currentSecsSinceEpoch() - started;
            QFile f(dir + QStringLiteral("/instance.json"));
            if (f.open(QIODevice::ReadOnly)) {
                QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
                f.close();
                o[QStringLiteral("totalSecs")] =
                    o[QStringLiteral("totalSecs")].toVariant().toLongLong() + played;
                QFile out(dir + QStringLiteral("/instance.json"));
                if (out.open(QIODevice::WriteOnly)) {
                    out.write(QJsonDocument(o).toJson());
                    out.close();
                }
            }
        }
        if (m_stack->currentWidget() == m_clientPage)
            refreshInstances();

        QSettings gs(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        show(); // in case it was hidden while playing

        // Crash → show the log (if enabled)
        if (code != 0 && gs.value(QStringLiteral("mc/showLogOnCrash"), false).toBool()) {
            QFile lf(dir + QStringLiteral("/logs/latest.log"));
            QString text = QStringLiteral("(no log found)");
            if (lf.open(QIODevice::ReadOnly)) {
                const QByteArray all = lf.readAll();
                text = QString::fromUtf8(all.right(16000)); // tail
                lf.close();
            }
            QDialog dlg(this);
            dlg.setWindowTitle(QStringLiteral("Game crashed — latest.log"));
            dlg.resize(760, 480);
            auto *lay = new QVBoxLayout(&dlg);
            auto *view = new QPlainTextEdit(&dlg);
            view->setReadOnly(true);
            view->setPlainText(text);
            view->setStyleSheet(QStringLiteral(
                "font-family: 'DejaVu Sans Mono', monospace; font-size: 11px;"));
            lay->addWidget(view);
            auto *close = new NiceButton(QStringLiteral("CLOSE"), NiceButton::Secondary, &dlg);
            close->setFixedSize(110, 32);
            connect(close, &QPushButton::clicked, &dlg, &QDialog::accept);
            lay->addWidget(close, 0, Qt::AlignRight);
            dlg.exec();
        }
    });

    connect(m_licenseManager, &LicenseManager::licenseChanged,
            this, &MainWindow::onLicenseChanged);

    connect(m_newsManager, &NewsManager::newsLoaded,
            this, &MainWindow::rebuildNewsAreas);

    connect(m_patreonAuth, &PatreonAuth::identityReady,
            this, [this](const QString &name, int rank, const QString &) {
        m_licenseManager->linkPatreon(name, rank);
    });

    connect(m_updateChecker, &UpdateChecker::updateAvailable,
            this, [this](const QString &label) {
        m_updateChip->setText(QStringLiteral("Update: ") + label);
        m_updateChip->show();
    });

    connect(m_downloadManager, &DownloadManager::progress,
            this, [this](qint64 recv, qint64 total) {
        if (total > 0) {
            int pct = static_cast<int>(recv * 100 / total);
            m_progressBar->setValue(pct);
            m_progressBar->setFormat(QStringLiteral("%1%").arg(pct));
        }
    });

    connect(m_downloadManager, &DownloadManager::finished,
            this, [this](const QString &filePath, bool ok, const QString &err) {
        Q_UNUSED(filePath)
        m_progressBar->hide();

        if (ok) {
            m_heroStatus->setText(QStringLiteral("Download complete"));
            loadVersions();
        } else {
            m_heroStatus->setText(err.contains(QStringLiteral("404"))
                                      ? QStringLiteral("Files missing on the server — EBALIA is re-uploading them")
                                      : QStringLiteral("Download failed: ") + err);
            m_installButton->setEnabled(true);
        }
    });

    connect(m_javaRunner, &JavaRunner::javaFound,
            this, [this](const QString &path) { m_javaPath = path; });

    connect(m_javaRunner, &JavaRunner::javaNotFound, this, [this] {
        if (m_heroStatus->text().isEmpty())
            m_heroStatus->setText(QStringLiteral("Java not found — install it from SETUP"));
    });

    connect(m_javaRunner, &JavaRunner::processStarted, this, [this] {
        m_heroStatus->setText(QStringLiteral("Game running..."));
    });

    connect(m_javaRunner, &JavaRunner::processFinished, this, [this](int code) {
        m_heroStatus->setText(QStringLiteral("Game closed (code %1)").arg(code));
        m_playButton->setEnabled(true);
    });

    connect(m_javaRunner, &JavaRunner::processError, this, [this](const QString &err) {
        m_heroStatus->setText(QStringLiteral("Launch error: ") + err);
        m_playButton->setEnabled(true);
    });
}

// ─── Navigation ──────────────────────────────────────────────────

void MainWindow::applyTheme(QWidget *page, const QString &theme)
{
    page->setProperty("theme", theme);
    page->style()->unpolish(page);
    page->style()->polish(page);
    const auto children = page->findChildren<QWidget*>();
    for (auto *w : children) {
        w->style()->unpolish(w);
        w->style()->polish(w);
    }
}

void MainWindow::showPage(QWidget *page, QPushButton *tab)
{
    m_stack->setCurrentWidget(page);
    for (auto *t : { m_tabPlay, m_tabVersions, m_tabMods, m_tabSupport, m_tabNews })
        t->setChecked(t == tab);
}

void MainWindow::setSideChecked(QPushButton *active)
{
    for (auto *b : { m_sideHome, m_sideAll, m_sideAlpha, m_sideHorror, m_sideRelease })
        b->setChecked(b == active);
}

void MainWindow::showVersionsCategory(QPushButton *side, const QString &category)
{
    setSideChecked(side);
    m_currentCategory = category;
    m_versionsHeader->setText(category.isEmpty()
                                  ? QStringLiteral("ALL VERSIONS")
                                  : category.toUpper());
    applyTheme(m_versionsPage, category.isEmpty() ? QStringLiteral("all") : category);
    showPage(m_versionsPage, m_tabVersions);
    refreshCards();
}

void MainWindow::onTabPlay()     { showPage(m_playPage, m_tabPlay);         setSideChecked(m_sideHome); }
void MainWindow::onTabVersions() { showVersionsCategory(m_sideAll, QString()); }
void MainWindow::onTabMods()     { showPage(m_modsScroll, m_tabMods);       setSideChecked(nullptr); }
void MainWindow::onTabSupport()  { showPage(m_supportScroll, m_tabSupport); setSideChecked(nullptr); }
void MainWindow::onTabNews()     { showPage(m_newsScroll, m_tabNews);       setSideChecked(nullptr); }
void MainWindow::onTabServers()  { showPage(m_serversScroll, nullptr);      setSideChecked(nullptr); }
void MainWindow::onTabLearn()    { showPage(m_learnScroll, nullptr);        setSideChecked(nullptr); }
void MainWindow::onTabFanarts()  { showPage(m_fanartsScroll, nullptr);      setSideChecked(nullptr); }
void MainWindow::onTabSetup()    { showPage(m_setupScroll, nullptr);        setSideChecked(nullptr); }
void MainWindow::onTabSettings() { showPage(m_settingsScroll, nullptr);     setSideChecked(nullptr); }

void MainWindow::onSideHome()
{
    setSideChecked(m_sideHome);
    showPage(m_playPage, m_tabPlay);
}

void MainWindow::onSideAll()     { showVersionsCategory(m_sideAll, QString()); }
void MainWindow::onSideAlpha()   { showVersionsCategory(m_sideAlpha, QStringLiteral("alpha")); }
void MainWindow::onSideHorror()  { showVersionsCategory(m_sideHorror, QStringLiteral("horror")); }
void MainWindow::onSideRelease() { showVersionsCategory(m_sideRelease, QStringLiteral("release")); }

// ─── Slots ───────────────────────────────────────────────────────

void MainWindow::onComboActivated(int row)
{
    const int index = m_versionCombo->itemData(row).toInt();
    selectVersion(index);
}

void MainWindow::onLicenseChipClicked()
{
    LicenseDialog dlg(m_licenseManager, m_patreonAuth, this);
    dlg.exec();
}

void MainWindow::onUpdateClicked()
{
    UpdateDialog dlg(m_updateChecker, this);
    dlg.exec();
}

void MainWindow::onLicenseChanged()
{
    updateLicenseChip();
    rebuildNewsAreas();
    m_newsManager->refresh();
    refreshCards();
    selectVersion(m_selectedIndex);
}

void MainWindow::onPlayClicked()
{
    if (m_selectedIndex < 0) return;
    const auto versions = m_versionManager->getVersions();
    if (m_selectedIndex >= versions.size()) return;

    const VersionInfo &v = versions[m_selectedIndex];
    QString dir = m_versionManager->getInstallPath(v);

    m_playButton->setEnabled(false);
    m_heroStatus->setText(QStringLiteral("Launching ") + v.name + QStringLiteral("..."));
    m_javaRunner->launch(v, dir);
}

void MainWindow::onInstallClicked()
{
    if (m_selectedIndex < 0) return;
    const auto versions = m_versionManager->getVersions();
    if (m_selectedIndex >= versions.size()) return;

    const VersionInfo &v = versions[m_selectedIndex];
    QString dest = QDir::tempPath() + QStringLiteral("/ebalia_") + v.id + QStringLiteral(".zip");

    m_progressBar->setValue(0);
    m_progressBar->setFormat(QStringLiteral("%p%"));
    m_progressBar->show();
    m_playButton->setEnabled(false);
    m_installButton->setEnabled(false);
    m_heroStatus->setText(QStringLiteral("Downloading ") + v.name + QStringLiteral("..."));

    m_downloadManager->downloadFile(v.downloadUrl, dest);
}

// ─── Event filter (card clicks) ─────────────────────────────────

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonRelease) {
        auto *frame = qobject_cast<QFrame*>(watched);
        if (frame && frame->objectName() == QStringLiteral("versionCard")) {
            QVariant idx = frame->property("versionIndex");
            if (idx.isValid())
                selectVersion(idx.toInt());
            return true;
        }
        if (frame && frame->objectName() == QStringLiteral("fanartCard")) {
            // Enlarge the fan art in a dialog
            const QString file = frame->property("fanartFile").toString();
            const QString artist = frame->property("fanartArtist").toString();
            QPixmap p(QStringLiteral(":/fanarts/%1.png").arg(file));
            if (!p.isNull()) {
                QDialog dlg(this);
                dlg.setWindowTitle(QStringLiteral("Artist: ") + artist);
                auto *lay = new QVBoxLayout(&dlg);
                auto *img = new QLabel(&dlg);
                img->setPixmap(p.scaled(880, 620, Qt::KeepAspectRatio,
                                        Qt::SmoothTransformation));
                img->setAlignment(Qt::AlignCenter);
                lay->addWidget(img);
                auto *credit = new QLabel(QStringLiteral("Artist: ") + artist, &dlg);
                credit->setObjectName(QStringLiteral("dialogTier"));
                credit->setAlignment(Qt::AlignCenter);
                lay->addWidget(credit);
                dlg.exec();
            }
            return true;
        }
    }
    return QMainWindow::eventFilter(watched, event);
}

// ─── Settings ────────────────────────────────────────────────────

void MainWindow::buildSettingsPage()
{
    auto *header = new QLabel(QStringLiteral("SETTINGS"), m_settingsScroll);
    header->setObjectName(QStringLiteral("pageHeader"));
    m_settingsLayout->addWidget(header);

    // ── Language ──
    auto *langCard = new QFrame;
    langCard->setObjectName(QStringLiteral("setupCard"));
    auto *langLay = new QHBoxLayout(langCard);
    langLay->setContentsMargins(16, 12, 16, 12);

    auto *langTextCol = new QVBoxLayout;
    auto *langName = new QLabel(QStringLiteral("Language / Idioma"), langCard);
    langName->setObjectName(QStringLiteral("cardName"));
    auto *langDesc = new QLabel(QStringLiteral("Interface language. Applies instantly."), langCard);
    langDesc->setObjectName(QStringLiteral("cardDesc"));
    langTextCol->addWidget(langName);
    langTextCol->addWidget(langDesc);
    langLay->addLayout(langTextCol, 1);

    auto *langCombo = new QComboBox(langCard);
    langCombo->setObjectName(QStringLiteral("versionCombo"));
    langCombo->addItem(QStringLiteral("English"),   QStringLiteral("en"));
    langCombo->addItem(QStringLiteral("Español"),   QStringLiteral("es"));
    langCombo->addItem(QStringLiteral("Português"), QStringLiteral("pt"));
    langCombo->addItem(QStringLiteral("Français"),  QStringLiteral("fr"));
    langCombo->addItem(QStringLiteral("Deutsch"),   QStringLiteral("de"));
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    const QString curLang = s.value(QStringLiteral("language"),
                                    QStringLiteral("en")).toString();
    langCombo->setCurrentIndex(qMax(0, langCombo->findData(curLang)));
    connect(langCombo, &QComboBox::activated, this, [this, langCombo](int row) {
        QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s2.setValue(QStringLiteral("language"), langCombo->itemData(row).toString());
        retranslateUi();
    });
    langLay->addWidget(langCombo, 0, Qt::AlignVCenter);
    m_settingsLayout->addWidget(langCard);

    // ── Verify resources ──
    auto *verCard = new QFrame;
    verCard->setObjectName(QStringLiteral("setupCard"));
    auto *verLay = new QHBoxLayout(verCard);
    verLay->setContentsMargins(16, 12, 16, 12);

    auto *verTextCol = new QVBoxLayout;
    auto *verName = new QLabel(QStringLiteral("Verify resources"), verCard);
    verName->setObjectName(QStringLiteral("cardName"));
    auto *verStatus = new QLabel(QStringLiteral("Check Java, tools and game packs."), verCard);
    verStatus->setObjectName(QStringLiteral("cardDesc"));
    verStatus->setWordWrap(true);
    verTextCol->addWidget(verName);
    verTextCol->addWidget(verStatus);
    verLay->addLayout(verTextCol, 1);

    auto *verBtn = new NiceButton(QStringLiteral("VERIFY"), NiceButton::Primary, verCard);
    verBtn->setFixedSize(130, 34);
    connect(verBtn, &QPushButton::clicked, this, [this, verStatus] {
        QStringList parts;
        const auto check = [this, &parts](DependencyManager::Dep d, const QString &name) {
            const bool ok = m_depManager->isInstalled(d);
            parts += name + (ok ? QStringLiteral(": OK") : QStringLiteral(": MISSING"));
        };
        check(DependencyManager::Dep::Java,      QStringLiteral("Java"));
        check(DependencyManager::Dep::Jarfix,    QStringLiteral("Jarfix"));
        check(DependencyManager::Dep::OpenAL,    QStringLiteral("OpenAL"));
        check(DependencyManager::Dep::Resources, QStringLiteral("Resources"));
        verStatus->setText(parts.join(QStringLiteral("   ·   ")));
    });
    verLay->addWidget(verBtn, 0, Qt::AlignVCenter);
    m_settingsLayout->addWidget(verCard);

    // ── Data folder ──
    auto *dataCard = new QFrame;
    dataCard->setObjectName(QStringLiteral("setupCard"));
    auto *dataLay = new QHBoxLayout(dataCard);
    dataLay->setContentsMargins(16, 12, 16, 12);

    auto *dataTextCol = new QVBoxLayout;
    auto *dataName = new QLabel(QStringLiteral("Data folder"), dataCard);
    dataName->setObjectName(QStringLiteral("cardName"));
    auto *dataPath = new QLabel(m_versionManager->getDataDir(), dataCard);
    dataPath->setObjectName(QStringLiteral("cardDesc"));
    dataPath->setWordWrap(true);
    dataTextCol->addWidget(dataName);
    dataTextCol->addWidget(dataPath);
    dataLay->addLayout(dataTextCol, 1);

    auto *dataBtn = new NiceButton(QStringLiteral("OPEN"), NiceButton::Secondary, dataCard);
    dataBtn->setFixedSize(130, 34);
    connect(dataBtn, &QPushButton::clicked, this, [this] {
        QDesktopServices::openUrl(QUrl::fromLocalFile(m_versionManager->getDataDir()));
    });
    dataLay->addWidget(dataBtn, 0, Qt::AlignVCenter);
    m_settingsLayout->addWidget(dataCard);

    // ── Replay tour ──
    auto *tourCard = new QFrame;
    tourCard->setObjectName(QStringLiteral("setupCard"));
    auto *tourLay = new QHBoxLayout(tourCard);
    tourLay->setContentsMargins(16, 12, 16, 12);

    auto *tourTextCol = new QVBoxLayout;
    auto *tourName = new QLabel(QStringLiteral("First-run tour"), tourCard);
    tourName->setObjectName(QStringLiteral("cardName"));
    auto *tourDesc = new QLabel(QStringLiteral("Silence walks you through the launcher again."), tourCard);
    tourDesc->setObjectName(QStringLiteral("cardDesc"));
    tourTextCol->addWidget(tourName);
    tourTextCol->addWidget(tourDesc);
    tourLay->addLayout(tourTextCol, 1);

    auto *tourBtn = new NiceButton(QStringLiteral("REPLAY"), NiceButton::Secondary, tourCard);
    tourBtn->setFixedSize(130, 34);
    connect(tourBtn, &QPushButton::clicked, this, [this] {
        QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s2.remove(QStringLiteral("tour/done"));
        maybeStartTour();
    });
    tourLay->addWidget(tourBtn, 0, Qt::AlignVCenter);
    m_settingsLayout->addWidget(tourCard);

    // ── CurseForge API key ──
    auto *cfCard = new QFrame;
    cfCard->setObjectName(QStringLiteral("setupCard"));
    auto *cfLay = new QHBoxLayout(cfCard);
    cfLay->setContentsMargins(16, 12, 16, 12);

    auto *cfTextCol = new QVBoxLayout;
    auto *cfName = new QLabel(QStringLiteral("CurseForge API key"), cfCard);
    cfName->setObjectName(QStringLiteral("cardName"));
    auto *cfDesc = new QLabel(
        QStringLiteral("Used for the CurseForge modpack source. "
                       "Get one at console.curseforge.com."), cfCard);
    cfDesc->setObjectName(QStringLiteral("cardDesc"));
    cfTextCol->addWidget(cfName);
    cfTextCol->addWidget(cfDesc);
    cfLay->addLayout(cfTextCol, 1);

    auto *cfKey = new QLineEdit(cfCard);
    cfKey->setObjectName(QStringLiteral("licenseInput"));
    cfKey->setFixedWidth(280);
    cfKey->setPlaceholderText(QStringLiteral("$2a$10$…"));
    cfKey->setText(s.value(QStringLiteral("curseforge/apikey")).toString());
    connect(cfKey, &QLineEdit::editingFinished, this, [cfKey] {
        QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s2.setValue(QStringLiteral("curseforge/apikey"), cfKey->text().trimmed());
    });
    cfLay->addWidget(cfKey, 0, Qt::AlignVCenter);
    m_settingsLayout->addWidget(cfCard);

    // ── Java (Prism-style global defaults) ──
    auto *javaCard = new QFrame;
    javaCard->setObjectName(QStringLiteral("setupCard"));
    auto *javaLay = new QHBoxLayout(javaCard);
    javaLay->setContentsMargins(16, 12, 16, 12);

    auto *javaTextCol = new QVBoxLayout;
    auto *javaName = new QLabel(QStringLiteral("Java (default)"), javaCard);
    javaName->setObjectName(QStringLiteral("cardName"));
    auto *javaDesc = new QLabel(QStringLiteral("Used when an instance has no Java override."), javaCard);
    javaDesc->setObjectName(QStringLiteral("cardDesc"));
    javaTextCol->addWidget(javaName);
    javaTextCol->addWidget(javaDesc);

    auto *javaCombo = new QComboBox(javaCard);
    javaCombo->setObjectName(QStringLiteral("versionCombo"));
    javaCombo->setMinimumWidth(220);
    javaCombo->addItem(QStringLiteral("Auto (first found)"), QString());
    {
        JavaRunner probe;
        for (const QString &j : probe.findJava())
            javaCombo->addItem(j, j);
        const QString cur = s.value(QStringLiteral("mc/defaultJava")).toString();
        if (!cur.isEmpty() && javaCombo->findData(cur) < 0)
            javaCombo->insertItem(1, cur, cur);
        javaCombo->setCurrentIndex(qMax(0, javaCombo->findData(cur)));
    }
    javaTextCol->addWidget(javaCombo);
    javaLay->addLayout(javaTextCol, 1);

    auto *ramCol = new QVBoxLayout;
    auto *ramLbl = new QLabel(QStringLiteral("Default RAM (MB)"), javaCard);
    ramLbl->setObjectName(QStringLiteral("cardName"));
    ramCol->addWidget(ramLbl);
    auto *ramSpin = new QSpinBox(javaCard);
    ramSpin->setRange(512, 32768);
    ramSpin->setSingleStep(256);
    ramSpin->setValue(s.value(QStringLiteral("mc/defaultXmx"), 2048).toInt());
    ramCol->addWidget(ramSpin);
    javaLay->addLayout(ramCol);
    m_settingsLayout->addWidget(javaCard);

    connect(javaCombo, &QComboBox::activated, this, [javaCombo](int row) {
        QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s2.setValue(QStringLiteral("mc/defaultJava"), javaCombo->itemData(row).toString());
    });
    connect(ramSpin, &QSpinBox::valueChanged, this, [](int v) {
        QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
        s2.setValue(QStringLiteral("mc/defaultXmx"), v);
    });

    // ── Behavior (Prism window/console options) ──
    auto *behCard = new QFrame;
    behCard->setObjectName(QStringLiteral("setupCard"));
    auto *behLay = new QVBoxLayout(behCard);
    behLay->setContentsMargins(16, 12, 16, 12);
    behLay->setSpacing(6);

    auto *behName = new QLabel(QStringLiteral("Behavior"), behCard);
    behName->setObjectName(QStringLiteral("cardName"));
    behLay->addWidget(behName);

    auto mkCheck = [&behLay, &behCard, &s](const QString &text, const QString &key) {
        auto *cb = new QCheckBox(text, behCard);
        cb->setStyleSheet(QStringLiteral("color:#d0d0d0; font-size:12px;"));
        cb->setChecked(s.value(key, false).toBool());
        connect(cb, &QCheckBox::toggled, [key](bool on) {
            QSettings s2(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
            s2.setValue(key, on);
        });
        behLay->addWidget(cb);
    };
    mkCheck(QStringLiteral("Hide the launcher while a game runs"),
            QStringLiteral("mc/hideOnPlay"));
    mkCheck(QStringLiteral("Show the game log when it crashes"),
            QStringLiteral("mc/showLogOnCrash"));
    m_settingsLayout->addWidget(behCard);

    m_settingsLayout->addStretch();
}

void MainWindow::retranslateUi()
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    const QString lang = s.value(QStringLiteral("language"),
                                 QStringLiteral("en")).toString();

    struct L {
        const char *home; const char *all; const char *horror;
        const char *play; const char *versions; const char *support; const char *news;
        const char *playBtn; const char *installBtn;
    };
    static const QHash<QString, L> langs = {
        { "en", { "HOME", "ALL VERSIONS", "HORROR", "Play", "Versions", "Support",
                  "Patch Notes", "PLAY", "INSTALL" } },
        { "es", { "INICIO", "TODAS", "TERROR", "Jugar", "Versiones", "Soporte",
                  "Notas", "JUGAR", "INSTALAR" } },
        { "pt", { "INÍCIO", "TODAS", "TERROR", "Jogar", "Versões", "Suporte",
                  "Notas", "JOGAR", "INSTALAR" } },
        { "fr", { "ACCUEIL", "TOUTES", "HORREUR", "Jouer", "Versions", "Support",
                  "Notes", "JOUER", "INSTALLER" } },
        { "de", { "START", "ALLE", "HORROR", "Spielen", "Versionen", "Support",
                  "Hinweise", "SPIELEN", "INSTALLIEREN" } },
    };
    const L &l = langs.value(lang, langs[QStringLiteral("en")]);

    const auto T = [](const char *s2) { return QString::fromUtf8(s2); };
    const QString two = QStringLiteral("  ");
    m_sideHome->setText(two    + T(l.home));
    m_sideAll->setText(two     + T(l.all));
    m_sideHorror->setText(two  + T(l.horror));
    m_tabPlay->setText(T(l.play));
    m_tabVersions->setText(T(l.versions));
    m_tabSupport->setText(T(l.support));
    m_tabNews->setText(T(l.news));
    m_playButton->setText(T(l.playBtn));
    m_installButton->setText(T(l.installBtn));

    if (m_currentCategory.isEmpty())
        m_versionsHeader->setText(T(l.all));
}

void MainWindow::maybeStartTour()
{
    QSettings s(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    if (s.value(QStringLiteral("tour/done"), false).toBool())
        return;

    onSideHome(); // start from the play page

    auto *tour = new TourOverlay(this);
    // Each step jumps to the page it describes
    connect(tour, &TourOverlay::stepChanged, this, [this](int idx) {
        switch (idx) {
        case 0: onSideHome();   break;  // welcome → play
        case 1: onSideAll();    break;  // library → versions
        case 2: onSideHome();   break;  // play controls
        case 3: onTabMods();    break;  // community → mods
        case 4: onSideHome();   break;  // membership chip lives in the sidebar
        }
    });
    tour->start();
}

// ─── Client mode (vanilla Minecraft instances) ──────────────────

void MainWindow::onModeLost()
{
    m_modeLost->setChecked(true);
    m_modeClient->setChecked(false);
    showPage(m_playPage, m_tabPlay);
    setSideChecked(m_sideHome);
}

void MainWindow::onModeClient()
{
    m_modeLost->setChecked(false);
    m_modeClient->setChecked(true);
    setSideChecked(nullptr);
    for (auto *t : { m_tabPlay, m_tabVersions, m_tabMods, m_tabSupport, m_tabNews })
        t->setChecked(false);
    m_stack->setCurrentWidget(m_clientPage);
    refreshInstances();
}

void MainWindow::refreshInstances()
{
    // Rebuild by REPLACING the page widget — takeAt() leaks children (ghosting)
    const int idx = m_stack->indexOf(m_clientPage);
    m_stack->removeWidget(m_clientPage);
    m_clientPage->deleteLater();

    m_clientPage = new QWidget;
    m_clientPage->setObjectName(QStringLiteral("cardsContainer"));
    auto *lay = new QVBoxLayout(m_clientPage);
    lay->setSpacing(8);
    lay->setContentsMargins(16, 12, 16, 10);
    m_stack->insertWidget(idx, m_clientPage);
    m_stack->setCurrentWidget(m_clientPage);

    // ── Toolbar ──
    auto *toolbar = new QHBoxLayout;
    toolbar->setSpacing(8);

    auto *newBtn = new NiceButton(QStringLiteral("＋ NUEVA INSTANCIA"), NiceButton::Primary, m_clientPage);
    newBtn->setFixedSize(190, 36);
    connect(newBtn, &QPushButton::clicked, this, &MainWindow::onNewInstance);
    toolbar->addWidget(newBtn);

    auto *folderBtn = new NiceButton(QStringLiteral("CARPETA"), NiceButton::Secondary, m_clientPage);
    folderBtn->setFixedSize(120, 36);
    connect(folderBtn, &QPushButton::clicked, this, [this] {
        QDesktopServices::openUrl(QUrl::fromLocalFile(m_mcManager->instancesRoot()));
    });
    toolbar->addWidget(folderBtn);

    toolbar->addStretch(1);

    m_accountCombo = new QComboBox(m_clientPage);
    m_accountCombo->setObjectName(QStringLiteral("versionCombo"));
    m_accountCombo->setMinimumWidth(190);
    connect(m_accountCombo, &QComboBox::activated, this, [this](int row) {
        m_accountManager->setActive(m_accountCombo->itemData(row).toString());
    });
    toolbar->addWidget(m_accountCombo);

    auto *msBtn = new NiceButton(QStringLiteral("+ MICROSOFT"), NiceButton::Secondary, m_clientPage);
    msBtn->setFixedSize(130, 36);
    connect(msBtn, &QPushButton::clicked, this, &MainWindow::onAddMsAccount);
    toolbar->addWidget(msBtn);

    auto *offBtn = new NiceButton(QStringLiteral("+ OFFLINE"), NiceButton::Secondary, m_clientPage);
    offBtn->setFixedSize(110, 36);
    connect(offBtn, &QPushButton::clicked, this, &MainWindow::onAddOfflineAccount);
    toolbar->addWidget(offBtn);

    lay->addLayout(toolbar);
    refreshAccountCombo();

    // ── Grid + action panel ──
    auto *midRow = new QHBoxLayout;
    midRow->setSpacing(10);

    auto *gridScroll = new QScrollArea(m_clientPage);
    gridScroll->setObjectName(QStringLiteral("cardsScroll"));
    gridScroll->setWidgetResizable(true);
    gridScroll->setFrameShape(QFrame::NoFrame);
    auto *gridContainer = new QWidget;
    gridContainer->setObjectName(QStringLiteral("cardsContainer"));
    auto *grid = new QGridLayout(gridContainer);
    grid->setSpacing(10);
    grid->setContentsMargins(4, 4, 4, 4);
    grid->setAlignment(Qt::AlignLeft | Qt::AlignTop);
    gridScroll->setWidget(gridContainer);
    midRow->addWidget(gridScroll, 1);

    const auto list = m_mcManager->instances();
    if (list.isEmpty()) {
        auto *empty = new QLabel(
            QStringLiteral("No instances yet — press NUEVA INSTANCIA to create one."),
            gridContainer);
        empty->setObjectName(QStringLiteral("cardDesc"));
        empty->setAlignment(Qt::AlignCenter);
        grid->addWidget(empty, 0, 0);
    }

    const int cols = 6;
    for (int i = 0; i < list.size(); ++i) {
        const McInstance &in = list[i];

        auto *tile = new QPushButton(gridContainer);
        tile->setObjectName(QStringLiteral("instTile"));
        tile->setCheckable(true);
        tile->setFixedSize(150, 118);
        tile->setCursor(Qt::PointingHandCursor);
        tile->setProperty("instDir", in.dir);
        tile->setChecked(in.dir == m_selectedInstanceDir);

        auto *tileLay = new QVBoxLayout(tile);
        tileLay->setContentsMargins(8, 8, 8, 8);
        tileLay->setSpacing(4);

        auto *ico = new QLabel(tile);
        ico->setPixmap(icons::alpha(52));
        ico->setAlignment(Qt::AlignCenter);
        tileLay->addWidget(ico);

        auto *nameLbl = new QLabel(in.name, tile);
        nameLbl->setObjectName(QStringLiteral("cardDesc"));
        nameLbl->setAlignment(Qt::AlignCenter);
        nameLbl->setWordWrap(true);
        tileLay->addWidget(nameLbl);

        // Per-instance download progress (shown while installing)
        auto *bar = new QProgressBar(tile);
        bar->setObjectName(QStringLiteral("mcProgress"));
        bar->setRange(0, 100);
        bar->setFixedHeight(8);
        bar->setTextVisible(false);
        bar->setProperty("instDir", in.dir);
        bar->setProperty("role", QStringLiteral("bar"));
        bar->hide();
        tileLay->addWidget(bar);

        const QString dir = in.dir;
        connect(tile, &QPushButton::clicked, this, [this, dir] {
            selectInstance(dir);
        });

        grid->addWidget(tile, i / cols, i % cols);
    }

    // Right action panel (Prism style)
    auto *panel = new QFrame(m_clientPage);
    panel->setObjectName(QStringLiteral("modCard"));
    panel->setFixedWidth(230);
    auto *panelLay = new QVBoxLayout(panel);
    panelLay->setContentsMargins(14, 14, 14, 14);
    panelLay->setSpacing(6);

    McInstance sel;
    bool found = false;
    for (const McInstance &in : list)
        if (in.dir == m_selectedInstanceDir) { sel = in; found = true; break; }

    if (!found) {
        auto *hint = new QLabel(QStringLiteral("Select an instance"), panel);
        hint->setObjectName(QStringLiteral("cardDesc"));
        hint->setAlignment(Qt::AlignCenter);
        panelLay->addWidget(hint);
        panelLay->addStretch(1);
    } else {
        auto *bigIco = new QLabel(panel);
        bigIco->setPixmap(icons::alpha(64));
        bigIco->setAlignment(Qt::AlignCenter);
        panelLay->addWidget(bigIco);

        auto *nameLbl = new QLabel(sel.name, panel);
        nameLbl->setObjectName(QStringLiteral("cardName"));
        nameLbl->setAlignment(Qt::AlignCenter);
        nameLbl->setWordWrap(true);
        panelLay->addWidget(nameLbl);

        auto *metaLbl = new QLabel(sel.mcVersion + QStringLiteral(" • ") + sel.loader, panel);
        metaLbl->setObjectName(QStringLiteral("cardCategory"));
        metaLbl->setAlignment(Qt::AlignCenter);
        panelLay->addWidget(metaLbl);

        panelLay->addSpacing(6);

        const QString dir = sel.dir;
        const bool ready = sel.ready;
        const bool running = m_mcManager->isRunning(dir);

        auto mkAction = [panel](const QString &text, bool primary = false) {
            auto *b = new NiceButton(text, primary ? NiceButton::Primary
                                                   : NiceButton::Secondary, panel);
            b->setFixedHeight(32);
            return b;
        };

        if (running) {
            auto *killBtn = mkAction(QStringLiteral("FORZAR CIERRE"));
            connect(killBtn, &QPushButton::clicked, this, [this, dir] {
                m_mcManager->killInstance(dir);
                selectInstance(dir);
            });
            panelLay->addWidget(killBtn);
        }

        auto *playBtn = mkAction(ready ? QStringLiteral("LANZAR")
                                       : QStringLiteral("INSTALAR"), true);
        connect(playBtn, &QPushButton::clicked, this, [this, dir] {
            launchInstance(dir);
        });
        panelLay->addWidget(playBtn);

        auto *editBtn = mkAction(QStringLiteral("EDITAR"));
        connect(editBtn, &QPushButton::clicked, this, [this, sel] {
            EditInstanceDialog dlg(sel, m_mcManager, m_mcVersions, this);
            dlg.exec();
            refreshInstances();
        });
        panelLay->addWidget(editBtn);

        auto *folderB = mkAction(QStringLiteral("CARPETA"));
        connect(folderB, &QPushButton::clicked, this, [dir] {
            QDesktopServices::openUrl(QUrl::fromLocalFile(dir));
        });
        panelLay->addWidget(folderB);

        auto *exportBtn = mkAction(QStringLiteral("EXPORTAR"));
        connect(exportBtn, &QPushButton::clicked, this, [this, sel] {
            const QString out = QFileDialog::getSaveFileName(
                this, QStringLiteral("Export instance"),
                QDir::homePath() + QLatin1Char('/') + sel.name + QStringLiteral(".zip"),
                QStringLiteral("Zip (*.zip)"));
            if (out.isEmpty())
                return;
            QProcess p;
            p.start(QStringLiteral("bsdtar"),
                    { QStringLiteral("-acf"), out,
                      QStringLiteral("-C"), QFileInfo(sel.dir).absolutePath(),
                      QFileInfo(sel.dir).fileName() });
            if (!p.waitForStarted(3000))
                p.start(QStringLiteral("zip"),
                        { QStringLiteral("-r"), out,
                          QFileInfo(sel.dir).fileName() });
            p.waitForFinished(-1);
        });
        panelLay->addWidget(exportBtn);

        auto *copyBtn = mkAction(QStringLiteral("COPIAR"));
        connect(copyBtn, &QPushButton::clicked, this, [this, sel] {
            const QString dst = sel.dir + QStringLiteral(" (copia)");
            QProcess::startDetached(QStringLiteral("cp"),
                                    { QStringLiteral("-r"), sel.dir, dst });
            QTimer::singleShot(900, this, [this] { refreshInstances(); });
        });
        panelLay->addWidget(copyBtn);

        auto *shortcutBtn = mkAction(QStringLiteral("CREAR ATAJO"));
        connect(shortcutBtn, &QPushButton::clicked, this, [this, sel] {
#if defined(Q_OS_LINUX)
            const QString desk = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation)
                + QLatin1Char('/') + sel.name + QStringLiteral(".desktop");
            QFile f(desk);
            if (f.open(QIODevice::WriteOnly)) {
                f.write(QStringLiteral(
                    "[Desktop Entry]\nType=Application\nName=%1\n"
                    "Comment=EBALIA instance\nExec=ebalia-launcher\n"
                    "Categories=Game;\n").arg(sel.name).toUtf8());
                f.close();
            }
#endif
        });
        panelLay->addWidget(shortcutBtn);

        auto *delBtn = mkAction(QStringLiteral("BORRAR"));
        connect(delBtn, &QPushButton::clicked, this, [this, dir] {
            m_mcManager->deleteInstance(dir);
            m_selectedInstanceDir.clear();
            refreshInstances();
        });
        panelLay->addWidget(delBtn);

        panelLay->addStretch(1);
    }

    midRow->addWidget(panel);
    lay->addLayout(midRow, 1);

    // ── Status bar ──
    auto *statusBar = new QLabel(m_clientPage);
    statusBar->setObjectName(QStringLiteral("cardDesc"));
    QString stext = QStringLiteral("No hay una instancia seleccionada");
    if (found) {
        QFile f(sel.dir + QStringLiteral("/instance.json"));
        if (f.open(QIODevice::ReadOnly)) {
            const QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
            const QString last = o[QStringLiteral("lastPlayed")].toString();
            const qint64 secs = o[QStringLiteral("totalSecs")].toVariant().toLongLong();
            stext = QStringLiteral("%1 — última vez: %2 — jugado total: %3 min")
                        .arg(sel.name,
                             last.isEmpty() ? QStringLiteral("nunca") : last)
                        .arg(secs / 60);
        }
    }
    statusBar->setText(stext);
    lay->addWidget(statusBar);

    // Minecraft news (compact, below)
    auto *newsHeader = new QLabel(QStringLiteral("MINECRAFT NEWS"), m_clientPage);
    newsHeader->setObjectName(QStringLiteral("sectionHeader"));
    lay->addWidget(newsHeader);

    m_clientNewsLayout = new QVBoxLayout;
    m_clientNewsLayout->setSpacing(8);
    lay->addLayout(m_clientNewsLayout);
    fetchMcNews();
}

void MainWindow::selectInstance(const QString &dir)
{
    m_selectedInstanceDir = dir;
    refreshInstances();
}

QFrame *MainWindow::buildInstanceCard(const McInstance &in)
{
    auto *card = new QFrame(m_clientPage);
    card->setObjectName(QStringLiteral("versionCard"));
    card->setMinimumWidth(280);
    card->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);

    auto *cl = new QVBoxLayout(card);
    cl->setContentsMargins(14, 12, 14, 12);
    cl->setSpacing(6);

    auto *row1 = new QHBoxLayout;
    row1->setSpacing(10);
    auto *icon = new QLabel(card);
    icon->setPixmap(icons::alpha(30));
    icon->setFixedSize(30, 30);
    icon->setAlignment(Qt::AlignCenter);
    auto *nameLbl = new QLabel(in.name, card);
    nameLbl->setObjectName(QStringLiteral("cardName"));
    auto *loaderLbl = new QLabel(in.loader.isEmpty()
                                     ? QStringLiteral("VANILLA")
                                     : in.loader.toUpper(), card);
    loaderLbl->setObjectName(QStringLiteral("cardCategory"));
    row1->addWidget(icon);
    row1->addWidget(nameLbl, 1);
    row1->addWidget(loaderLbl);
    cl->addLayout(row1);

    auto *verLbl = new QLabel(QStringLiteral("Minecraft ") + in.mcVersion, card);
    verLbl->setObjectName(QStringLiteral("cardDesc"));
    cl->addWidget(verLbl);

    auto *statusRow = new QHBoxLayout;
    statusRow->setSpacing(8);
    auto *statusLbl = new QLabel(in.ready ? QStringLiteral("READY")
                                          : QStringLiteral("NOT INSTALLED"), card);
    statusLbl->setObjectName(in.ready ? QStringLiteral("cardInstalled")
                                      : QStringLiteral("cardNotInstalled"));
    auto *progLbl = new QLabel(card);
    progLbl->setObjectName(QStringLiteral("cardDesc"));
    progLbl->setProperty("instDir", in.dir);
    progLbl->hide();
    statusRow->addWidget(statusLbl);
    statusRow->addWidget(progLbl, 1);
    cl->addLayout(statusRow);

    auto *btnRow = new QHBoxLayout;
    btnRow->setSpacing(6);

    const bool running = m_mcManager->isRunning(in.dir);

    auto *playBtn = new NiceButton(in.ready ? QStringLiteral("PLAY")
                                            : QStringLiteral("INSTALL"),
                                   NiceButton::Primary, card);
    playBtn->setFixedHeight(30);
    connect(playBtn, &QPushButton::clicked, this, [this, in] {
        if (in.ready)
            launchInstance(in.dir);
        else
            m_mcManager->installInstance(in.dir);
    });
    btnRow->addWidget(playBtn, 1);

    if (running) {
        playBtn->setEnabled(false);
        playBtn->setText(QStringLiteral("RUNNING"));
        auto *killBtn = new NiceButton(QStringLiteral("KILL"), NiceButton::Outline, card);
        killBtn->setFixedHeight(30);
        connect(killBtn, &QPushButton::clicked, this, [this, in] {
            m_mcManager->killInstance(in.dir);
        });
        btnRow->addWidget(killBtn, 1);
    }

    auto *editBtn = new NiceButton(QStringLiteral("EDIT"), NiceButton::Secondary, card);
    editBtn->setFixedHeight(30);
    connect(editBtn, &QPushButton::clicked, this, [this, in] {
        EditInstanceDialog dlg(in, m_mcManager, m_mcVersions, this);
        connect(&dlg, &EditInstanceDialog::playRequested,
                this, [this](const QString &dir) { launchInstance(dir); });
        dlg.exec();
        refreshInstances();
    });
    btnRow->addWidget(editBtn, 1);

    auto *folderBtn = new QPushButton(card);
    folderBtn->setIcon(QIcon(icons::folder(16)));
    folderBtn->setIconSize(QSize(16, 16));
    folderBtn->setFixedSize(30, 30);
    folderBtn->setObjectName(QStringLiteral("modLinkBtn"));
    folderBtn->setCursor(Qt::PointingHandCursor);
    folderBtn->setToolTip(in.dir);
    const QString dir = in.dir;
    connect(folderBtn, &QPushButton::clicked, this, [dir] {
        QDir().mkpath(dir);
        QDesktopServices::openUrl(QUrl::fromLocalFile(dir));
    });
    btnRow->addWidget(folderBtn);

    auto *delBtn = new NiceButton(QStringLiteral("DELETE"), NiceButton::Outline, card);
    delBtn->setFixedHeight(30);
    connect(delBtn, &QPushButton::clicked, this, [this, in] {
        if (QMessageBox::question(this, QStringLiteral("Delete instance"),
                QStringLiteral("Delete \"%1\" and all its files?").arg(in.name))
            != QMessageBox::Yes)
            return;
        m_mcManager->deleteInstance(in.dir);
        refreshInstances();
    });
    btnRow->addWidget(delBtn, 1);

    cl->addLayout(btnRow);
    return card;
}

void MainWindow::launchInstance(const QString &dir)
{
    // Not installed yet → this button means INSTALL
    const auto list = m_mcManager->instances();
    for (const McInstance &in : list) {
        if (in.dir == dir && !in.ready) {
            // Prism-style download screen: live stage + progress
            auto *dlg = new QDialog(this);
            dlg->setWindowTitle(QStringLiteral("Downloading — ") + in.name);
            dlg->setMinimumWidth(420);
            auto *dlay = new QVBoxLayout(dlg);
            auto *stageLbl = new QLabel(QStringLiteral("Starting…"), dlg);
            stageLbl->setObjectName(QStringLiteral("dialogTier"));
            auto *pctLbl = new QLabel(QString(), dlg);
            pctLbl->setObjectName(QStringLiteral("dialogInfo"));
            auto *bar = new QProgressBar(dlg);
            bar->setRange(0, 100);
            bar->setValue(0);
            dlay->addWidget(stageLbl);
            dlay->addWidget(bar);
            dlay->addWidget(pctLbl);

            auto *progConn = new QMetaObject::Connection;
            auto *doneConn = new QMetaObject::Connection;
            *progConn = connect(m_mcManager, &McInstanceManager::installProgress, dlg,
                    [dlg, stageLbl, pctLbl, bar](const QString &d, int pct, const QString &stage) {
                if (d != dlg->property("instDir").toString()) return;
                stageLbl->setText(stage);
                bar->setValue(pct);
                pctLbl->setText(QStringLiteral("%1%").arg(pct));
            });
            dlg->setProperty("instDir", dir);
            *doneConn = connect(m_mcManager, &McInstanceManager::installDone, dlg,
                    [dlg, progConn, doneConn](const QString &d, bool ok, const QString &) {
                if (d != dlg->property("instDir").toString()) return;
                disconnect(*progConn);
                disconnect(*doneConn);
                dlg->close();   // close on success AND failure (error box follows)
            });
            dlg->setAttribute(Qt::WA_DeleteOnClose);
            dlg->show();

            m_mcManager->installInstance(dir);
            return;
        }
    }

    const McAccount acc = m_accountManager->active();
    if (acc.name.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("No account"),
            QStringLiteral("Add a Microsoft or offline account first "
                           "(top of this page)."));
        return;
    }
    const QString userType = acc.type == QStringLiteral("msa")
                                 ? QStringLiteral("msa")
                                 : QStringLiteral("legacy");
    m_mcManager->launch(dir, acc.name, acc.uuid, acc.mcToken, userType);
}

void MainWindow::onNewInstance()
{
    // Make sure the manifest is loaded before the user picks
    if (m_mcVersions.isEmpty()) {
        m_mcManager->fetchManifest();
        connect(m_mcManager, &McInstanceManager::manifestReady, this,
                [this](const QList<McVersion> &) { onNewInstance(); },
                Qt::SingleShotConnection);
        return;
    }

    NewInstanceDialog dlg(m_mcVersions, this);
    if (dlg.exec() != QDialog::Accepted)
        return;

    const QString name   = dlg.instanceName();
    const QString zipIn  = dlg.importZipPath();

    if (!zipIn.isEmpty() && zipIn.endsWith(QStringLiteral(".mrpack"), Qt::CaseInsensitive)) {
        // Modrinth pack: read game version + loader from modrinth.index.json,
        // download every referenced file, then install the game itself
        QString mcVer, loader;
        if (!m_mcManager->mrpackReadInfo(zipIn, mcVer, loader) || mcVer.isEmpty()) {
            mcVer  = dlg.mcVersion();
            loader = dlg.loader();
        }
        m_mcManager->createInstance(name, mcVer, loader, dlg.loaderVersion());
        const QString dir = m_mcManager->instancesRoot() + QLatin1Char('/') + name;
        refreshInstances();
        m_mcManager->installMrpackFiles(dir, zipIn);
        m_mcManager->installInstance(dir);
        return;
    }

    if (!zipIn.isEmpty()) {
        // Modpack import: create the instance, extract the pack into it,
        // and read the CurseForge manifest for the right MC version/loader
        QString mcVer = dlg.mcVersion();
        QString loader = dlg.loader();

        m_mcManager->createInstance(name, mcVer, loader, dlg.loaderVersion());
        const QString dir = m_mcManager->instancesRoot() + QLatin1Char('/') + name;
        McInstanceManager::extractZipTo(zipIn, dir);

        // CurseForge manifest.json → minecraft.version + modLoaders
        QFile mf(dir + QStringLiteral("/manifest.json"));
        if (mf.open(QIODevice::ReadOnly)) {
            const QJsonObject pack = QJsonDocument::fromJson(mf.readAll()).object();
            const QJsonObject mc = pack[QStringLiteral("minecraft")].toObject();
            const QString packVer = mc[QStringLiteral("version")].toString();
            QString packLoader = loader;
            const QJsonArray loaders = mc[QStringLiteral("modLoaders")].toArray();
            for (const QJsonValue &lv : loaders) {
                const QString id = lv.toObject()[QStringLiteral("id")].toString();
                if (id.startsWith(QStringLiteral("fabric")))      packLoader = QStringLiteral("fabric");
                else if (id.startsWith(QStringLiteral("quilt")))  packLoader = QStringLiteral("quilt");
            }
            if (!packVer.isEmpty())
                mcVer = packVer;

            // Rewrite instance.json with the pack's version/loader
            QFile f(dir + QStringLiteral("/instance.json"));
            if (f.open(QIODevice::ReadOnly)) {
                QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
                f.close();
                o[QStringLiteral("mcVersion")] = mcVer;
                o[QStringLiteral("loader")]    = packLoader;
                QFile out(dir + QStringLiteral("/instance.json"));
                if (out.open(QIODevice::WriteOnly)) {
                    out.write(QJsonDocument(o).toJson());
                    out.close();
                }
            }
            mf.close();
        }

        // Non-CurseForge zip or no version info: fall back to latest release
        if (mcVer.isEmpty()) {
            for (const McVersion &v : m_mcVersions)
                if (v.type == QStringLiteral("release")) { mcVer = v.id; break; }
            QFile f(dir + QStringLiteral("/instance.json"));
            if (f.open(QIODevice::ReadOnly)) {
                QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
                f.close();
                o[QStringLiteral("mcVersion")] = mcVer;
                QFile out(dir + QStringLiteral("/instance.json"));
                if (out.open(QIODevice::WriteOnly)) {
                    out.write(QJsonDocument(o).toJson());
                    out.close();
                }
            }
        }
    } else {
        m_mcManager->createInstance(name, dlg.mcVersion(), dlg.loader(), dlg.loaderVersion());
    }

    refreshInstances();
}

void MainWindow::fetchMcNews()
{
    if (!m_clientNewsLayout)
        return;

    auto *nam = new QNetworkAccessManager(this);
    QNetworkRequest req{QUrl(QStringLiteral("https://launchercontent.mojang.com/v2/news.json"))};
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("EBALIA-Launcher/3.0"));

    QNetworkReply *reply = nam->get(req);
    connect(reply, &QNetworkReply::finished, this, [this, reply, nam] {
        reply->deleteLater();
        nam->deleteLater();
        if (reply->error() != QNetworkReply::NoError || !m_clientNewsLayout)
            return;

        const QJsonArray entries = QJsonDocument::fromJson(reply->readAll())
                                       .object()[QStringLiteral("entries")].toArray();
        int shown = 0;
        for (const QJsonValue &ev : entries) {
            if (shown >= 3)
                break;
            const QJsonObject e = ev.toObject();
            NewsItem n;
            n.title   = e[QStringLiteral("title")].toString();
            n.date    = e[QStringLiteral("date")].toString();
            n.excerpt = e[QStringLiteral("text")].toString();
            n.url     = e[QStringLiteral("readMoreLink")].toString();
            if (n.url.isEmpty())
                n.url = e[QStringLiteral("link")].toString();
            if (n.title.isEmpty())
                continue;
            m_clientNewsLayout->addWidget(buildNewsCard(n, shown == 0));
            ++shown;
        }
    });
}

// ─── Account management ─────────────────────────────────────────

void MainWindow::refreshAccountCombo()
{
    if (!m_accountCombo)
        return;
    QSignalBlocker b(m_accountCombo);
    m_accountCombo->clear();
    const auto accs = m_accountManager->accounts();
    const QString activeUuid = m_accountManager->active().uuid;
    int sel = 0;
    for (int i = 0; i < accs.size(); ++i) {
        const McAccount &a = accs[i];
        const QString label = a.name + (a.type == QStringLiteral("msa")
                                            ? QStringLiteral("  ·  Microsoft")
                                            : QStringLiteral("  ·  offline"));
        m_accountCombo->addItem(label, a.uuid);
        if (a.uuid == activeUuid)
            sel = i;
    }
    if (!accs.isEmpty())
        m_accountCombo->setCurrentIndex(sel);
}

void MainWindow::onAddMsAccount()
{
    auto *dlg = new QDialog(this);
    dlg->setWindowTitle(QStringLiteral("Add Microsoft account"));
    dlg->setModal(true);
    dlg->setMinimumWidth(440);

    auto *lay = new QVBoxLayout(dlg);
    lay->setContentsMargins(24, 24, 24, 24);
    lay->setSpacing(12);

    auto *title = new QLabel(QStringLiteral("MICROSOFT LOGIN"), dlg);
    title->setObjectName(QStringLiteral("dialogTitle"));
    title->setAlignment(Qt::AlignCenter);
    lay->addWidget(title);

    auto *codeLabel = new QLabel(QStringLiteral("…"), dlg);
    codeLabel->setObjectName(QStringLiteral("dialogTier"));
    codeLabel->setAlignment(Qt::AlignCenter);
    codeLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    lay->addWidget(codeLabel);

    auto *linkLabel = new QLabel(dlg);
    linkLabel->setObjectName(QStringLiteral("dialogInfo"));
    linkLabel->setAlignment(Qt::AlignCenter);
    linkLabel->setWordWrap(true);
    linkLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    lay->addWidget(linkLabel);

    auto *status = new QLabel(QStringLiteral("Requesting device code..."), dlg);
    status->setObjectName(QStringLiteral("dialogFeedback"));
    status->setAlignment(Qt::AlignCenter);
    lay->addWidget(status);

    auto *auth = new MsAuth(dlg);
    connect(auth, &MsAuth::showCode, dlg, [codeLabel, linkLabel](const QString &code,
                                                                 const QString &url) {
        codeLabel->setText(code);
        linkLabel->setText(QStringLiteral("Go to %1 and enter the code").arg(url));
    });
    connect(auth, &MsAuth::statusUpdate, dlg, [status](const QString &s) {
        status->setText(s);
    });
    connect(auth, &MsAuth::loginFailed, dlg, [status](const QString &err) {
        status->setStyleSheet(QStringLiteral("color:#e05a5a;"));
        status->setText(err);
    });
    connect(auth, &MsAuth::loginDone, this,
            [this, dlg](const QString &mcToken, const QString &refreshToken,
                        const QString &uuid, const QString &name) {
        McAccount acc;
        acc.type         = QStringLiteral("msa");
        acc.name         = name;
        acc.uuid         = uuid;
        acc.mcToken      = mcToken;
        acc.refreshToken = refreshToken;
        m_accountManager->addAccount(acc);
        refreshAccountCombo();
        dlg->accept();
    });

    QTimer::singleShot(0, auth, &MsAuth::startLogin);
    dlg->exec();
}

void MainWindow::onAddOfflineAccount()
{
    QDialog dlg(this);
    dlg.setWindowTitle(QStringLiteral("Add offline account"));
    dlg.setModal(true);
    dlg.setMinimumWidth(360);

    auto *lay = new QVBoxLayout(&dlg);
    lay->setContentsMargins(20, 20, 20, 20);
    lay->setSpacing(10);

    auto *title = new QLabel(QStringLiteral("OFFLINE ACCOUNT"), &dlg);
    title->setObjectName(QStringLiteral("dialogTitle"));
    lay->addWidget(title);

    auto *nameEdit = new QLineEdit(&dlg);
    nameEdit->setObjectName(QStringLiteral("licenseInput"));
    nameEdit->setPlaceholderText(QStringLiteral("Username"));
    lay->addWidget(nameEdit);

    auto *addBtn = new NiceButton(QStringLiteral("ADD"), NiceButton::Primary, &dlg);
    addBtn->setFixedHeight(36);
    lay->addWidget(addBtn);

    connect(addBtn, &QPushButton::clicked, &dlg, [&] {
        const QString name = nameEdit->text().trimmed();
        if (name.isEmpty())
            return;
        McAccount acc;
        acc.type = QStringLiteral("offline");
        acc.name = name;
        acc.uuid = QUuid::createUuid().toString(QUuid::WithoutBraces)
                       .remove(QLatin1Char('-'));
        m_accountManager->addAccount(acc);
        refreshAccountCombo();
        dlg.accept();
    });

    dlg.exec();
}

void MainWindow::onRemoveAccount()
{
    const QString uuid = m_accountCombo ? m_accountCombo->currentData().toString()
                                        : QString();
    if (uuid.isEmpty())
        return;
    m_accountManager->removeAccount(uuid);
    refreshAccountCombo();
}

// Drives the real GUI install path (createInstance + installInstance) with logs
void MainWindow::installSelfTest(const QString &mcver)
{
    const QString name = QStringLiteral("guitest-") + mcver;
    QFile log(QStringLiteral("/tmp/ebalia_install_gui.log"));
    if (log.open(QIODevice::WriteOnly)) {
        log.write("installSelfTest start\n");
        log.close();
    }

    connect(m_mcManager, &McInstanceManager::installProgress, this,
            [](const QString &, int pct, const QString &stage) {
        QFile log(QStringLiteral("/tmp/ebalia_install_gui.log"));
        if (log.open(QIODevice::Append)) {
            log.write(QStringLiteral("%1%% %2\n").arg(pct).arg(stage).toUtf8());
            log.close();
        }
    });
    connect(m_mcManager, &McInstanceManager::installDone, this,
            [](const QString &, bool ok, const QString &err) {
        QFile log(QStringLiteral("/tmp/ebalia_install_gui.log"));
        if (log.open(QIODevice::Append)) {
            log.write(QStringLiteral("DONE ok=%1 err=%2\n").arg(ok).arg(err).toUtf8());
            log.close();
        }
        qApp->quit();
    });

    m_mcManager->createInstance(name, mcver, QStringLiteral("vanilla"));
    m_mcManager->installInstance(m_mcManager->instancesRoot() + QLatin1Char('/') + name);
}
