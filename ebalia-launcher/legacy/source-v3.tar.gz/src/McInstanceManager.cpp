#include "McInstanceManager.hpp"
#include "JavaRunner.hpp"

#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QProcess>
#include <QEventLoop>
#include <QTimer>
#include <QUuid>
#include <QRegularExpression>
#include <QSettings>
#include <QSharedPointer>
#include <functional>

static const char kManifestUrl[] =
    "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
static const char kResourcesBase[] = "https://resources.download.minecraft.net/";

McInstanceManager::McInstanceManager(const QString &dataDir, QObject *parent)
    : QObject(parent)
{
    m_root = dataDir + QStringLiteral("/mc");
    QDir().mkpath(instancesRoot());
    QDir().mkpath(m_root + QStringLiteral("/libraries"));
    QDir().mkpath(m_root + QStringLiteral("/versions"));
    QDir().mkpath(m_root + QStringLiteral("/assets/objects"));
    QDir().mkpath(m_root + QStringLiteral("/assets/indexes"));
}

// ── Live version list (auto-updating by design) ──
void McInstanceManager::fetchManifest()
{
    QNetworkRequest req{QUrl(QString::fromLatin1(kManifestUrl))};
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("EBALIA-Launcher/3.0"));

    QNetworkReply *reply = m_nam.get(req);
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit manifestFailed(reply->errorString());
            return;
        }
        QList<McVersion> out;
        const QJsonArray arr = QJsonDocument::fromJson(reply->readAll())
                                   .object()[QStringLiteral("versions")].toArray();
        for (const QJsonValue &v : arr) {
            const QJsonObject o = v.toObject();
            McVersion mv;
            mv.id   = o[QStringLiteral("id")].toString();
            mv.type = o[QStringLiteral("type")].toString();
            mv.url  = o[QStringLiteral("url")].toString();
            mv.releaseTime = o[QStringLiteral("releaseTime")].toString().left(10);
            out.append(mv);
        }
        emit manifestReady(out);
    });
}

// ── Instances on disk ──
QList<McInstance> McInstanceManager::instances() const
{
    QList<McInstance> out;
    const QDir root(instancesRoot());
    for (const QString &sub : root.entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        QFile f(root.filePath(sub + QStringLiteral("/instance.json")));
        if (!f.open(QIODevice::ReadOnly))
            continue;
        const QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
        McInstance in;
        in.name      = o[QStringLiteral("name")].toString();
        in.dir       = root.filePath(sub);
        in.mcVersion = o[QStringLiteral("mcVersion")].toString();
        in.loader    = o[QStringLiteral("loader")].toString();
        in.ready     = o[QStringLiteral("ready")].toBool();
        in.xmx       = o[QStringLiteral("xmx")].toInt(2048);
        in.lastPlayed = o[QStringLiteral("lastPlayed")].toVariant().toLongLong();
        in.totalSecs  = o[QStringLiteral("totalSecs")].toVariant().toLongLong();
        out.append(in);
    }
    return out;
}

void McInstanceManager::createInstance(const QString &name, const QString &mcVersion,
                                       const QString &loader,
                                       const QString &loaderVersion)
{
    QString safe = name;
    safe.replace(QRegularExpression(QStringLiteral("[^\\w\\-. ]")), QString());
    const QString dir = instancesRoot() + QLatin1Char('/') + safe;
    QDir().mkpath(dir);

    QJsonObject o;
    o[QStringLiteral("name")]      = name;
    o[QStringLiteral("mcVersion")] = mcVersion;
    o[QStringLiteral("loader")]    = loader;
    if (!loaderVersion.isEmpty())
        o[QStringLiteral("loaderVersion")] = loaderVersion;
    o[QStringLiteral("ready")]     = false;
    QFile f(dir + QStringLiteral("/instance.json"));
    if (f.open(QIODevice::WriteOnly)) {
        f.write(QJsonDocument(o).toJson());
        f.close();
    }
}

void McInstanceManager::deleteInstance(const QString &dir)
{
    QDir(dir).removeRecursively();
}

// ── Install: version json → client jar → libraries → assets → natives ──
void McInstanceManager::installInstance(const QString &dir)
{
    QFile f(dir + QStringLiteral("/instance.json"));
    if (!f.open(QIODevice::ReadOnly)) {
        emit installDone(dir, false, QStringLiteral("instance.json missing"));
        return;
    }
    const QJsonObject inst = QJsonDocument::fromJson(f.readAll()).object();
    const QString mcver = inst[QStringLiteral("mcVersion")].toString();

    emit installProgress(dir, 0, QStringLiteral("Fetching version manifest"));
    fetchManifest(); // refresh cache of URLs

    // Find the version URL in the live manifest
    QNetworkRequest req{QUrl(QString::fromLatin1(kManifestUrl))};
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("EBALIA-Launcher/3.0"));
    QNetworkReply *reply = m_nam.get(req);
    connect(reply, &QNetworkReply::finished, this, [this, reply, dir, mcver] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit installDone(dir, false, reply->errorString());
            return;
        }
        QString vurl;
        const QJsonArray arr = QJsonDocument::fromJson(reply->readAll())
                                   .object()[QStringLiteral("versions")].toArray();
        for (const QJsonValue &v : arr) {
            if (v.toObject()[QStringLiteral("id")].toString() == mcver) {
                vurl = v.toObject()[QStringLiteral("url")].toString();
                break;
            }
        }
        if (vurl.isEmpty()) {
            emit installDone(dir, false, QStringLiteral("Version not found in manifest"));
            return;
        }

        emit installProgress(dir, 5, QStringLiteral("Fetching version metadata"));
        QNetworkRequest vreq{QUrl(vurl)};
        vreq.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("EBALIA-Launcher/3.0"));
        QNetworkReply *vreply = m_nam.get(vreq);
        connect(vreply, &QNetworkReply::finished, this, [this, vreply, dir] {
            vreply->deleteLater();
            if (vreply->error() != QNetworkReply::NoError) {
                emit installDone(dir, false, vreply->errorString());
                return;
            }
            installVersionJson(dir, QJsonDocument::fromJson(vreply->readAll()).object());
        });
    });
}

void McInstanceManager::installVersionJson(const QString &dir, const QJsonObject &vjson)
{
    const QString mcver = vjson[QStringLiteral("id")].toString();

    // Mod loader (Fabric/Quilt/Forge/NeoForge): merge its profile into the json
    QFile instF(dir + QStringLiteral("/instance.json"));
    QString loader;
    QString loaderVersion;
    if (instF.open(QIODevice::ReadOnly)) {
        const QJsonObject io = QJsonDocument::fromJson(instF.readAll()).object();
        loader         = io[QStringLiteral("loader")].toString();
        loaderVersion  = io[QStringLiteral("loaderVersion")].toString();
        instF.close();
    }
    QJsonObject merged = vjson;
    if (!loader.isEmpty() && loader != QStringLiteral("vanilla")) {
        emit installProgress(dir, 8, QStringLiteral("Fetching ") + loader +
                                 QStringLiteral(" profile"));
        if (loader == QStringLiteral("forge") || loader == QStringLiteral("neoforge"))
            applyForgeLike(loader, mcver, merged, loaderVersion);
        else
            applyLoader(loader, mcver, merged, loaderVersion);
    }

    // Persist the version json — launch() reads it back. Loader instances get
    // their own id so they never clobber the plain vanilla json.
    QString vid = mcver;
    if (!loader.isEmpty() && loader != QStringLiteral("vanilla"))
        vid = mcver + QLatin1Char('-') + loader;
    const QString vdir = m_root + QStringLiteral("/versions/") + vid;
    QDir().mkpath(vdir);

    QFile vjf(vdir + QStringLiteral("/") + vid + QStringLiteral(".json"));
    if (vjf.open(QIODevice::WriteOnly)) {
        vjf.write(QJsonDocument(merged).toJson());
        vjf.close();
    }

    // Client jar
    const QString jarUrl = merged[QStringLiteral("downloads")].toObject()
                               [QStringLiteral("client")].toObject()
                               [QStringLiteral("url")].toString();
    const QString jarDest = m_root + QStringLiteral("/versions/") + mcver +
                            QStringLiteral("/") + mcver + QStringLiteral(".jar");
    if (!QFile::exists(jarDest)) {
        emit installProgress(dir, 10, QStringLiteral("Downloading client jar"));
        if (!jarUrl.isEmpty() && !downloadFileSync(jarUrl, jarDest)) {
            emit installDone(dir, false, QStringLiteral("Client jar download failed"));
            return;
        }
    }

    downloadLibraries(dir, merged);
}

// Parallel download queue (8 at a time) — sequential downloads took 10+ min
void McInstanceManager::runQueue(const QString &dir, QList<QPair<QString, QString>> jobs,
                                 int pctFrom, int pctTo, const QString &stage, bool failFast,
                                 std::function<void(bool, const QString &)> onDone)
{
    const int total = jobs.size();
    if (total == 0) { onDone(true, QString()); return; }

    auto idx     = QSharedPointer<int>::create(0);
    auto pending = QSharedPointer<int>::create(0);
    auto done    = QSharedPointer<int>::create(0);
    auto failed  = QSharedPointer<QString>::create();
    auto fire    = QSharedPointer<std::function<void()>>::create();

    *fire = [=, this]() {
        while (*pending < 8 && *idx < total) {
            const auto job = jobs.at(*idx);
            ++(*idx);
            ++(*pending);

            QNetworkRequest req{QUrl(job.first)};
            req.setHeader(QNetworkRequest::UserAgentHeader,
                          QStringLiteral("EBALIA-Launcher/3.0"));
            req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                             QNetworkRequest::NoLessSafeRedirectPolicy);

            QNetworkReply *r = m_nam.get(req);
            connect(r, &QNetworkReply::finished, this, [=, this]() {
                r->deleteLater();
                --(*pending);

                if (r->error() == QNetworkReply::NoError) {
                    QDir().mkpath(QFileInfo(job.second).absolutePath());
                    QFile out(job.second);
                    if (out.open(QIODevice::WriteOnly)) {
                        out.write(r->readAll());
                        out.close();
                    }
                } else if (failed->isEmpty()) {
                    *failed = job.first + QStringLiteral(" — ") + r->errorString();
                }

                ++(*done);
                emit installProgress(dir,
                    pctFrom + int((pctTo - pctFrom) * double(*done) / total),
                    stage + QStringLiteral(" %1/%2").arg(*done).arg(total));

                if (*done >= total) {
                    const bool ok = failed->isEmpty() || !failFast;
                    onDone(ok, *failed);
                    return;
                }
                if (failFast && !failed->isEmpty()) {
                    onDone(false, *failed);
                    return;
                }
                (*fire)();
            });
        }
    };
    (*fire)();
}

void McInstanceManager::downloadLibraries(const QString &dir, const QJsonObject &vjson)
{
    QList<QPair<QString, QString>> jobs;
    QList<QPair<QString, QString>> natives;   // jar -> extract dir

    const QJsonArray libs = vjson[QStringLiteral("libraries")].toArray();
    for (const QJsonValue &lv : libs) {
        const QJsonObject lib = lv.toObject();
        if (!allowedByRules(lib))
            continue;

        const QJsonObject downloads = lib[QStringLiteral("downloads")].toObject();
        const QJsonObject artifact = downloads[QStringLiteral("artifact")].toObject();
        if (!artifact.isEmpty()) {
            const QString path = artifact[QStringLiteral("path")].toString();
            const QString dest = m_root + QStringLiteral("/libraries/") + path;
            if (!QFile::exists(dest))
                jobs.append({ artifact[QStringLiteral("url")].toString(), dest });
        }

        const QJsonObject classifiers = downloads[QStringLiteral("classifiers")].toObject();
        const QString nKey = nativesKey();
        if (!nKey.isEmpty() && classifiers.contains(nKey)) {
            const QJsonObject nat = classifiers[nKey].toObject();
            const QString path = nat[QStringLiteral("path")].toString();
            const QString dest = m_root + QStringLiteral("/libraries/") + path;
            const QString natDir = m_root + QStringLiteral("/versions/") +
                vjson[QStringLiteral("id")].toString() + QStringLiteral("/natives");
            if (!QFile::exists(dest))
                jobs.append({ nat[QStringLiteral("url")].toString(), dest });
            natives.append({ dest, natDir });
        }
    }

    runQueue(dir, jobs, 10, 70, QStringLiteral("Libraries"), true,
             [this, dir, vjson, natives](bool ok, const QString &err) {
        if (!ok) {
            emit installDone(dir, false, err);
            return;
        }
        // Extract natives after their jars are on disk
        for (const auto &n : natives) {
            QDir().mkpath(n.second);
            extractJar(n.first, n.second);
        }
        downloadAssets(dir, vjson);
    });
}

void McInstanceManager::downloadAssets(const QString &dir, const QJsonObject &vjson)
{
    const QJsonObject assetIndex = vjson[QStringLiteral("assetIndex")].toObject();
    const QString idxUrl = assetIndex[QStringLiteral("url")].toString();
    const QString idxId  = assetIndex[QStringLiteral("id")].toString();

    const auto markReady = [this, dir] {
        QFile fi(dir + QStringLiteral("/instance.json"));
        if (fi.open(QIODevice::ReadOnly)) {
            QJsonObject o = QJsonDocument::fromJson(fi.readAll()).object();
            fi.close();
            o[QStringLiteral("ready")] = true;
            QFile out(dir + QStringLiteral("/instance.json"));
            if (out.open(QIODevice::WriteOnly)) {
                out.write(QJsonDocument(o).toJson());
                out.close();
            }
        }
        emit installProgress(dir, 100, QStringLiteral("Done"));
        emit installDone(dir, true, QString());
    };

    if (idxUrl.isEmpty()) {   // very old versions have no asset index
        markReady();
        return;
    }

    const QString idxDest = m_root + QStringLiteral("/assets/indexes/") + idxId +
                            QStringLiteral(".json");
    emit installProgress(dir, 72, QStringLiteral("Asset index"));
    if (!QFile::exists(idxDest) && !downloadFileSync(idxUrl, idxDest)) {
        emit installDone(dir, false, QStringLiteral("Asset index failed"));
        return;
    }

    QFile f(idxDest);
    if (!f.open(QIODevice::ReadOnly)) {
        emit installDone(dir, false, QStringLiteral("Asset index unreadable"));
        return;
    }
    const QJsonObject objects = QJsonDocument::fromJson(f.readAll()).object()
                                    [QStringLiteral("objects")].toObject();

    QList<QPair<QString, QString>> jobs;
    for (const QString &k : objects.keys()) {
        const QString hash = objects[k].toObject()[QStringLiteral("hash")].toString();
        if (hash.size() < 2)
            continue;
        const QString sub  = hash.left(2);
        const QString dest = m_root + QStringLiteral("/assets/objects/") + sub +
                             QLatin1Char('/') + hash;
        if (!QFile::exists(dest))
            jobs.append({ QString::fromLatin1(kResourcesBase) + sub + QLatin1Char('/') + hash,
                          dest });
    }

    // Asset failures are skipped (not fatal)
    runQueue(dir, jobs, 75, 99, QStringLiteral("Assets"), false,
             [markReady](bool, const QString &) { markReady(); });
}

// ── Launch ──
void McInstanceManager::launch(const QString &dir, const QString &name,
                               const QString &uuidIn, const QString &accessToken,
                               const QString &userType)
{
    QFile f(dir + QStringLiteral("/instance.json"));
    if (!f.open(QIODevice::ReadOnly)) {
        emit gameEnded(dir, -1);
        return;
    }
    const QJsonObject inst = QJsonDocument::fromJson(f.readAll()).object();
    const QString mcver = inst[QStringLiteral("mcVersion")].toString();
    const QString loader = inst[QStringLiteral("loader")].toString();

    // Locate version json on disk — loader instances live under their own id
    QString vid = mcver;
    if (!loader.isEmpty() && loader != QStringLiteral("vanilla")) {
        const QString cand = mcver + QLatin1Char('-') + loader;
        if (QFile::exists(m_root + QStringLiteral("/versions/") + cand +
                          QStringLiteral("/") + cand + QStringLiteral(".json")))
            vid = cand;
    }
    const QString vjsonPath = m_root + QStringLiteral("/versions/") + vid +
                              QStringLiteral("/") + vid + QStringLiteral(".json");

    // We need the version json; if missing, refetch via manifest
    if (!QFile::exists(vjsonPath)) {
        emit gameEnded(dir, -2);
        return;
    }
    QFile vf(vjsonPath);
    vf.open(QIODevice::ReadOnly);
    const QJsonObject vjson = QJsonDocument::fromJson(vf.readAll()).object();

    JavaRunner probe;
    const QStringList javas = probe.findJava();

    // Per-instance Java override → global default → first JVM found
    QSettings gs(QStringLiteral("EBALIA"), QStringLiteral("EBALIA Launcher"));
    const QString customJava = inst[QStringLiteral("javaPath")].toString();
    const QString globalJava = gs.value(QStringLiteral("mc/defaultJava")).toString();
    QString javaBin;
    if (!customJava.isEmpty() && QFile::exists(customJava))
        javaBin = customJava;
    else if (!globalJava.isEmpty() && QFile::exists(globalJava))
        javaBin = globalJava;
    else if (!javas.isEmpty())
        javaBin = javas.first();
    if (javaBin.isEmpty()) {
        emit gameEnded(dir, -3);
        return;
    }

    // Classpath: libraries + client jar
    QStringList cp;
    const QJsonArray libs = vjson[QStringLiteral("libraries")].toArray();
    for (const QJsonValue &lv : libs) {
        const QJsonObject lib = lv.toObject();
        if (!allowedByRules(lib))
            continue;
        const QString path = lib[QStringLiteral("downloads")].toObject()
                                 [QStringLiteral("artifact")].toObject()
                                 [QStringLiteral("path")].toString();
        if (!path.isEmpty()) {
            const QString full = m_root + QStringLiteral("/libraries/") + path;
            if (QFile::exists(full))
                cp << full;
        }
    }
    const QString jarPath = m_root + QStringLiteral("/versions/") + mcver +
                            QStringLiteral("/") + mcver + QStringLiteral(".jar");
    cp << jarPath;

#if defined(Q_OS_WIN)
    const QString cpSep = QStringLiteral(";");
#else
    const QString cpSep = QStringLiteral(":");
#endif

    const QString mainClass = vjson[QStringLiteral("mainClass")].toString();
    const QString assetsId  = vjson[QStringLiteral("assetIndex")].toObject()
                                  [QStringLiteral("id")].toString();
    const QString player = name.isEmpty() ? QStringLiteral("Player") : name;
    const QString uuid = uuidIn.isEmpty()
        ? QUuid::createUuid().toString(QUuid::WithoutBraces).remove(QLatin1Char('-'))
        : uuidIn;
    const QString token = accessToken.isEmpty() ? QStringLiteral("0") : accessToken;
    const QString uType = userType.isEmpty() ? QStringLiteral("legacy") : userType;

    QStringList args;
    const int xmx = inst[QStringLiteral("xmx")].toInt(
        gs.value(QStringLiteral("mc/defaultXmx"), 2048).toInt());
    args << QStringLiteral("-Xmx%1M").arg(xmx > 0 ? xmx : 2048)
         << QStringLiteral("-Djava.library.path=") + m_root +
                QStringLiteral("/versions/") + mcver + QStringLiteral("/natives")
         << QStringLiteral("-cp") << cp.join(cpSep) << mainClass;

    if (vjson.contains(QStringLiteral("arguments"))) {
        // Modern argument format
        args << QStringLiteral("--username") << player
             << QStringLiteral("--version") << mcver
             << QStringLiteral("--gameDir") << dir
             << QStringLiteral("--assetsDir") << m_root + QStringLiteral("/assets")
             << QStringLiteral("--assetIndex") << assetsId
             << QStringLiteral("--uuid") << uuid
             << QStringLiteral("--accessToken") << token
             << QStringLiteral("--userType") << uType;
        // Loader-supplied extra game args (Forge/NeoForge: --launchTarget etc.)
        const QJsonArray extra = vjson[QStringLiteral("_ebaliaExtraGameArgs")].toArray();
        for (const QJsonValue &ev : extra)
            args << ev.toString();
    } else {
        // Legacy minecraftArguments string
        QString legacy = vjson[QStringLiteral("minecraftArguments")].toString();
        legacy.replace(QStringLiteral("${auth_player_name}"), player);
        legacy.replace(QStringLiteral("${auth_session}"), token);
        legacy.replace(QStringLiteral("${auth_uuid}"), uuid);
        legacy.replace(QStringLiteral("${auth_access_token}"), token);
        legacy.replace(QStringLiteral("${user_properties}"), QStringLiteral("{}"));
        legacy.replace(QStringLiteral("${user_type}"), uType);
        legacy.replace(QStringLiteral("${game_directory}"), dir);
        legacy.replace(QStringLiteral("${assets_root}"), m_root + QStringLiteral("/assets"));
        legacy.replace(QStringLiteral("${game_assets}"), m_root + QStringLiteral("/assets"));
        legacy.replace(QStringLiteral("${assets_index_name}"), assetsId);
        legacy.replace(QStringLiteral("${version_name}"), mcver);
        args << legacy.split(QLatin1Char(' '), Qt::SkipEmptyParts);
    }

    auto *proc = new QProcess(this);
    proc->setWorkingDirectory(dir);
    proc->setProcessChannelMode(QProcess::ForwardedChannels);
    m_running.insert(dir, proc);
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this, dir, proc](int code, QProcess::ExitStatus) {
        m_running.remove(dir);
        proc->deleteLater();
        emit gameEnded(dir, code);
    });
    proc->start(javaBin, args);
    emit gameStarted(dir);
}

// ── Running games ──
bool McInstanceManager::isRunning(const QString &dir) const
{
    return m_running.contains(dir);
}

void McInstanceManager::killInstance(const QString &dir)
{
    QProcess *proc = m_running.value(dir, nullptr);
    if (!proc)
        return;
    proc->kill();              // finished() fires → gameEnded + hash cleanup
}

// ── Helpers ──
bool McInstanceManager::downloadFileSync(const QString &url, const QString &dest)
{
    QDir().mkpath(QFileInfo(dest).absolutePath());
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("EBALIA-Launcher/3.0"));
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);

    QNetworkReply *reply = m_nam.get(req);
    QEventLoop loop;
    QTimer timeout;
    timeout.setSingleShot(true);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    connect(&timeout, &QTimer::timeout, &loop, &QEventLoop::quit);
    timeout.start(60000);
    loop.exec();

    const bool ok = reply->error() == QNetworkReply::NoError;
    if (ok) {
        QFile out(dest);
        if (out.open(QIODevice::WriteOnly)) {
            out.write(reply->readAll());
            out.close();
        }
    }
    reply->deleteLater();
    return ok;
}

bool McInstanceManager::allowedByRules(const QJsonObject &lib) const
{
    const QJsonArray rules = lib[QStringLiteral("rules")].toArray();
    if (rules.isEmpty())
        return true;

#if defined(Q_OS_WIN)
    const QString os = QStringLiteral("windows");
#elif defined(Q_OS_MAC)
    const QString os = QStringLiteral("osx");
#else
    const QString os = QStringLiteral("linux");
#endif

    bool allowed = false;
    for (const QJsonValue &rv : rules) {
        const QJsonObject rule = rv.toObject();
        const QString action = rule[QStringLiteral("action")].toString();
        const QJsonObject osObj = rule[QStringLiteral("os")].toObject();
        if (osObj.isEmpty() ||
            osObj[QStringLiteral("name")].toString() == os) {
            allowed = (action != QStringLiteral("disallow"));
        }
    }
    return allowed;
}

QString McInstanceManager::nativesKey() const
{
#if defined(Q_OS_WIN)
    return QStringLiteral("natives-windows");
#elif defined(Q_OS_MAC)
    return QStringLiteral("natives-macos");
#else
    return QStringLiteral("natives-linux");
#endif
}

bool McInstanceManager::extractJar(const QString &jar, const QString &destDir)
{
    const QStringList tools = { QStringLiteral("bsdtar"), QStringLiteral("unzip") };
    for (const QString &tool : tools) {
        QProcess p;
        if (tool == QStringLiteral("bsdtar"))
            p.start(tool, {QStringLiteral("-xf"), jar, QStringLiteral("-C"), destDir});
        else
            p.start(tool, {QStringLiteral("-o"), jar, QStringLiteral("-d"), destDir});
        if (!p.waitForStarted(5000))
            continue;
        p.waitForFinished(-1);
        if (p.exitCode() == 0)
            return true;
    }
    return false;
}

// ── Mod loader profiles (Fabric / Quilt meta APIs) ──

QString McInstanceManager::mavenPath(const QString &name)
{
    // group:artifact:version → group/artifact/version/artifact-version.jar
    const QStringList parts = name.split(QLatin1Char(':'));
    if (parts.size() < 3)
        return QString();
    QString group = parts[0];
    group.replace(QLatin1Char('.'), QLatin1Char('/'));
    return group + QLatin1Char('/') + parts[1] + QLatin1Char('/') + parts[2] +
           QLatin1Char('/') + parts[1] + QLatin1Char('-') + parts[2] +
           QStringLiteral(".jar");
}

bool McInstanceManager::applyLoader(const QString &loader, const QString &mcver,
                                    QJsonObject &vjson, const QString &loaderVersion)
{
    QString base;
    if (loader == QStringLiteral("fabric"))
        base = QStringLiteral("https://meta.fabricmc.net/v2/versions/loader/");
    else if (loader == QStringLiteral("quilt"))
        base = QStringLiteral("https://meta.quiltmc.org/v3/versions/loader/");
    else
        return false;

    // Latest loader version for this MC version
    const QString listDest = QDir::tempPath() + QStringLiteral("/ebalia_loader_list.json");
    if (!downloadFileSync(base + mcver, listDest))
        return false;

    QFile lf(listDest);
    if (!lf.open(QIODevice::ReadOnly))
        return false;
    const QJsonArray list = QJsonDocument::fromJson(lf.readAll()).array();
    if (list.isEmpty())
        return false;
    // Chosen loader version wins; latest otherwise
    QString loaderVer;
    if (!loaderVersion.isEmpty()) {
        for (const QJsonValue &v : list) {
            if (v.toObject()[QStringLiteral("loader")].toObject()
                    [QStringLiteral("version")].toString() == loaderVersion) {
                loaderVer = loaderVersion;
                break;
            }
        }
    }
    if (loaderVer.isEmpty())
        loaderVer = list.first().toObject()
                        [QStringLiteral("loader")].toObject()
                        [QStringLiteral("version")].toString();
    if (loaderVer.isEmpty())
        return false;

    // Profile json
    const QString profDest = QDir::tempPath() + QStringLiteral("/ebalia_loader_profile.json");
    if (!downloadFileSync(base + mcver + QLatin1Char('/') + loaderVer +
                          QStringLiteral("/profile/json"), profDest))
        return false;

    QFile pf(profDest);
    if (!pf.open(QIODevice::ReadOnly))
        return false;
    const QJsonObject profile = QJsonDocument::fromJson(pf.readAll()).object();

    // Merge mainClass
    const QString mainClass = profile[QStringLiteral("mainClass")].toString();
    if (!mainClass.isEmpty())
        vjson[QStringLiteral("mainClass")] = mainClass;

    // Merge + download loader libraries
    QJsonArray libs = vjson[QStringLiteral("libraries")].toArray();
    const QJsonArray loaderLibs = profile[QStringLiteral("libraries")].toArray();
    for (const QJsonValue &lv : loaderLibs) {
        const QJsonObject lib = lv.toObject();
        const QString name = lib[QStringLiteral("name")].toString();
        const QString repo = lib[QStringLiteral("url")].toString();
        const QString path = mavenPath(name);
        if (path.isEmpty())
            continue;

        const QString dest = m_root + QStringLiteral("/libraries/") + path;
        if (!QFile::exists(dest))
            downloadFileSync(repo + path, dest);

        QJsonObject entry;
        QJsonObject downloads, artifact;
        artifact[QStringLiteral("path")] = path;
        artifact[QStringLiteral("url")]  = repo + path;
        downloads[QStringLiteral("artifact")] = artifact;
        entry[QStringLiteral("downloads")] = downloads;
        libs.append(entry);
    }
    vjson[QStringLiteral("libraries")] = libs;
    return true;
}

bool McInstanceManager::extractZipTo(const QString &zip, const QString &destDir)
{
    QDir().mkpath(destDir);
    const QStringList tools = { QStringLiteral("bsdtar"), QStringLiteral("unzip") };
    for (const QString &tool : tools) {
        QProcess p;
        if (tool == QStringLiteral("bsdtar"))
            p.start(tool, {QStringLiteral("-xf"), zip, QStringLiteral("-C"), destDir});
        else
            p.start(tool, {QStringLiteral("-o"), zip, QStringLiteral("-d"), destDir});
        if (!p.waitForStarted(5000))
            continue;
        p.waitForFinished(-1);
        if (p.exitCode() == 0)
            return true;
    }
    return false;
}

// ── Forge (1.13+) / NeoForge: installer-jar profile merge ──

static int compareSemver(const QString &a, const QString &b)
{
    const QStringList pa = a.split(QLatin1Char('.'));
    const QStringList pb = b.split(QLatin1Char('.'));
    const int n = qMax(pa.size(), pb.size());
    for (int i = 0; i < n; ++i) {
        const int va = i < pa.size() ? pa[i].toInt() : 0;
        const int vb = i < pb.size() ? pb[i].toInt() : 0;
        if (va != vb)
            return va < vb ? -1 : 1;
    }
    return 0;
}

bool McInstanceManager::applyForgeLike(const QString &loader, const QString &mcver,
                                       QJsonObject &vjson, const QString &loaderVersion)
{
    QString installerUrl;
    QString fallbackRepo;

    if (loader == QStringLiteral("forge")) {
        fallbackRepo = QStringLiteral("https://maven.minecraftforge.net/");

        // Chosen forge version (form "<mc>-<forge>") wins; promos latest otherwise
        QString fver;
        if (!loaderVersion.isEmpty()) {
            fver = loaderVersion;
            if (fver.startsWith(mcver + QLatin1Char('-')))
                fver = fver.mid(mcver.size() + 1);
        }
        if (fver.isEmpty()) {
            const QString promoDest = QDir::tempPath() + QStringLiteral("/ebalia_forge_promos.json");
            if (!downloadFileSync(QStringLiteral(
                    "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"),
                    promoDest))
                return false;
            QFile pf(promoDest);
            if (!pf.open(QIODevice::ReadOnly))
                return false;
            const QJsonObject promos = QJsonDocument::fromJson(pf.readAll()).object()
                                           [QStringLiteral("promos")].toObject();
            fver = promos[mcver + QStringLiteral("-latest")].toString();
            if (fver.isEmpty())
                fver = promos[mcver + QStringLiteral("-recommended")].toString();
            if (fver.isEmpty())
                return false;
        }

        installerUrl = QStringLiteral(
            "https://maven.minecraftforge.net/net/minecraftforge/forge/%1-%2/"
            "forge-%1-%2-installer.jar").arg(mcver, fver);
    } else { // neoforge
        fallbackRepo = QStringLiteral("https://maven.neoforged.net/releases/");

        const QString listDest = QDir::tempPath() + QStringLiteral("/ebalia_neoforge_versions.json");
        if (!downloadFileSync(QStringLiteral(
                "https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge"),
                listDest))
            return false;
        QFile lf(listDest);
        if (!lf.open(QIODevice::ReadOnly))
            return false;
        const QJsonArray vers = QJsonDocument::fromJson(lf.readAll()).object()
                                    [QStringLiteral("versions")].toArray();

        // MC 1.21.1 → NeoForge 21.1.x — strip the leading "1."
        QString prefix = mcver;
        if (prefix.startsWith(QStringLiteral("1.")))
            prefix = prefix.mid(2);

        QString best;
        if (!loaderVersion.isEmpty())
            best = loaderVersion;   // user-picked NeoForge version wins
        if (best.isEmpty()) {
            for (const QJsonValue &vv : vers) {
                const QString v = vv.toString();
                if (v.startsWith(prefix + QLatin1Char('.')) &&
                    compareSemver(v, best) > 0)
                    best = v;
            }
        }
        // 1.20.1 maps to the 47.1.x line (Forge-style numbering)
        if (best.isEmpty() && mcver == QStringLiteral("1.20.1")) {
            for (const QJsonValue &vv : vers) {
                const QString v = vv.toString();
                if (v.startsWith(QStringLiteral("47.1.")) &&
                    (best.isEmpty() || compareSemver(v, best) > 0))
                    best = v;
            }
        }
        if (best.isEmpty())
            return false;

        installerUrl = QStringLiteral(
            "https://maven.neoforged.net/releases/net/neoforged/neoforge/%1/"
            "neoforge-%1-installer.jar").arg(best);
    }

    const QString jarDest = QDir::tempPath() + QStringLiteral("/ebalia_loader_installer.jar");
    QFile::remove(jarDest);
    if (!downloadFileSync(installerUrl, jarDest))
        return false;

    // The installer jar is a zip with install_profile.json + version.json
    const QString extractDir = QDir::tempPath() + QStringLiteral("/ebalia_loader_installer");
    QDir(extractDir).removeRecursively();
    if (!extractZipTo(jarDest, extractDir))
        return false;

    return mergeForgeProfile(extractDir, fallbackRepo, vjson);
}

bool McInstanceManager::mergeForgeProfile(const QString &extractDir,
                                          const QString &fallbackRepo,
                                          QJsonObject &vjson)
{
    // version.json lives at the installer root, or inside install_profile.json
    QJsonObject vinfo;
    QFile vf(extractDir + QStringLiteral("/version.json"));
    if (vf.open(QIODevice::ReadOnly)) {
        vinfo = QJsonDocument::fromJson(vf.readAll()).object();
        vf.close();
    }
    if (vinfo.isEmpty()) {
        QFile pf(extractDir + QStringLiteral("/install_profile.json"));
        if (!pf.open(QIODevice::ReadOnly))
            return false;
        vinfo = QJsonDocument::fromJson(pf.readAll()).object()
                    [QStringLiteral("versionInfo")].toObject();
    }
    if (vinfo.isEmpty())
        return false;

    const QString mainClass = vinfo[QStringLiteral("mainClass")].toString();
    if (!mainClass.isEmpty())
        vjson[QStringLiteral("mainClass")] = mainClass;

    // Libraries: downloads.artifact.url when present; empty url = bundled
    // inside the installer under maven/; otherwise fall back to the repo.
    QJsonArray libs = vjson[QStringLiteral("libraries")].toArray();
    const QJsonArray loaderLibs = vinfo[QStringLiteral("libraries")].toArray();
    for (const QJsonValue &lv : loaderLibs) {
        const QJsonObject lib = lv.toObject();
        const QString name = lib[QStringLiteral("name")].toString();

        // The "client" classifier jar is Mojang's own — already the game jar.
        // Forge stopped publishing it on their maven (404). Skip it like Prism.
        const QStringList parts = name.split(QLatin1Char(':'));
        if (parts.size() >= 4 && parts[3] == QStringLiteral("client"))
            continue;
        QJsonObject artifact = lib[QStringLiteral("downloads")].toObject()
                                   [QStringLiteral("artifact")].toObject();
        QString path = artifact[QStringLiteral("path")].toString();
        if (path.isEmpty())
            path = mavenPath(name);
        if (path.isEmpty())
            continue;

        QString url = artifact[QStringLiteral("url")].toString();
        const QString dest = m_root + QStringLiteral("/libraries/") + path;
        if (!QFile::exists(dest)) {
            if (!url.isEmpty()) {
                downloadFileSync(url, dest);
            } else {
                const QString bundled = extractDir + QStringLiteral("/maven/") + path;
                if (QFile::exists(bundled)) {
                    QDir().mkpath(QFileInfo(dest).absolutePath());
                    QFile::copy(bundled, dest);
                } else {
                    downloadFileSync(fallbackRepo + path, dest);
                }
            }
        }
        if (url.isEmpty())
            url = fallbackRepo + path;

        QJsonObject entry, downloads, art;
        art[QStringLiteral("path")] = path;
        art[QStringLiteral("url")]  = url;
        downloads[QStringLiteral("artifact")] = art;
        entry[QStringLiteral("name")] = name;
        entry[QStringLiteral("downloads")] = downloads;
        libs.append(entry);
    }
    vjson[QStringLiteral("libraries")] = libs;

    // Pass through literal game args (--launchTarget forgeclient etc.);
    // launch() appends them after the standard set.
    QJsonArray extra;
    const QJsonArray gameArgs = vinfo[QStringLiteral("arguments")].toObject()
                                    [QStringLiteral("game")].toArray();
    for (const QJsonValue &av : gameArgs) {
        const QString a = av.toString();
        if (!a.isEmpty() && !a.contains(QStringLiteral("${")))
            extra.append(a);
    }
    if (!extra.isEmpty())
        vjson[QStringLiteral("_ebaliaExtraGameArgs")] = extra;

    return true;
}

// ── Modrinth .mrpack import ──

bool McInstanceManager::mrpackReadInfo(const QString &mrpack, QString &mcVersion,
                                       QString &loader)
{
    const QString tmp = QDir::tempPath() + QStringLiteral("/ebalia_mrpack");
    QDir(tmp).removeRecursively();
    if (!extractZipTo(mrpack, tmp))
        return false;

    QFile f(tmp + QStringLiteral("/modrinth.index.json"));
    if (!f.open(QIODevice::ReadOnly))
        return false;
    const QJsonObject deps = QJsonDocument::fromJson(f.readAll()).object()
                                 [QStringLiteral("dependencies")].toObject();
    mcVersion = deps[QStringLiteral("minecraft")].toString();

    loader = QStringLiteral("vanilla");
    if (deps.contains(QStringLiteral("fabric-loader")))      loader = QStringLiteral("fabric");
    else if (deps.contains(QStringLiteral("quilt-loader")))  loader = QStringLiteral("quilt");
    else if (deps.contains(QStringLiteral("neoforge")))      loader = QStringLiteral("neoforge");
    else if (deps.contains(QStringLiteral("forge")))         loader = QStringLiteral("forge");

    return !mcVersion.isEmpty();
}

static void copyDirContents(const QString &src, const QString &dst)
{
    const QDir from(src);
    if (!from.exists())
        return;
    QDir().mkpath(dst);
    for (const QFileInfo &e : from.entryInfoList(QDir::Dirs | QDir::Files |
                                                 QDir::NoDotAndDotDot | QDir::Hidden)) {
        const QString target = dst + QLatin1Char('/') + e.fileName();
        if (e.isDir())
            copyDirContents(e.absoluteFilePath(), target);
        else if (!QFile::exists(target))
            QFile::copy(e.absoluteFilePath(), target);
    }
}

bool McInstanceManager::installMrpackFiles(const QString &dir, const QString &mrpack)
{
    const QString tmp = QDir::tempPath() + QStringLiteral("/ebalia_mrpack");
    QDir(tmp).removeRecursively();
    if (!extractZipTo(mrpack, tmp))
        return false;

    QFile f(tmp + QStringLiteral("/modrinth.index.json"));
    if (!f.open(QIODevice::ReadOnly))
        return false;
    const QJsonArray files = QJsonDocument::fromJson(f.readAll()).object()
                                 [QStringLiteral("files")].toArray();

    int done = 0;
    const int total = files.size();
    for (const QJsonValue &fv : files) {
        const QJsonObject fo = fv.toObject();
        const QString path = fo[QStringLiteral("path")].toString();
        const QJsonArray dls = fo[QStringLiteral("downloads")].toArray();
        if (path.isEmpty() || dls.isEmpty())
            continue;
        const QString dest = dir + QLatin1Char('/') + path;
        if (!QFile::exists(dest))
            downloadFileSync(dls.first().toString(), dest); // a broken file is not fatal
        ++done;
        if (total > 0)
            emit installProgress(dir, int(90.0 * done / total),
                                 QStringLiteral("Modpack files %1/%2").arg(done).arg(total));
    }

    // Pack overrides (configs etc.) ship loose inside the zip
    copyDirContents(tmp + QStringLiteral("/overrides"), dir);
    QDir(tmp).removeRecursively();
    return true;
}
