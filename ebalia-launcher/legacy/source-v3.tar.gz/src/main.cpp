#include <QApplication>
#include <QDir>
#include <QStandardPaths>
#include <QTimer>
#include <QIcon>
#include <cstdio>
#include "MainWindow.hpp"
#include "SplashScreen.hpp"
#include "McInstanceManager.hpp"

static void ensureDataDirs() {
    QString base = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(base);
    QDir().mkpath(base + "/versions");
    QDir().mkpath(base + "/libraries");
    QDir().mkpath(base + "/assets");
    QDir().mkpath(base + "/java");
}

int main(int argc, char *argv[]) {
    QApplication::setOrganizationName("EBALIA");
    QApplication::setApplicationName("EBALIA Launcher");
    QApplication::setApplicationVersion("3.0.0");
    QApplication::setStyle("Fusion");

    QApplication app(argc, argv);
    app.setWindowIcon(QIcon(QStringLiteral(":/icon.png")));
    ensureDataDirs();

    // --installtest <mcver>: run the real install flow headless, log everything
    const QStringList preArgs = app.arguments();
    const int itIdx = preArgs.indexOf(QStringLiteral("--installtest"));
    if (itIdx >= 0 && itIdx + 1 < preArgs.size()) {
        const QString ver = preArgs[itIdx + 1];
        const QString loader = (itIdx + 2 < preArgs.size())
            ? preArgs[itIdx + 2] : QStringLiteral("vanilla");
        const bool guiMode = preArgs.contains(QStringLiteral("--gui"));
        QString base = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        auto *mgr = new McInstanceManager(base, &app);
        QObject::connect(mgr, &McInstanceManager::installProgress,
                         [](const QString &, int pct, const QString &stage) {
            fprintf(stderr, "[install] %3d%% %s\n", pct, stage.toUtf8().constData());
        });
        QObject::connect(mgr, &McInstanceManager::installDone,
                         &app, [&app](const QString &, bool ok, const QString &err) {
            fprintf(stderr, "[install] DONE ok=%d err=%s\n", ok ? 1 : 0,
                    err.toUtf8().constData());
            app.quit();
        });
        mgr->createInstance(QStringLiteral("selftest-") + ver, ver, loader);
        mgr->installInstance(mgr->instancesRoot() + QStringLiteral("/selftest-") + ver);
        return app.exec();
    }

    // --selftest [PageName]: grab splash + main window to /tmp PNGs and quit.
    // PageName (optional) invokes the matching onTab<PageName> slot first,
    // e.g. --selftest Mods / Servers / Learn / Fanarts / Setup / Support / News
    const QStringList args = app.arguments();
    const bool selftest = args.contains(QStringLiteral("--selftest"));
    QString page;
    const int pageIdx = args.indexOf(QStringLiteral("--selftest"));
    if (pageIdx >= 0 && pageIdx + 1 < args.size())
        page = args[pageIdx + 1];

    // Build the main window while the splash animation runs
    MainWindow window;

    auto *splash = new SplashScreen;
    splash->setAttribute(Qt::WA_DeleteOnClose);

    if (selftest) {
        // Mid-animation splash grab
        QTimer::singleShot(1200, splash, [splash] {
            splash->grab().save(QStringLiteral("/tmp/ebalia_splash.png"));
        });
    }

    QObject::connect(splash, &SplashScreen::finished, &window,
                     [&window, selftest, page] {
        window.show();
        if (!page.isEmpty())
            QMetaObject::invokeMethod(&window,
                                      QByteArray("onTab") + page.toUtf8(),
                                      Qt::DirectConnection);
        if (page == QLatin1String("ClientDebug")) {
            // auto-switch into CLIENT mode for dock testing
            QMetaObject::invokeMethod(&window, "onModeClient", Qt::DirectConnection);
        }
        if (page == QLatin1String("NewInstance")) {
            // Open the new-instance dialog non-modal and grab it
            QTimer::singleShot(300, &window, [&window] {
                QMetaObject::invokeMethod(&window, "onModeClient", Qt::DirectConnection);
                QTimer::singleShot(500, &window, [&window] {
                    QMetaObject::invokeMethod(&window, "onNewInstance", Qt::DirectConnection);
                });
            });
        }
        if (page == QLatin1String("InstallGui")) {
            // Drive the real install path inside the full GUI
            QTimer::singleShot(800, &window, [&window] {
                QMetaObject::invokeMethod(&window, "onModeClient", Qt::DirectConnection);
                QMetaObject::invokeMethod(&window, "installSelfTest",
                                          Qt::DirectConnection,
                                          Q_ARG(QString, QStringLiteral("1.20.1")));
            });
        }
        if (selftest) {
            const bool clientDebug = (page == QLatin1String("ClientDebug"));
            const bool newInst = (page == QLatin1String("NewInstance"));
            const bool installGui = (page == QLatin1String("InstallGui"));
            if (!installGui) {  // InstallGui quits itself on installDone
                QTimer::singleShot(clientDebug ? 14000 : (newInst ? 1600 : 700), &window, [&window, newInst] {
                    QWidget *target = newInst && QApplication::activeWindow()
                                          ? QApplication::activeWindow() : &window;
                    target->grab().save(QStringLiteral("/tmp/ebalia_main.png"));
                    QTimer::singleShot(200, qApp, &QCoreApplication::quit);
                });
            }
        } else {
            // First run only: mascot-guided tour (skippable)
            QTimer::singleShot(400, &window, &MainWindow::maybeStartTour);
        }
    });
    splash->show();

    return app.exec();
}
