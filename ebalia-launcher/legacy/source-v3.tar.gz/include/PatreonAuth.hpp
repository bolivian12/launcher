#pragma once

#include <QObject>
#include <QString>
#include <QNetworkAccessManager>

class QTcpServer;

// Patreon OAuth2 login (authorization-code flow with a loopback redirect).
// The launcher opens the browser, spins a one-shot local HTTP server,
// catches the ?code= callback, exchanges it for tokens and resolves the
// patron's active membership tier.
//
// SETUP (one time, creator side):
//   1. Register a client at https://www.patreon.com/portal/registration/register-clients
//   2. Redirect URI: http://127.0.0.1/callback  (any port — we use ephemeral)
//   3. Fill kClientId / kClientSecret in PatreonAuth.cpp
class PatreonAuth : public QObject {
    Q_OBJECT
public:
    explicit PatreonAuth(QObject *parent = nullptr);

    bool isConfigured() const;   // client id/secret filled in
    bool hasTokens() const;      // stored session exists
    QString authUrl() const { return m_authUrl; }  // last authorize URL (manual fallback)

    void startLogin();           // browser + loopback server
    void fetchIdentity();        // validate/refresh stored session
    void logout();               // drop stored tokens

signals:
    void loginStarted();
    void loginFailed(const QString &error);
    // tierRank: 0=free 1=exclusive 2=explicit 3=senior
    void identityReady(const QString &patronName, int tierRank, const QString &tierTitle);

private:
    void onCallbackConnection();
    void exchangeCode(const QString &code, quint16 port);
    void refreshTokens();
    void requestIdentity(const QString &accessToken, bool allowRefreshRetry);

    QNetworkAccessManager m_nam;
    QTcpServer *m_server = nullptr;
    QString m_authUrl;
};
