#pragma once

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QProgressBar>
#include <QScrollArea>
#include <QComboBox>
#include <QFrame>
#include <QStackedWidget>
#include <QString>
#include <QList>
#include <QVBoxLayout>

#include "VersionManager.hpp"
#include "DownloadManager.hpp"
#include "JavaRunner.hpp"
#include "LicenseManager.hpp"
#include "PatreonAuth.hpp"
#include "ModManager.hpp"
#include "NewsManager.hpp"
#include "UpdateChecker.hpp"
#include "DependencyManager.hpp"
#include "HeroSlideshow.hpp"
#include "McInstanceManager.hpp"
#include "MsAuth.hpp"
#include "AccountManager.hpp"

class NiceButton;
class QLineEdit;

struct VersionCard {
    int versionIndex = -1;
    QFrame *frame = nullptr;
    QLabel *statusLabel = nullptr;
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private slots:
    void onPlayClicked();
    void onInstallClicked();
    void onLicenseChipClicked();
    void onLicenseChanged();
    void onUpdateClicked();
    void onComboActivated(int row);

    void onTabPlay();
    void onTabVersions();
    void onTabMods();
    void onTabSupport();
    void onTabNews();
    void onTabServers();
    void onTabLearn();
    void onTabFanarts();
    void onTabSetup();
    void onTabSettings();

public slots:
    void maybeStartTour();
    void installSelfTest(const QString &mcver);   // drives the real GUI install path

    void onSideHome();
    void onSideAll();
    void onSideAlpha();
    void onSideHorror();
    void onSideRelease();

    // Client mode
    void onModeLost();
    void onModeClient();
    void onTabClient() { onModeClient(); }
    void onNewInstance();
    void refreshInstances();
    void fetchMcNews();
    void refreshAccountCombo();
    void onAddMsAccount();
    void onAddOfflineAccount();
    void onRemoveAccount();

private:
    void setupUI();
    void setupStylesheet();
    void connectSignals();
    void loadVersions();
    void refreshCards();
    void refreshCombo();
    void buildModsPage();
    void buildSupportPage();
    void buildServersPage();
    void buildLearnPage();
    void buildFanartsPage();
    void buildSetupPage();
    void buildSettingsPage();
    void retranslateUi();
    void rebuildNewsAreas();
    QWidget *buildNewsCard(const NewsItem &item, bool featured);
    QWidget *buildNewsLockCard();
    void selectVersion(int index);
    void updateHero(const VersionInfo &v, bool installed);
    void updateLicenseChip();
    bool newsVisible() const;
    void applyTheme(QWidget *page, const QString &theme);
    void showPage(QWidget *page, QPushButton *tab);
    void setSideChecked(QPushButton *active);
    void showVersionsCategory(QPushButton *side, const QString &category);
    void launchInstance(const QString &dir);
    void selectInstance(const QString &dir);
    QFrame *buildInstanceCard(const McInstance &in);
    QString m_selectedInstanceDir;

    // Sidebar
    QPushButton *m_licenseChip;
    QPushButton *m_modeLost;
    QPushButton *m_modeClient;
    QPushButton *m_sideHome;
    QPushButton *m_sideAll;
    QPushButton *m_sideAlpha;
    QPushButton *m_sideHorror;
    QPushButton *m_sideRelease;

    // Top tabs
    QPushButton *m_tabPlay;
    QPushButton *m_tabVersions;
    QPushButton *m_tabMods;
    QPushButton *m_tabSupport;
    QPushButton *m_tabNews;

    // Pages
    QStackedWidget *m_stack;
    QWidget *m_playPage;
    QWidget *m_versionsPage;
    QLabel *m_versionsHeader;
    QScrollArea *m_modsScroll;
    QVBoxLayout *m_modsLayout;
    QScrollArea *m_supportScroll;
    QVBoxLayout *m_supportLayout;
    QScrollArea *m_newsScroll;
    QVBoxLayout *m_newsLayout;
    QScrollArea *m_setupScroll;
    QVBoxLayout *m_setupLayout;
    QScrollArea *m_settingsScroll;
    QVBoxLayout *m_settingsLayout;
    QPushButton *m_sideSettings;
    QScrollArea *m_serversScroll;
    QVBoxLayout *m_serversLayout;
    QScrollArea *m_learnScroll;
    QVBoxLayout *m_learnLayout;
    QScrollArea *m_fanartsScroll;

    // Client mode page
    QWidget *m_clientPage;
    QVBoxLayout *m_instancesLayout;
    QVBoxLayout *m_clientNewsLayout;
    QComboBox *m_accountCombo;
    QList<McVersion> m_mcVersions;
    QHash<QString, qint64> m_playStarts;

    // Hero (play page)
    HeroSlideshow *m_slideshow;
    QLabel *m_heroCategory;
    QLabel *m_heroName;
    QLabel *m_heroDesc;
    QLabel *m_heroStatus;
    QComboBox *m_versionCombo;
    QProgressBar *m_progressBar;
    NiceButton *m_installButton;
    NiceButton *m_playButton;
    NiceButton *m_updateChip;
    NiceButton *m_folderButton;

    // News (play page strip)
    QVBoxLayout *m_playNewsLayout;

    // Cards list (versions page)
    QWidget *m_cardsContainer;
    QVBoxLayout *m_cardsLayout;

    // Managers
    VersionManager *m_versionManager;
    DownloadManager *m_downloadManager;
    DownloadManager *m_serverDl;
    JavaRunner *m_javaRunner;
    LicenseManager *m_licenseManager;
    PatreonAuth *m_patreonAuth;
    ModManager *m_modManager;
    NewsManager *m_newsManager;
    UpdateChecker *m_updateChecker;
    DependencyManager *m_depManager;
    McInstanceManager *m_mcManager;
    AccountManager *m_accountManager;

    QList<VersionCard> m_cards;
    QString m_currentCategory;
    int m_selectedIndex = -1;
    QString m_javaPath;
};
