#pragma once

#include <QObject>
#include <QString>
#include <QStringList>
#include <QList>
#include <QHash>
#include <QNetworkAccessManager>
#include <QJsonObject>
#include <QSharedPointer>
#include <functional>

class QProcess;

struct McVersion {
    QString id;
    QString type;   // release | snapshot | old_beta | old_alpha
    QString url;
    QString releaseTime;  // ISO date from the manifest
};

struct McInstance {
    QString name;
    QString dir;
    QString mcVersion;
    QString loader;  // vanilla | fabric | quilt | forge | neoforge
    bool ready = false;
    int xmx = 2048;          // max heap in MB (instance.json "xmx")
    qint64 lastPlayed = 0;   // unix secs, 0 = never
    qint64 totalSecs = 0;    // accumulated playtime
};

// Real Minecraft instances: live Mojang version manifest (auto-updates as
// new versions drop), downloads client + libraries + assets + natives,
// launches offline. Fabric/Quilt supported via their meta APIs,
// Forge (1.13+) and NeoForge via installer-jar profile merging.
class McInstanceManager : public QObject {
    Q_OBJECT
public:
    explicit McInstanceManager(const QString &dataDir, QObject *parent = nullptr);

    void fetchManifest();
    QList<McInstance> instances() const;
    QString instancesRoot() const { return m_root + QStringLiteral("/instances"); }

    void createInstance(const QString &name, const QString &mcVersion,
                        const QString &loader,
                        const QString &loaderVersion = QString());
    void deleteInstance(const QString &dir);
    void installInstance(const QString &dir);
    void launch(const QString &dir, const QString &name, const QString &uuid,
                const QString &accessToken, const QString &userType);

    // Running games (keyed by instance dir)
    bool isRunning(const QString &dir) const;
    void killInstance(const QString &dir);

    QString mcDir() const { return m_root; }
    static bool extractZipTo(const QString &zip, const QString &destDir);

    // Modrinth .mrpack import: read game version + loader from the index,
    // then download every referenced file into the instance dir.
    bool mrpackReadInfo(const QString &mrpack, QString &mcVersion, QString &loader);
    bool installMrpackFiles(const QString &dir, const QString &mrpack);

signals:
    void manifestReady(const QList<McVersion> &versions);
    void manifestFailed(const QString &error);
    void installProgress(const QString &dir, int pct, const QString &stage);
    void installDone(const QString &dir, bool ok, const QString &error);
    void gameStarted(const QString &dir);
    void gameEnded(const QString &dir, int code);

private:
    void installVersionJson(const QString &dir, const QJsonObject &vjson);
    bool applyLoader(const QString &loader, const QString &mcver, QJsonObject &vjson,
                     const QString &loaderVersion = QString());
    bool applyForgeLike(const QString &loader, const QString &mcver, QJsonObject &vjson,
                        const QString &loaderVersion = QString());
    bool mergeForgeProfile(const QString &extractDir, const QString &fallbackRepo,
                           QJsonObject &vjson);
    static QString mavenPath(const QString &name);
    void downloadLibraries(const QString &dir, const QJsonObject &vjson);
    void downloadAssets(const QString &dir, const QJsonObject &vjson);
    void runQueue(const QString &dir, QList<QPair<QString, QString>> jobs,
                  int pctFrom, int pctTo, const QString &stage, bool failFast,
                  std::function<void(bool, const QString &)> onDone);
    bool downloadFileSync(const QString &url, const QString &dest);
    bool allowedByRules(const QJsonObject &lib) const;
    QString nativesKey() const;
    bool extractJar(const QString &jar, const QString &destDir);

    QString m_root;
    QNetworkAccessManager m_nam;
    QHash<QString, QProcess*> m_running;
};
